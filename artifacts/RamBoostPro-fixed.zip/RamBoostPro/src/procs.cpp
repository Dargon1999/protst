#define WIN32_LEAN_AND_MEAN
#include "procs.h"
#include <tlhelp32.h>
#include <psapi.h>
#include <cwctype>

static std::wstring Basename(const std::wstring& name) {
    size_t p = name.find_last_of(L"\\/");
    std::wstring base = (p == std::wstring::npos) ? name : name.substr(p + 1);
    if (base.size() > 4 &&
        _wcsicmp(base.c_str() + base.size() - 4, L".exe") == 0)
        base = base.substr(0, base.size() - 4);
    return base;
}

static std::wstring Lower(const std::wstring& s) {
    std::wstring r = s;
    for (auto& c : r) c = (wchar_t)towlower(c);
    return r;
}

std::vector<std::pair<std::wstring, uint32_t>> AllProcesses() {
    std::vector<std::pair<std::wstring, uint32_t>> r;
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snap == INVALID_HANDLE_VALUE) return r;
    PROCESSENTRY32W pe{ sizeof(pe) };
    if (Process32FirstW(snap, &pe)) {
        do {
            std::wstring name = pe.szExeFile;
            while (!name.empty() && (name.front() == L'"' || name.front() == L' ')) name.erase(0, 1);
            r.emplace_back(name, pe.th32ProcessID);
        } while (Process32NextW(snap, &pe));
    }
    CloseHandle(snap);
    return r;
}

uint32_t FindProcByName(const std::wstring& name) {
    std::wstring target = Lower(Basename(name));
    for (auto& p : AllProcesses()) {
        if (Lower(Basename(p.first)) == target) return p.second;
    }
    return 0;
}

bool CloseProcByName(const std::wstring& name, DWORD waitMs) {
    std::wstring target = Lower(Basename(name));
    bool graceful = false;
    for (auto& p : AllProcesses()) {
        if (Lower(Basename(p.first)) != target) continue;
        HANDLE h = OpenProcess(PROCESS_TERMINATE | PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, FALSE, p.second);
        if (!h) continue;
        // enumerate its windows and post WM_CLOSE
        struct Ctx { uint32_t pid; bool posted; } c{ p.second, false };
        EnumWindows([](HWND w, LPARAM lp) -> BOOL {
            auto& ctx = *(Ctx*)lp;
            DWORD wid;
            if (GetWindowThreadProcessId(w, &wid) && wid == ctx.pid &&
                IsWindowVisible(w)) {
                PostMessageW(w, WM_CLOSE, 0, 0);
                ctx.posted = true;
            }
            return TRUE;
        }, (LPARAM)&c);
        graceful = graceful || c.posted;
        CloseHandle(h);
    }
    if (!graceful) return false;
    // wait then kill leftovers
    Sleep(waitMs);
    for (int tries = 0; tries < 3; tries++) {
        if (FindProcByName(target) == 0) break;
        for (auto& p : AllProcesses()) {
            if (Lower(Basename(p.first)) != target) continue;
            HANDLE h = OpenProcess(PROCESS_TERMINATE, FALSE, p.second);
            if (h) { TerminateProcess(h, 1); CloseHandle(h); }
        }
        Sleep(300);
    }
    return FindProcByName(target) == 0;
}

bool SetProcPriority(uint32_t pid, DWORD priorityClass) {
    HANDLE h = OpenProcess(PROCESS_SET_INFORMATION, FALSE, pid);
    if (!h) return false;
    bool ok = SetPriorityClass(h, priorityClass) != 0;
    CloseHandle(h);
    return ok;
}

int BoostPriorities(const std::vector<std::wstring>& apps) {
    int boosted = 0;
    for (auto& app : apps) {
        uint32_t pid = FindProcByName(app);
        if (pid && SetProcPriority(pid, HIGH_PRIORITY_CLASS)) boosted++;
    }
    return boosted;
}

bool BoostGameAffinity(const std::wstring& gameName) {
    uint32_t pid = FindProcByName(gameName);
    if (!pid) return false;
    HANDLE h = OpenProcess(PROCESS_SET_INFORMATION | PROCESS_QUERY_INFORMATION, FALSE, pid);
    if (!h) return false;
    bool ok = false;
    DWORD_PTR sysAff, procAff;
    if (GetProcessAffinityMask(h, &procAff, &sysAff)) {
        // exclude CPU0, keep the rest
        DWORD_PTR mask = procAff & ~(DWORD_PTR)1;
        if (mask != 0) ok = SetProcessAffinityMask(h, mask) != 0;
    }
    CloseHandle(h);
    return ok;
}

bool ServiceExists(const wchar_t* name) {
    SC_HANDLE scm = OpenSCManagerW(nullptr, L"ServicesActive", SC_MANAGER_CONNECT);
    if (!scm) return false;
    SC_HANDLE svc = OpenServiceW(scm, name, SERVICE_QUERY_STATUS);
    bool ok = (svc != nullptr);
    if (svc) CloseServiceHandle(svc);
    CloseServiceHandle(scm);
    return ok;
}

bool StopService(const wchar_t* name) {
    SC_HANDLE scm = OpenSCManagerW(nullptr, L"ServicesActive", SC_MANAGER_CONNECT);
    if (!scm) return false;
    SC_HANDLE svc = OpenServiceW(scm, name, SERVICE_STOP | SERVICE_QUERY_STATUS);
    if (!svc) { CloseServiceHandle(scm); return false; }
    SERVICE_STATUS status;
    bool ok = ControlService(svc, SERVICE_CONTROL_STOP, &status) != 0;
    if (ok) Sleep(400);
    CloseServiceHandle(svc);
    CloseServiceHandle(scm);
    return ok;
}