#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <windowsx.h>
#include <shellapi.h>
#include <shlobj.h>
#include <stdio.h>
#include <thread>
#include <atomic>
#include <memory>
#include <algorithm>
#include <cstring>
#include <cwctype>
#include <cstdarg>
#include <vector>
#include <string>
#include "memcore.h"
#include "cleanfiles.h"
#include "settings.h"
#include "procs.h"
#include "ui/ui.h"
#include "resource.h"

using namespace Gdiplus;

static const UINT WM_TRAY        = WM_APP + 1;
static const UINT WM_CLEAN_DONE  = WM_APP + 2;
static const UINT WM_SCAN_DONE   = WM_APP + 3;
static const UINT WM_DELETE_DONE = WM_APP + 4;
static const UINT WM_PROCS_DONE  = WM_APP + 5;
static const int  TIMER_MAIN     = 1;
static const int  IDM_TRAY_OPEN  = 1;
static const int  IDM_TRAY_CLEAN = 2;
static const int  IDM_TRAY_EXIT  = 3;
static const int  CAP_H          = 36;   // custom caption height

// Временные файлы: row height / card paddings / bottom summary strip
static const int TEMP_ROW_H     = 40;
static const int TEMP_PAD       = 14;
static const int TEMP_TOP_OFF   = 44;
static const int TEMP_SUMMARY_H = 30;

enum { T_OVERVIEW = 0, T_CLEAN, T_TEMP, T_PROCS, T_STREAM, T_SETTINGS, T_COUNT };
static const wchar_t* TAB_NAMES[T_COUNT] = {
    L"Обзор", L"Очистка", L"Временные файлы", L"Процессы", L"Стрим", L"Настройки"
};

static LRESULT CALLBACK DarkEditProc(HWND h, UINT m, WPARAM w, LPARAM l);
static const wchar_t* ACTION_NAMES[ACT_COUNT] = {
    L"Обрезка рабочих множеств", L"Standby List (низк.)", L"Кэш файлов ОС",
    L"Standby List (все)", L"Сброс изменённых страниц", L"Аллокация памяти",
    L"Сброс Суперфетча", L"Combine Pages", L"Сброс реестра", L"Чистка Pagefile"
};
static const wchar_t* MODE_NAMES[3] = { L"Мягкая", L"Умная", L"Агрессивная" };
static const wchar_t* PRESSURE_NAMES[5] = {
    L"Свободно", L"Норма", L"Предупреждение", L"Высокое", L"Критическое"
};
static const DWORD PRESSURE_COLORS[5] = {
    ui::GREEN, ui::GREEN, ui::ORANGE, ui::ORANGE, ui::RED
};

struct PendingDeleteData {
    std::vector<CleanCategory> cats;
    std::vector<int> idx;
    CleanReportData r;
};

struct App {
    HWND hwnd = nullptr;
    HICON icon = nullptr;
    HBRUSH editBrush = nullptr;
    Settings st;
    int tab = T_OVERVIEW;
    Snap snap;

    std::vector<ui::Button> tabs;
    std::vector<ui::Button> modeBtns;
    std::vector<ui::Check>  actionChecks;
    ui::Button btnCleanNow, btnStreamToggle, btnStartClean, btnScan, btnDelete,
               btnRefresh, btnHigh, btnKill, btnAddApp, btnAddBoost, btnAddProt,
               btnSaveSettings, btnApplyStream, btnCloseApps,
               btnSelAll, btnSelNone, btnAdminRelaunch;
    ui::Check chkAutostart, chkTray, chkNotifs, chkAutoClean, chkSched, chkStreamNotifs,
              chkSimpleUi;
    ui::ScrollBar sbTemp, sbProcs;
    RECT thrBar, thrHandle;
    RECT statCards[4];
    RECT donutCard, infoCard;
    RECT pressureRow;
    RECT listRc;
    RECT modeRc;
    RECT group1Rc, group2Rc;
    RECT editHotkeyRc, editSchedRc, editAddAppRc, editAddBoostRc, editAddProtRc;

    HWND hEditHotkey = nullptr, hEditSched = nullptr, hEditAddApp = nullptr,
         hEditAddBoost = nullptr, hEditAddProt = nullptr;
    WNDPROC origEditProc = nullptr;

    std::atomic<bool> cleaning{false};
    CleanReport pendingReport;
    CleanReport report;

    std::vector<CleanCategory> cats;
    std::vector<int>     catChecked;
    std::vector<int>     tempRows;       // -1 = group header row, else category index
    bool scanned = false;
    uint64_t scannedTotal = 0;
    int      scannedFiles = 0;
    std::atomic<bool> busyIo{false};
    std::atomic<int>  busyMode{0};          // 1 = scanning, 2 = deleting (busy indicator)
    std::shared_ptr<std::vector<CleanCategory>> tempPending;
    std::shared_ptr<PendingDeleteData> pendingDelete;
    uint64_t deleteResult = 0;
    int      deleteCount = 0;
    int      deleteSkipped = 0;
    bool     deleteServiceIssue = false;

    std::vector<ProcInfo> procs;
    int selProc = -1;
    std::shared_ptr<std::vector<ProcInfo>> procsPending;

    int scrollTemp = 0, scrollProcs = 0;
    int hoverTemp = -1, hoverProcs = -1;
    bool draggingThr = false;
    bool draggingSbTemp = false, draggingSbProcs = false;

    bool streamOn = false;
    DWORD lastStreamClean = 0;
    DWORD lastCleanTick = 0;
    bool  cleanedToday = false;
    int   lastCleanDayKey = 0;
    uint64_t lastCleanBefore = 0;
    int64_t  lastCleanDelta = 0;
    bool  hasClean = false;
    DWORD lastCleanDoneTick = 0;
    uint64_t sessionFreed = 0;
    float hist[60]{};
    int histIdx = 0, histCount = 0;

    HICON trayIcon = nullptr;
    DWORD trayColKey = (DWORD)-1;

    std::vector<int> procView;
    std::wstring procFilter;
    int sortCol = 0;
    bool sortAsc = true;
    RECT hdrName{}, hdrPid{}, hdrRam{};
    RECT editSearchRc;
    HWND hEditProcs = nullptr;

    std::wstring tipText;
    POINT tipPos{ 0, 0 };
    int tipTarget = -1;
    bool tipVisible = false;
    DWORD tipHoverTick = 0;
    RECT capMinRc{}, capMaxRc{}, capCloseRc{};
    bool capMinHov = false, capMaxHov = false, capCloseHov = false;
    bool capMinPr  = false, capMaxPr  = false, capClosePr  = false;
    bool capMax    = false;
    RECT capRestoredRc{};
    bool selftestMode = false;
    DWORD animTick = 0;
} GP;

static int HotkeyToVK(const std::wstring& s) {
    if (s.empty()) return 0;
    if (s[0] == L'F' && s.size() > 1) {
        int n = _wtoi(s.c_str() + 1);
        if (n >= 1 && n <= 24) return 0x6F + n;
    }
    if (s.size() == 1) return (int)towupper(s[0]);
    return 0;
}

static const wchar_t* GB(double gb) {
    static wchar_t buf[24];
    swprintf_s(buf, 24, L"%.2f ГБ", gb);
    return buf;
}

static std::wstring MBString(uint64_t bytes) {
    wchar_t buf[32];
    swprintf_s(buf, 32, L"%.0f МБ", bytes / 1048576.0);
    return buf;
}

static const wchar_t* ACTION_TOOLTIPS[ACT_COUNT] = {
    L"Обрезает рабочие множества процессов — страницы, не использовавшиеся в последнее время, помечаются кандидатами на выгрузку.",
    L"Очищает standby-список низкого приоритета (строки с меткой 'low').",
    L"Сбрасывает системный кэш файлов (File Cache) через NtSetSystemInformation.",
    L"Полная очистка всего standby-списка памяти.",
    L"Сбрасывает список изменённых страниц (modified list) в файл подкачки.",
    L"Выделяет и освобождает большой блок памяти для принудительной выгрузки.",
    L"Сбрасывает кэш SysMain (Superfetch).",
    L"Выполняет CombinePages — объединение одинаковых страниц памяти.",
    L"Сбрасывает внутренние структуры сброса реестра (registry recon).",
    L"Чистка pagefile через обнуление standby-страниц."
};

static std::wstring RelTime(DWORD sinceTick) {
    DWORD now = GetTickCount();
    DWORD sec = now > sinceTick ? (now - sinceTick) / 1000 : 0;
    if (sec < 60) return L"Только что";
    if (sec < 3600) return std::to_wstring(sec / 60) + L" мин назад";
    DWORD h = sec / 3600;
    if (h < 24) return std::to_wstring(h) + L" ч назад";
    return std::to_wstring(h / 24) + L" дн назад";
}

static void RebuildProcView();

static void SetListPos();
static void ApplyLayout();
static void StartClean(bool confirmAggressive = false);
static void StartScan();
static void StartDelete();
static void RefreshProcs();
static void ShowBalloon(const std::wstring& title, const std::wstring& msg, bool err = false);
static void ToggleStream();
static void SaveWindowPos();
static void UpdateTrayTip();
static void UpdateTrayIcon();

// ------------------------------------------------------------------ layout

static RECT Fit(RECT c, int x, int y, int w, int h) {
    RECT r;
    r.left = c.left + x; r.top = c.top + y;
    r.right = r.left + w; r.bottom = r.top + h;
    return r;
}

static SIZE MeasureGP(Graphics& g, const std::wstring& s, float pts, bool bold) {
    SIZE sz{};
    if (s.empty()) return sz;
    RectF r;
    g.MeasureString(s.c_str(), (INT)s.size(), ui::GetFont(pts, bold),
                    PointF(0.0f, 0.0f), &r);
    sz.cx = (LONG)ceilf(r.Width);
    sz.cy = (LONG)ceilf(r.Height);
    if (sz.cy <= 0) sz.cy = (int)pts + 2;
    return sz;
}

static bool StatusNeedsTwoLines(int availW) {
    std::wstring l1 = GP.st.autoClean ? L"Авто-очистка: ВКЛ" : L"Авто-очистка: ВЫКЛ";
    std::wstring l2 = GP.streamOn    ? L"Стрим: ВКЛ"       : L"Стрим: ВЫКЛ";
    std::wstring lr = GP.hasClean
        ? L"Последняя: " + RelTime(GP.lastCleanDoneTick) + L" · освобождено " +
          std::wstring(GB(GP.lastCleanDelta / 1073741824.0))
        : L"Очистка ещё не выполнялась";
    std::wstring sr = GP.hasClean
        ? L"За сессию: " + std::wstring(GB(GP.sessionFreed / 1073741824.0))
        : L"";
    if (!GP.hwnd) return false;
    HDC hdc = GetDC(GP.hwnd);
    if (!hdc) return false;
    Graphics mg(hdc);
    SIZE d1 = MeasureGP(mg, l1, 12, false);
    SIZE d2 = MeasureGP(mg, l2, 12, false);
    SIZE s1 = MeasureGP(mg, lr, 12, false);
    SIZE s2 = MeasureGP(mg, sr, 12, true);
    ReleaseDC(GP.hwnd, hdc);
    int leftW = 4 + 12 + d1.cx + 4 + 26 + 12 + d2.cx + 4;   // left block (dots + labels)
    int rightW = s1.cx + (sr.empty() ? 0 : 26 + s2.cx);     // right block (lr + sr)
    return (leftW + 26 + rightW) > (availW - 8);            // 8 = side padding
}

static void ApplyLayout() {
    RECT c;
    if (!GP.hwnd) return;
    GetClientRect(GP.hwnd, &c);
    const int M = 20;

    GP.capMinRc   = { c.right - 138, 3, c.right - 96, CAP_H - 3 };
    GP.capMaxRc   = { c.right - 94,  3, c.right - 52, CAP_H - 3 };
    GP.capCloseRc = { c.right - 50,  3, c.right - 8,  CAP_H - 3 };

    GP.tabs.clear();
    int x = M, y = CAP_H + 8;
    for (int i = 0; i < T_COUNT; i++) {
        int len = (int)wcslen(TAB_NAMES[i]);
        int w = 28 + len * 10;
        ui::Button b;
        b.rc = { x, y, x + w, y + 38 };
        b.text = TAB_NAMES[i];
        b.id = 200 + i;
        b.accent = (i == GP.tab);
        b.pill = true;
        GP.tabs.push_back(b);
        x += w + 10;
    }

    const int top = 96;
    const int body = top + 40;
    int W = c.right - 2 * M;

    if (GP.tab == T_OVERVIEW) {
        int cardW = (W - 3 * 14) / 4;
        const int statH = 86;
        for (int i = 0; i < 4; i++)
            GP.statCards[i] = Fit(c, M + i * (cardW + 14), body, cardW, statH);

        int below = body + statH + 16;
        int leftW = (W - 14) / 2;

        // Bottom block is anchored to the bottom edge of the window so it
        // always fits whatever the window size is:
        //   20px bottom margin, 46px buttons, 8px gap, strip (28/46), 16px gap.
        const int btnH = 46;
        const int stripH = StatusNeedsTwoLines(W) ? 46 : 28;
        int btnTop = c.bottom - 20 - btnH;
        int stripBottom = btnTop - 8;
        int stripTop = stripBottom - stripH;
        int cardsBottom = stripTop - 16;
        int cardH = cardsBottom - below;
        if (cardH < 140) { cardH = 140; cardsBottom = below + cardH; }

        GP.donutCard = Fit(c, M, below, leftW, cardH);
        GP.infoCard  = Fit(c, M + leftW + 14, below, W - leftW - 14, cardH);
        GP.pressureRow = Fit(c, M, stripTop, W, stripH);

        GP.btnCleanNow = {};
        GP.btnCleanNow.rc = Fit(c, M, btnTop, 200, btnH);
        GP.btnCleanNow.text = L"Очистить сейчас";
        GP.btnCleanNow.id = 1;
        GP.btnCleanNow.accent = true;
        GP.btnCleanNow.pill = true;

        GP.btnStreamToggle = {};
        GP.btnStreamToggle.rc = Fit(c, M + 216, btnTop, 220, btnH);
        GP.btnStreamToggle.text = GP.streamOn ? L"Стрим: ВКЛ" : L"Стрим: ВЫКЛ";
        GP.btnStreamToggle.id = 2;
        GP.btnStreamToggle.on = GP.streamOn;
        GP.btnStreamToggle.accent = !GP.streamOn;
        GP.btnStreamToggle.pill = true;
    }
    else if (GP.tab == T_CLEAN) {
        // Mode panel: title «Режим очистки» + the three mode pills inside one card.
        const int modePanelTop = body;
        const int modePanelH = 76;
        GP.modeRc = Fit(c, M, modePanelTop, W, modePanelH);

        const int pillW = 128, pillGap = 12;
        const int pillsTotal = 3 * pillW + 2 * pillGap;
        int pillsLeft = GP.modeRc.right - M - 16 - pillsTotal;
        int pillY = modePanelTop + (modePanelH - 40) / 2;

        GP.modeBtns.clear();
        for (int i = 0; i < 3; i++) {
            ui::Button b;
            b.rc = Fit(c, pillsLeft, pillY, pillW, 40);
            b.text = MODE_NAMES[i];
            b.id = 20 + i;
            b.on = ((int)GP.st.mode == i);
            b.accent = ((int)GP.st.mode == i);
            b.pill = true;
            GP.modeBtns.push_back(b);
            pillsLeft += pillW + pillGap;
        }
        int chkY = modePanelTop + modePanelH + 16;
        int cw = (W - 28) / 2;
        GP.actionChecks.clear();
        for (int i = 0; i < ACT_COUNT; i++) {
            ui::Check ch;
            int col = i / 5, row = i % 5;
            ch.rc = Fit(c, M + col * (cw + 14), chkY + row * 27, cw, 26);
            ch.box = { ch.rc.left, ch.rc.top, ch.rc.left + 18, ch.rc.top + 18 };
            ch.text = ACTION_NAMES[i];
            ch.id = 30 + i;
            ch.checked = GP.st.actions[i];
            GP.actionChecks.push_back(ch);
        }
        int btnTop = chkY + 4 * 27 + 28 + 15;
        GP.btnStartClean = {};
        GP.btnStartClean.rc = Fit(c, M, btnTop, 240, 48);
        GP.btnStartClean.text = L"Запустить очистку";
        GP.btnStartClean.id = 3;
        GP.btnStartClean.accent = true;
        GP.btnStartClean.pill = true;
        GP.btnStartClean.disabled = GP.cleaning.load();
        int listY = btnTop + 48 + 7;
        int lh = c.bottom - M - listY;
        if (lh < 60) lh = 60;
        GP.listRc = Fit(c, M, listY, W, lh);
    }
    else if (GP.tab == T_TEMP) {
        GP.btnScan = {}; GP.btnScan.rc = Fit(c, M, body, 160, 44);
        GP.btnScan.text = L"Сканировать"; GP.btnScan.id = 40;
        GP.btnScan.accent = !GP.scanned; GP.btnScan.pill = true;
        GP.btnDelete = {}; GP.btnDelete.rc = Fit(c, M + 176, body, 230, 44);
        GP.btnDelete.text = L"Удалить выбранное"; GP.btnDelete.id = 41;
        GP.btnDelete.disabled = !GP.scanned; GP.btnDelete.accent = GP.scanned; GP.btnDelete.pill = true;
        GP.btnSelAll = {}; GP.btnSelAll.rc = Fit(c, M + 422, body, 128, 44);
        GP.btnSelAll.text = L"Выбрать все"; GP.btnSelAll.id = 66; GP.btnSelAll.pill = true;
        GP.btnSelNone = {}; GP.btnSelNone.rc = Fit(c, M + 566, body, 134, 44);
        GP.btnSelNone.text = L"Снять выбор"; GP.btnSelNone.id = 67; GP.btnSelNone.pill = true;
        GP.btnAdminRelaunch = {};
        GP.btnAdminRelaunch.rc = Fit(c, M + W - 212, body + 38, 196, 30);
        GP.btnAdminRelaunch.text = L"Права администратора";
        GP.btnAdminRelaunch.id = 68;
        GP.btnAdminRelaunch.pill = true;
        GP.btnAdminRelaunch.accent = true;
        // Cat rows + group separators for scrolling
        GP.tempRows.clear();
        int prevGrp = -1;
        for (size_t i = 0; i < GP.cats.size(); i++) {
            if (GP.cats[i].group != prevGrp) { GP.tempRows.push_back(-1); prevGrp = GP.cats[i].group; }
            GP.tempRows.push_back((int)i);
        }
        int lh = c.bottom - M - (body + 64);
        if (lh < 60) lh = 60;
        GP.listRc = Fit(c, M, body + 64, W - 16, lh);
        GP.sbTemp.rc = Fit(c, M + W - 14, body + 68, 10, lh - 8);
        GP.sbTemp.total = (int)GP.tempRows.size();
        int visRows = std::max<int>(0, ((int)GP.listRc.bottom - (int)GP.listRc.top - TEMP_TOP_OFF - TEMP_PAD - TEMP_SUMMARY_H) / TEMP_ROW_H);
        GP.sbTemp.visible = visRows;
        GP.sbTemp.pos = GP.scrollTemp;
        GP.sbTemp.Update();
    }
    else if (GP.tab == T_PROCS) {
        GP.btnRefresh = {}; GP.btnRefresh.rc = Fit(c, M, body, 130, 44);
        GP.btnRefresh.text = L"Обновить"; GP.btnRefresh.id = 50; GP.btnRefresh.pill = true;
        GP.btnHigh = {}; GP.btnHigh.rc = Fit(c, M + 146, body, 190, 44);
        GP.btnHigh.text = L"Приоритет High"; GP.btnHigh.id = 51; GP.btnHigh.pill = true;
        GP.btnKill = {}; GP.btnKill.rc = Fit(c, M + 350, body, 140, 44);
        GP.btnKill.text = L"Завершить"; GP.btnKill.id = 52;
        GP.btnKill.accent = true; GP.btnKill.pill = true;
        int sw = W - 520;
        if (sw < 160) sw = 160;
        GP.editSearchRc = Fit(c, M + 504, body + 2, sw, 40);
        int lh = c.bottom - M - (body + 64);
        if (lh < 60) lh = 60;
        GP.listRc = Fit(c, M, body + 64, W - 16, lh);
        GP.sbProcs.rc = Fit(c, M + W - 14, body + 68, 10, lh - 8);
        GP.sbProcs.total = (int)GP.procView.size();
        int rowH = 32, pad = 14, topOff = 40;
        GP.sbProcs.visible = std::max<int>(0, ((int)GP.listRc.bottom - (int)GP.listRc.top - pad - topOff) / rowH);
        GP.sbProcs.pos = GP.scrollProcs;
        GP.sbProcs.Update();
        RECT h = GP.listRc;
        int hby = h.top + 8;
        GP.hdrPid  = { h.right - 304, hby, h.right - 204, hby + 24 };
        GP.hdrRam  = { h.right - 194, hby, h.right - pad, hby + 24 };
        GP.hdrName = { h.left + pad, hby, h.right - 314, hby + 24 };
    }
    else if (GP.tab == T_STREAM) {
        GP.btnStreamToggle = {};
        GP.btnStreamToggle.rc = Fit(c, M, body, 260, 48);
        GP.btnStreamToggle.text = GP.streamOn ? L"Стрим-режим: ВКЛ" : L"Стрим-режим: ВЫКЛ";
        GP.btnStreamToggle.id = 2;
        GP.btnStreamToggle.accent = !GP.streamOn;
        GP.btnStreamToggle.on = GP.streamOn;
        GP.btnStreamToggle.pill = true;
        GP.chkStreamNotifs = {};
        GP.chkStreamNotifs.rc = Fit(c, M, body + 60, 340, 24);
        GP.chkStreamNotifs.box = { GP.chkStreamNotifs.rc.left,
                                  GP.chkStreamNotifs.rc.top,
                                  GP.chkStreamNotifs.rc.left + 18,
                                  GP.chkStreamNotifs.rc.top + 18 };
        GP.chkStreamNotifs.text = L"Не показывать уведомления в стриме";
        GP.chkStreamNotifs.id = 70;
        GP.chkStreamNotifs.checked = GP.st.disableNotifsInStream;
        int gy = body + 96;
        int gh = (c.bottom - M - gy - 16) / 2;
        GP.group1Rc = Fit(c, M, gy, W, gh);
        GP.group2Rc = Fit(c, M, gy + gh + 16, W, gh);
        GP.editAddAppRc = Fit(c, M + 10, GP.group1Rc.top + 44, W - 210, 32);
        GP.btnAddApp = {};
        GP.btnAddApp.rc = Fit(c, M + 14 + W - 180, GP.group1Rc.top + 44, 160, 32);
        GP.btnAddApp.text = L"Добавить"; GP.btnAddApp.id = 60; GP.btnAddApp.pill = true;
        GP.btnCloseApps = {};
        GP.btnCloseApps.rc = Fit(c, M + W - 240, GP.group1Rc.top + 10, 230, 28);
        GP.btnCloseApps.text = L"Закрыть все из списка"; GP.btnCloseApps.id = 62;
        GP.btnCloseApps.pill = true;
        GP.editAddBoostRc = Fit(c, M + 10, GP.group2Rc.top + 44, W - 210, 32);
        GP.btnAddBoost = {};
        GP.btnAddBoost.rc = Fit(c, M + 14 + W - 180, GP.group2Rc.top + 44, 160, 32);
        GP.btnAddBoost.text = L"Добавить"; GP.btnAddBoost.id = 61; GP.btnAddBoost.pill = true;
        GP.btnApplyStream = {};
        GP.btnApplyStream.rc = Fit(c, M, gy + 2 * (gh + 16) - 44, 220, 38);
        GP.btnApplyStream.text = L"Применить буст"; GP.btnApplyStream.id = 63;
        GP.btnApplyStream.accent = true; GP.btnApplyStream.pill = true;
    }
    else if (GP.tab == T_SETTINGS) {
        RECT panel = Fit(c, M, body, W, 80);
        GP.chkAutostart = {};
        GP.chkAutostart.rc = Fit(panel, 16, 14, 270, 24);
        GP.chkAutostart.box = { GP.chkAutostart.rc.left, GP.chkAutostart.rc.top,
                               GP.chkAutostart.rc.left + 18, GP.chkAutostart.rc.top + 18 };
        GP.chkAutostart.text = L"Автозапуск с Windows";
        GP.chkAutostart.id = 80;
        GP.chkAutostart.checked = GP.st.autostart;

        GP.chkTray = {};
        GP.chkTray.rc = Fit(panel, 320, 14, 270, 24);
        GP.chkTray.box = { GP.chkTray.rc.left, GP.chkTray.rc.top,
                          GP.chkTray.rc.left + 18, GP.chkTray.rc.top + 18 };
        GP.chkTray.text = L"Сворачивать в трей";
        GP.chkTray.id = 81;
        GP.chkTray.checked = GP.st.minimizeToTray;

        GP.chkNotifs = {};
        GP.chkNotifs.rc = Fit(panel, 16, 46, 260, 24);
        GP.chkNotifs.box = { GP.chkNotifs.rc.left, GP.chkNotifs.rc.top,
                            GP.chkNotifs.rc.left + 18, GP.chkNotifs.rc.top + 18 };
        GP.chkNotifs.text = L"Уведомления об очистке";
        GP.chkNotifs.id = 82;
        GP.chkNotifs.checked = GP.st.showNotifications;

        GP.chkAutoClean = {};
        GP.chkAutoClean.rc = Fit(panel, 320, 46, 280, 24);
        GP.chkAutoClean.box = { GP.chkAutoClean.rc.left, GP.chkAutoClean.rc.top,
                               GP.chkAutoClean.rc.left + 18, GP.chkAutoClean.rc.top + 18 };
        GP.chkAutoClean.text = L"Авто-очистка по порогу";
        GP.chkAutoClean.id = 83;
        GP.chkAutoClean.checked = GP.st.autoClean;

        int sY = panel.bottom + 16;
        GP.thrBar = Fit(c, M, sY + 10, 320, 12);
        int pct = GP.st.autoThreshold;
        int hx = GP.thrBar.left + (int)((double)(GP.thrBar.right - GP.thrBar.left) * pct / 100.0);
        GP.thrHandle = { hx - 8, GP.thrBar.top - 8, hx + 8, GP.thrBar.top + 20 };

        GP.chkSched = {};
        GP.chkSched.rc = Fit(c, M + 360, sY, 160, 24);
        GP.chkSched.box = { GP.chkSched.rc.left, GP.chkSched.rc.top,
                           GP.chkSched.rc.left + 18, GP.chkSched.rc.top + 18 };
        GP.chkSched.text = L"По расписанию";
        GP.chkSched.id = 84;
        GP.chkSched.checked = GP.st.scheduledEnabled;
        GP.editSchedRc = Fit(c, M + 530, sY - 2, 90, 28);

        GP.editHotkeyRc = Fit(c, M + 140, sY + 50, 90, 28);
        GP.editAddProtRc = Fit(c, M + 140, sY + 96, 260, 28);
        GP.btnAddProt = {};
        GP.btnAddProt.rc = Fit(c, M + 410, sY + 96, 130, 28);
        GP.btnAddProt.text = L"Добавить"; GP.btnAddProt.id = 64; GP.btnAddProt.pill = true;

        GP.btnSaveSettings = {};
        GP.btnSaveSettings.rc = Fit(c, M, sY + 150, 220, 44);
        GP.btnSaveSettings.text = L"Сохранить настройки";
        GP.btnSaveSettings.id = 65;
        GP.btnSaveSettings.accent = true; GP.btnSaveSettings.pill = true;
        GP.chkSimpleUi = {};
        GP.chkSimpleUi.rc = Fit(c, M + 240, sY + 150, 380, 24);
        GP.chkSimpleUi.box = { GP.chkSimpleUi.rc.left, GP.chkSimpleUi.rc.top,
                                GP.chkSimpleUi.rc.left + 18, GP.chkSimpleUi.rc.top + 18 };
        GP.chkSimpleUi.text = L"Простой интерфейс (без эффектов)";
        GP.chkSimpleUi.id = 85;
        GP.chkSimpleUi.checked = GP.st.simpleUi;
    }
    SetListPos();
}

static void SetListPos() {
    auto mv = [](HWND e, RECT r) {
        if (!e) return;
        MoveWindow(e, r.left, r.top, r.right - r.left, r.bottom - r.top, TRUE);
        ShowWindow(e, SW_SHOW);
    };
    auto hide = [](HWND e) { if (e) ShowWindow(e, SW_HIDE); };
    if (GP.tab == T_SETTINGS) {
        mv(GP.hEditHotkey, GP.editHotkeyRc);
        mv(GP.hEditSched, GP.editSchedRc);
        mv(GP.hEditAddProt, GP.editAddProtRc);
        hide(GP.hEditAddApp); hide(GP.hEditAddBoost);
        hide(GP.hEditProcs);
    } else if (GP.tab == T_STREAM) {
        mv(GP.hEditAddApp, GP.editAddAppRc);
        mv(GP.hEditAddBoost, GP.editAddBoostRc);
        hide(GP.hEditHotkey); hide(GP.hEditSched); hide(GP.hEditAddProt);
        hide(GP.hEditProcs);
    } else if (GP.tab == T_PROCS) {
        mv(GP.hEditProcs, GP.editSearchRc);
        hide(GP.hEditHotkey); hide(GP.hEditSched); hide(GP.hEditAddProt);
        hide(GP.hEditAddApp); hide(GP.hEditAddBoost);
    } else {
        hide(GP.hEditHotkey); hide(GP.hEditSched); hide(GP.hEditAddProt);
        hide(GP.hEditAddApp); hide(GP.hEditAddBoost);
        hide(GP.hEditProcs);
    }
}

// ------------------------------------------------------------------ drawing

static void DrawFitted(Graphics& g, const std::wstring& s, RECT rc, float maxPt, float minPt,
                       COLORREF col, bool bold, int align) {
    float pt = maxPt;
    int rw = rc.right - rc.left;
    int rh = rc.bottom - rc.top;
    if (rw < 8) { ui::DrawText(g, s, rc, maxPt, col, bold, align); return; }
    while (pt > minPt) {
        RectF box;
        g.MeasureString(s.c_str(), (INT)s.size(), ui::GetFont(pt, bold), PointF(0, 0), &box);
        if (box.Width <= (REAL)rw - 2.0f && box.Height <= (REAL)rh + 4.0f) break;
        pt -= 0.5f;
    }
    ui::DrawText(g, s, rc, pt, col, bold, align);
}

static void DrawMiniGraph(Graphics& g, float x, float y, float w, float h, Color col) {
    int n = GP.histCount > 60 ? 60 : GP.histCount;
    if (n < 2 || w < 12 || h < 8) return;
    std::vector<PointF> pts((size_t)n);
    float mn = 100.0f, mx = 0.0f;
    for (int k = 0; k < n; k++) {
        int src = (GP.histIdx - n + k + 60) % 60;
        float v = GP.hist[src];
        if (v < mn) mn = v;
        if (v > mx) mx = v;
    }
    if (mx - mn < 1.0f) { mx = mn + 1.0f; }
    if (mn > 5.0f) mn = 0.0f;
    if (mx < 95.0f) mx = 100.0f;
    for (int k = 0; k < n; k++) {
        int src = (GP.histIdx - n + k + 60) % 60;
        float v = GP.hist[src];
        pts[(size_t)k].X = x + w * ((float)k / (float)(n - 1));
        pts[(size_t)k].Y = y + h - (v - mn) * h / (mx - mn);
    }
    if (!ui::g_simpleUi) {
        Pen gpen(Color(50, col.GetR(), col.GetG(), col.GetB()), 4.0f);
        g.DrawCurve(&gpen, pts.data(), (INT)pts.size(), 0.2f);
    }
    Pen pen(col, 1.6f);
    g.DrawCurve(&pen, pts.data(), (INT)pts.size(), 0.2f);
    SolidBrush fbr(Color(45, col.GetR(), col.GetG(), col.GetB()));
    std::vector<PointF> poly = pts;
    poly.push_back(PointF(pts.back().X, y + h));
    poly.push_back(PointF(pts.front().X, y + h));
    g.FillPolygon(&fbr, poly.data(), (INT)poly.size());
}

static void DrawStatusStrip(Graphics& g, const RECT& c) {
    RECT s = GP.pressureRow;
    if (s.right <= s.left) return;

    std::wstring l1 = GP.st.autoClean ? L"Авто-очистка: ВКЛ" : L"Авто-очистка: ВЫКЛ";
    std::wstring l2 = GP.streamOn    ? L"Стрим: ВКЛ"       : L"Стрим: ВЫКЛ";
    std::wstring lr = GP.hasClean
        ? L"Последняя: " + RelTime(GP.lastCleanDoneTick) + L" · освобождено " +
          std::wstring(GB(GP.lastCleanDelta / 1073741824.0))
        : L"Очистка ещё не выполнялась";
    std::wstring sr = GP.hasClean
        ? L"За сессию: " + std::wstring(GB(GP.sessionFreed / 1073741824.0))
        : L"";

    // Measure everything up front (single layout pass, no overlap)
    SIZE d1 = MeasureGP(g, l1, 12, false);
    SIZE d2 = MeasureGP(g, l2, 12, false);
    SIZE s1 = MeasureGP(g, lr, 12, false);
    SIZE s2 = MeasureGP(g, sr, 12, true);

    int leftW = 4 + 12 + d1.cx + 4 + 26 + 12 + d2.cx + 4;
    int rightW = s1.cx + (sr.empty() ? 0 : 26 + s2.cx);
    bool twoRows = (leftW + 26 + rightW) > (s.right - s.left - 8);
    if (!twoRows) {
        // Single line: left block (dots + labels), right block anchored right.
        // Draw each piece into a rect that is exactly one text line tall, so
        // the text cannot reflow into a second line inside the strip.
        int rightEdge = s.right;
        int lh = d1.cy > 0 ? d1.cy : 16;
        int vy = s.top + (s.bottom - s.top - lh) / 2;
        if (!sr.empty()) {
            RECT s2r = { rightEdge - 4 - s2.cx - 10, vy, rightEdge - 4, vy + lh };
            rightEdge = s2r.left - 26;
            ui::DrawText(g, sr, s2r, 12, ui::PURPLE, true, 2);
        }
        RECT s1r = { rightEdge - s1.cx - 10, vy, rightEdge, vy + lh };
        ui::DrawText(g, lr, s1r, 12, ui::DIM, false, 2);

        // Left block (dots + labels), naturally laid out after the right block
        int x = s.left + 4;
        int cy = vy + lh / 2;
        auto dot = [&](COLORREF col, int dx) {
            int cx = x + dx;
            ui::DrawCircle(g, (REAL)cx, (REAL)cy, 4.0f, true, ui::ToColor(col));
            if (!ui::g_simpleUi)
                ui::DrawGlow(g, (REAL)cx - 8, (REAL)cy - 8, 16.0f, 16.0f, 8.0f,
                             ui::ToColorA(col, 90), 3.0f);
        };
        auto label = [&](const std::wstring& t, SIZE sz) {
            int r = x + 12 + sz.cx + 8;
            if (r > rightEdge - 26) r = rightEdge - 26; // safe guard only
            RECT tr = { x + 12, vy, r, vy + lh };
            ui::DrawText(g, t, tr, 12, ui::TEXT, false, 0);
            x = tr.right + 26;
        };
        dot(GP.st.autoClean ? ui::GREEN : ui::DIM, 0);
        label(l1, d1);
        dot(GP.streamOn ? ui::GREEN : ui::DIM, 0);
        label(l2, d2);
    } else {
        // Two rows: row1 = dots + labels, row2 = last clean (left) + session (right)
        int mid = s.top + (s.bottom - s.top) / 2;
        RECT rTop = { s.left, s.top, s.right, mid };
        RECT rBot = { s.left, mid, s.right, s.bottom };

        int x = s.left + 4;
        int cy = (rTop.top + rTop.bottom) / 2;
        auto dot = [&](COLORREF col) {
            ui::DrawCircle(g, (REAL)x, (REAL)cy, 4.0f, true, ui::ToColor(col));
            if (!ui::g_simpleUi)
                ui::DrawGlow(g, (REAL)x - 8, (REAL)cy - 8, 16.0f, 16.0f, 8.0f,
                             ui::ToColorA(col, 90), 3.0f);
        };
        auto label = [&](const std::wstring& t, SIZE sz) {
            RECT tr = { x + 12, rTop.top, x + 12 + sz.cx + 8, rTop.bottom };
            ui::DrawText(g, t, tr, 12, ui::TEXT, false, 0);
            x = tr.right + 26;
        };
        dot(GP.st.autoClean ? ui::GREEN : ui::DIM);
        label(l1, d1);
        dot(GP.streamOn ? ui::GREEN : ui::DIM);
        label(l2, d2);

        // Bottom row: full available width, no ellipsis, both fully visible
        RECT lrR = { s.left + 4, rBot.top, s.right - 4, rBot.bottom };
        if (!sr.empty()) {
            RECT s2r = { s.right - 4 - s2.cx - 10, rBot.top, s.right - 4, rBot.bottom };
            ui::DrawText(g, sr, s2r, 12, ui::PURPLE, true, 2);
            lrR.right = s2r.left - 26;
        }
        ui::DrawText(g, lr, lrR, 12, ui::DIM, false, 0);
    }
}

static void DrawOverview(Graphics& g, const RECT& c) {
    Color donutFill = GP.snap.usagePct > 85 ? ui::ToColor(ui::RED)
                    : GP.snap.usagePct > 60 ? ui::ToColor(ui::ORANGE)
                    : ui::ToColor(ui::GREEN);
    Color donutGlow = GP.snap.usagePct > 85 ? Color(80, 248, 113, 113)
                    : GP.snap.usagePct > 60 ? Color(80, 251, 191, 36)
                    : Color(80, 52, 211, 153);

    // Title with subtle accent
    ui::DrawTextF(g, L"Обзор системы", (REAL)c.left, (REAL)c.top, 22, ui::TEXT, true);
    ui::DrawLine(g, (REAL)c.left, (REAL)c.top + 32, (REAL)c.left + 80, (REAL)c.top + 32,
                 ui::ToColor(ui::ACCENT), 2.5f);

    // 4 stat cards with shadows, top accent lines and icons
    struct CardInfo { const wchar_t* label; std::wstring value; COLORREF col; int accentCol; void(*iconFn)(Graphics&,float,float,float,Color); };
    CardInfo cards[4];
    cards[0] = { L"Доступно", std::wstring(GB(GP.snap.availGB())), ui::GREEN, ui::GREEN, ui::DrawIconMemory };
    cards[1] = { L"Всего",   std::wstring(GB(GP.snap.totalGB())), ui::TEXT,  ui::ACCENT, ui::DrawIconShield };
    cards[2] = { L"Standby", std::wstring(GB(GP.snap.standbyGB())), ui::ORANGE, ui::ORANGE, ui::DrawIconTemp };
    cards[3] = { L"В кэше", std::wstring(GB(GP.snap.cache / 1073741824.0)), ui::PURPLE, ui::PURPLE, ui::DrawIconBolt };

    for (int i = 0; i < 4; i++) {
        float cx = (REAL)GP.statCards[i].left;
        float cy = (REAL)GP.statCards[i].top;
        float cw = (REAL)(GP.statCards[i].right - GP.statCards[i].left);
        float ch = (REAL)(GP.statCards[i].bottom - GP.statCards[i].top);
        ui::DrawShadow(g, cx, cy, cw, ch, 10, 40);
        // Subtle background gradient
        ui::RoundedRectGradient(g, cx, cy, cw, ch, 10,
            Color(255, 28, 32, 42), Color(255, 22, 25, 34), true);
        ui::RoundedRect(g, cx, cy, cw, ch, 10, false, Color(), 1.0f, ui::ToColorA(ui::BORDER, 120));
        // Top accent line (thicker with glow)
        Color accent = ui::ToColor(cards[i].accentCol);
        if (!ui::g_simpleUi) {
            ui::DrawGlow(g, cx, cy - 2, cw, 6.0f, 3.0f, Color(70, accent.GetR(), accent.GetG(), accent.GetB()), 6.0f);
        }
        ui::DrawCardTopLine(g, cx, cy, cw, ch, 10, accent, 3.0f);
        GraphicsState cardClip = g.Save();
        g.SetClip(RectF(cx, cy, cw, ch));
        // Icon on the left
        float iconCx = cx + 26;
        float iconCy = cy + ch * 0.46f;
        Color iconBgCol = Color(70, accent.GetR(), accent.GetG(), accent.GetB());
        ui::DrawCircle(g, iconCx, iconCy, 16.0f, true, iconBgCol);
        if (cards[i].iconFn) cards[i].iconFn(g, iconCx, iconCy, 20.0f, accent);
        // Value — shrink to the card so "12.08 ГБ" never spills into the next one
        RECT v = GP.statCards[i];
        v.left = (int)(iconCx + 22);
        v.right = GP.statCards[i].right - 8;
        v.top = (int)(cy + 14);
        v.bottom = (int)(cy + 50);
        DrawFitted(g, cards[i].value, v, 18.0f, 12.0f, cards[i].col, true, 0);
        RECT l = v;
        l.top = (int)(cy + 50);
        l.bottom = GP.statCards[i].bottom - 8;
        ui::DrawText(g, cards[i].label, l, 11.0f, ui::DIM, false, 0);
        g.Restore(cardClip);
    }

    // Donut card (RAM usage visualization)
    {
        float dx = (REAL)GP.donutCard.left;
        float dy = (REAL)GP.donutCard.top;
        float dw = (REAL)(GP.donutCard.right - GP.donutCard.left);
        float dh = (REAL)(GP.donutCard.bottom - GP.donutCard.top);
        ui::DrawShadow(g, dx, dy, dw, dh, 12, 35);
        ui::RoundedRectGradient(g, dx, dy, dw, dh, 12,
            Color(255, 26, 29, 37), Color(255, 20, 22, 30), true);
        ui::RoundedRect(g, dx, dy, dw, dh, 12, false, Color(), 1.0f, ui::ToColorA(ui::BORDER, 120));
        Color accent = ui::ToColor(ui::ACCENT);
        if (!ui::g_simpleUi)
            ui::DrawGlow(g, dx, dy - 2, dw, 6.0f, 3.0f, Color(70, accent.GetR(), accent.GetG(), accent.GetB()), 5.0f);
        ui::DrawCardTopLine(g, dx, dy, dw, dh, 12, accent, 3.0f);
        // Header with icon
        ui::DrawIconMemory(g, dx + 22, dy + 24, 16.0f, accent);
        RECT hdrR = { (int)(dx + 40), (int)(dy + 10), (int)(dx + dw - 14), (int)(dy + 38) };
        ui::DrawText(g, L"Использование RAM", hdrR, 13, ui::TEXT, true, 0);

        float cx = dx + dw * 0.5f;
        float cy = dy + dh * 0.52f;
        float r = (dw < dh ? dw : dh) * 0.30f;
        float thick = 15.0f;
        const float legH = 22.0f;
        float maxR = (dy + dh - 6.0f) - 14.0f - thick - legH - cy;
        if (r > maxR) r = maxR;

        ui::DrawDonut(g, cx, cy, r, thick, GP.snap.usagePct / 100.0,
                      ui::ToColor(ui::BORDER), donutFill, donutGlow);

        wchar_t pct[24];
        swprintf_s(pct, 24, L"%.0f%%", GP.snap.usagePct);
        ui::DrawTextC(g, pct, cx, cy - 14, 30, ui::ToColor(ui::TEXT), true);
        ui::DrawTextC(g, L"Занято", cx, cy + 18, 11, ui::ToColor(ui::DIM), false);

        wchar_t used[48], avail[48];
        swprintf_s(used, 48, L"Исп: %.1f ГБ", (GP.snap.total - GP.snap.avail) / 1073741824.0);
        swprintf_s(avail, 48, L"Св: %.1f ГБ", GP.snap.availGB());
        RECT legL = { (int)(dx + 16), (int)(cy + r + thick + 14), (int)(dx + dw / 2 - 8), (int)(cy + r + thick + 36) };
        RECT legR = { (int)(dx + dw / 2 + 8), (int)(cy + r + thick + 14), (int)(dx + dw - 16), (int)(cy + r + thick + 36) };
        ui::DrawText(g, used, legL, 11, donutFill.ToCOLORREF(), true, 1);
        ui::DrawText(g, avail, legR, 11, ui::GREEN, true, 1);
    }

    // Info card (CPU + Pressure + mini RAM graph)
    {
        float ix = (REAL)GP.infoCard.left;
        float iy = (REAL)GP.infoCard.top;
        float iw = (REAL)(GP.infoCard.right - GP.infoCard.left);
        float ih = (REAL)(GP.infoCard.bottom - GP.infoCard.top);
        ui::DrawShadow(g, ix, iy, iw, ih, 12, 35);
        ui::RoundedRectGradient(g, ix, iy, iw, ih, 12,
            Color(255, 26, 29, 37), Color(255, 20, 22, 30), true);
        ui::RoundedRect(g, ix, iy, iw, ih, 12, false, Color(), 1.0f, ui::ToColorA(ui::BORDER, 120));
        Color purple = ui::ToColor(ui::PURPLE);
        if (!ui::g_simpleUi)
            ui::DrawGlow(g, ix, iy - 2, iw, 6.0f, 3.0f, Color(70, purple.GetR(), purple.GetG(), purple.GetB()), 5.0f);
        ui::DrawCardTopLine(g, ix, iy, iw, ih, 12, purple, 3.0f);
        ui::DrawIconCpu(g, ix + 24, iy + 22, 18.0f, purple);
        RECT hdrR = { (int)(ix + 48), (int)(iy + 10), (int)(ix + iw - 16), (int)(iy + 34) };
        ui::DrawText(g, L"Состояние системы", hdrR, 13, ui::TEXT, true, 0);

        // CPU mini donut
        float cpuR = 38;
        float cpuX = ix + iw * 0.22f;
        float cpuY = iy + ih * 0.35f;
        Color cpuCol = GP.snap.cpuPct > 80 ? ui::ToColor(ui::RED)
                     : GP.snap.cpuPct > 50 ? ui::ToColor(ui::ORANGE)
                     : ui::ToColor(ui::CYAN);
        Color cpuGlow = GP.snap.cpuPct > 80 ? Color(80, 248, 113, 113)
                      : GP.snap.cpuPct > 50 ? Color(80, 251, 191, 36)
                      : Color(80, 34, 211, 238);
        ui::DrawDonut(g, cpuX, cpuY, cpuR, 8, GP.snap.cpuPct / 100.0,
                      ui::ToColor(ui::BORDER), cpuCol, cpuGlow);
        wchar_t cp[24];
        swprintf_s(cp, 24, L"%.0f%%", GP.snap.cpuPct);
        ui::DrawTextC(g, cp, cpuX, cpuY, 14, ui::ToColor(ui::TEXT), true);
        ui::DrawTextC(g, L"CPU", cpuX, cpuY + 18, 10, ui::ToColor(ui::DIM), false);

        // Pressure
        int press = GP.snap.pressure;
        if (press > 4) press = 4;
        Color pressC = ui::ToColor(PRESSURE_COLORS[press]);
        float pIconX = ix + iw * 0.48f;
        float pIconY = iy + 58;
        Color pbCol = Color(55, pressC.GetR(), pressC.GetG(), pressC.GetB());
        ui::DrawCircle(g, pIconX, pIconY, 14.0f, true, pbCol);
        ui::DrawIconBolt(g, pIconX, pIconY, 16.0f, pressC);
        RECT prLab = { (int)(pIconX + 22), (int)(iy + 36), (int)(ix + iw - 12), (int)(iy + 56) };
        ui::DrawText(g, L"Давление памяти", prLab, 11, ui::DIM, false, 0);
        RECT prVal = { (int)(pIconX + 22), (int)(iy + 54), (int)(ix + iw - 12), (int)(iy + 80) };
        DrawFitted(g, PRESSURE_NAMES[press], prVal, 16.0f, 12.0f, PRESSURE_COLORS[press], true, 0);

        // Pressure bar
        float barY = iy + ih * 0.48f;
        float barW = iw * 0.84f;
        float barX = ix + (iw - barW) * 0.5f;
        ui::DrawBarHGlow(g, barX, barY, barW, 10, GP.snap.usagePct / 100.0, donutFill);

        // Mini RAM history graph
        float gy = iy + ih * 0.58f;
        DrawMiniGraph(g, ix + 8, gy, iw - 16, (iy + ih) - gy - 4, donutFill);
    }

    // Status strip: dots + last clean + session freed
    DrawStatusStrip(g, c);

    // Buttons with glow
    GP.btnCleanNow.Draw(g);
    GP.btnStreamToggle.Draw(g);
}

static void DrawClean(Graphics& g, const RECT& c) {
    const float tLeft = (REAL)(c.left + 38);
    const SIZE tSize = MeasureGP(g, L"Очистка памяти", 22, true);
    ui::DrawIconBolt(g, tLeft - 12, (REAL)c.top + 17, 22.0f, ui::ToColor(ui::ORANGE));
    ui::DrawTextF(g, L"Очистка памяти", tLeft, (REAL)c.top, 22, ui::TEXT, true);
    ui::DrawLine(g, tLeft, (REAL)c.top + 32, tLeft + tSize.cx, (REAL)c.top + 32,
                 ui::ToColor(ui::ORANGE), 2.5f);

    // Mode panel: «Режим очистки» + mode pills live inside this card.
    RECT modeRc = GP.modeRc;
    if (modeRc.right <= modeRc.left) modeRc = Fit(c, 0, 40, 0, 76);
    ui::DrawShadow(g, (REAL)modeRc.left, (REAL)modeRc.top, (REAL)(modeRc.right - modeRc.left),
                   (REAL)(modeRc.bottom - modeRc.top), 8, 22);
    ui::RoundedRectGradient(g, (REAL)modeRc.left, (REAL)modeRc.top,
                    (REAL)(modeRc.right - modeRc.left), (REAL)(modeRc.bottom - modeRc.top), 10,
                    Color(255, 25, 28, 36), Color(255, 20, 22, 30), true);
    ui::RoundedRect(g, (REAL)modeRc.left, (REAL)modeRc.top,
                    (REAL)(modeRc.right - modeRc.left), (REAL)(modeRc.bottom - modeRc.top), 10,
                    false, Color(), 1.0f, ui::ToColorA(ui::BORDER, 130));
    Color oc = ui::ToColor(ui::ORANGE);
    if (!ui::g_simpleUi)
        ui::DrawGlow(g, (REAL)modeRc.left, (REAL)modeRc.top - 2, (REAL)(modeRc.right - modeRc.left),
                     6, 3, Color(60, oc.GetR(), oc.GetG(), oc.GetB()), 4);
    ui::DrawCardTopLine(g, (REAL)modeRc.left, (REAL)modeRc.top,
                        (REAL)(modeRc.right - modeRc.left), (REAL)(modeRc.bottom - modeRc.top),
                        10, oc, 3.0f);
    int mh = modeRc.bottom - modeRc.top;
    RECT mlab = { modeRc.left + 20, modeRc.top + (mh - 24) / 2,
                  modeRc.left + 20 + 190, modeRc.top + (mh - 24) / 2 + 24 };
    ui::DrawText(g, L"Режим очистки:", mlab, 12, ui::DIM, true, 0);

    for (auto& b : GP.modeBtns) b.Draw(g);
    for (auto& ch : GP.actionChecks) ch.Draw(g);
    GP.btnStartClean.Draw(g);

    RECT rt = GP.listRc;
    ui::DrawShadow(g, (REAL)rt.left, (REAL)rt.top, (REAL)(rt.right - rt.left),
                   (REAL)(rt.bottom - rt.top), 10, 35);
    ui::RoundedRectGradient(g, (REAL)rt.left, (REAL)rt.top, (REAL)(rt.right - rt.left),
                    (REAL)(rt.bottom - rt.top), 10,
                    Color(255, 24, 27, 34), Color(255, 18, 20, 28), true);
    ui::RoundedRect(g, (REAL)rt.left, (REAL)rt.top, (REAL)(rt.right - rt.left),
                    (REAL)(rt.bottom - rt.top), 10, false, Color(), 1.0f, ui::ToColorA(ui::BORDER, 140));
    Color a2 = ui::ToColor(ui::ACCENT2);
    if (!ui::g_simpleUi)
        ui::DrawGlow(g, (REAL)rt.left, (REAL)rt.top - 2, (REAL)(rt.right - rt.left), 6, 3,
                     Color(60, a2.GetR(), a2.GetG(), a2.GetB()), 5);
    ui::DrawCardTopLine(g, (REAL)rt.left, (REAL)rt.top, (REAL)(rt.right - rt.left),
                        (REAL)(rt.bottom - rt.top), 10, a2, 3.0f);

    ui::DrawIconBolt(g, (REAL)rt.left + 20, (REAL)rt.top + 24, 16.0f, a2);
    RECT hd = Fit(rt, 44, 12, 0, 24);
    ui::DrawText(g, L"Результат очистки", hd, 13, ui::TEXT, true, 0);
    RECT hdrLine = Fit(rt, 16, 42, rt.right - rt.left - 32, 1);
    SolidBrush sep(ui::ToColorA(ui::BORDER, 160));
    g.FillRectangle(&sep, (REAL)hdrLine.left, (REAL)hdrLine.top, (REAL)(hdrLine.right - hdrLine.left), 1.0f);

    if (GP.cleaning.load()) {
        // Animated progress bar
        RECT pb = Fit(rt, 16, 50, rt.right - rt.left - 32, 8);
        ui::DrawShadow(g, (REAL)pb.left, (REAL)pb.top, (REAL)(pb.right - pb.left),
                       (REAL)(pb.bottom - pb.top), 4, 25);
        ui::RoundedRect(g, (REAL)pb.left, (REAL)pb.top, (REAL)(pb.right - pb.left),
                        (REAL)(pb.bottom - pb.top), 4, true, Color(40, 30, 40, 55));
        float pw = (float)(pb.right - pb.left);
        float tw = pw * 0.25f;
        float seg = (float)((GetTickCount() / 300) % 14);
        float px = (float)pb.left + (pw - tw) * (seg / 13.0f);
        ui::DrawGlow(g, px, (float)pb.top, tw, 8.0f, 4.0f,
                     Color(100, 96, 165, 250), 5.0f);
        ui::RoundedRectGradient(g, px, (float)pb.top, tw, 8.0f, 4.0f,
                                Color(255, 96, 165, 250), Color(255, 59, 130, 246), false);
        ui::DrawTextF(g, L"Очистка выполняется...",
                      (REAL)pb.left, (REAL)(pb.bottom + 10), 12, ui::DIM);
    } else if (GP.hasClean) {
        wchar_t beforeB[24], afterB[24], freedB[24];
        int64_t afterAvail = (int64_t)GP.lastCleanBefore + GP.lastCleanDelta;
        if (afterAvail < 0) afterAvail = 0;
        swprintf_s(beforeB, 24, L"%.2f ГБ", GP.lastCleanBefore / 1073741824.0);
        swprintf_s(afterB, 24, L"%.2f ГБ", afterAvail / 1073741824.0);
        swprintf_s(freedB, 24, L"%.2f ГБ", GP.lastCleanDelta / 1073741824.0);
        wchar_t buf[160];
        swprintf_s(buf, 160, L"Было: %s   |   Стало: %s", beforeB, afterB);
        RECT l1 = Fit(rt, 16, 48, rt.right - rt.left - 32, 20);
        if (rt.bottom - rt.top >= 72)
            ui::DrawText(g, buf, l1, 13, ui::TEXT, false, 0);
        RECT l2 = Fit(rt, 16, 70, rt.right - rt.left - 32, 24);
        if (rt.bottom - rt.top >= 98)
            ui::DrawTextF(g, std::wstring(L"Освобождено: ") + freedB,
                          (REAL)l2.left, (REAL)l2.top, 16,
                          GP.lastCleanDelta > 0 ? ui::GREEN : ui::RED, true);
        int y = 98;
        for (auto& s : GP.report.steps) {
            if (y > rt.bottom - rt.top - 22) break;
            RECT row = Fit(rt, 16, y, rt.right - rt.left - 32, 20);
            RECT nameR = { row.left, row.top, row.left + (rt.right - rt.left) - 320, row.bottom };
            ui::DrawText(g, s.name, nameR, 12, ui::TEXT, false, 0);
            wchar_t db[64];
            swprintf_s(db, 64, L"%+.2f ГБ", s.deltaBytes / 1073741824.0);
            RECT deltaR = { row.left + (rt.right - rt.left) - 180, row.top,
                            row.left + (rt.right - rt.left) - 20, row.bottom };
            ui::DrawText(g, db, deltaR, 12, s.deltaBytes >= 0 ? ui::GREEN : ui::RED, false, 2);
            y += 24;
        }
    } else {
        RECT e = Fit(rt, 16, 78, rt.right - rt.left - 32, 26);
        if (rt.bottom - rt.top >= 90)
            ui::DrawText(g, L"Запустите очистку — шаги и результаты появятся здесь", e, 13, ui::DIM, false, 0);
    }
}

static void DrawTemp(Graphics& g, const RECT& c) {
    ui::DrawIconTrash(g, (REAL)c.left + 14, (REAL)c.top + 17, 22.0f, ui::ToColor(ui::ACCENT));
    ui::DrawTextF(g, L"Временные файлы", (REAL)c.left + 38, (REAL)c.top, 22, ui::TEXT, true);
    ui::DrawLine(g, (REAL)c.left, (REAL)c.top + 32, (REAL)c.left + 100, (REAL)c.top + 32,
                 ui::ToColor(ui::ACCENT), 2.5f);

    GP.btnScan.text  = GP.busyMode.load() == 1 ? L"Сканирование..."   : L"Сканировать";
    GP.btnDelete.text = GP.busyMode.load() == 2 ? L"Удаление..."        : L"Удалить выбранное";
    GP.btnScan.disabled   = GP.busyIo.load();
    GP.btnDelete.disabled = GP.busyIo.load();
    GP.btnSelAll.disabled  = GP.busyIo.load();
    GP.btnSelNone.disabled = GP.busyIo.load();
    GP.btnScan.Draw(g);
    GP.btnDelete.Draw(g);
    GP.btnSelAll.Draw(g);
    GP.btnSelNone.Draw(g);
    if (!IsElevated()) GP.btnAdminRelaunch.Draw(g);

    RECT totalR = Fit(c, 0, 0, 0, 0);
    totalR.top = c.top + 40 + 44; totalR.bottom = totalR.top + 24; totalR.right = c.right - 20;
    if (!IsElevated()) totalR.right = GP.btnAdminRelaunch.rc.left - 12;
    std::wstring total;
    if (GP.busyMode.load() == 1) {
        total = L"Идёт сканирование...";
    } else if (GP.busyMode.load() == 2) {
        total = L"Идёт удаление...";
    } else {
        total = L"Всего: " + FormatBytes(GP.scannedTotal) +
            L"  (" + std::to_wstring(GP.scannedFiles) + L" файлов)";
        if (GP.deleteResult) total += L"   Удалено: " + FormatBytes(GP.deleteResult);
        else if (GP.deleteSkipped)
            total += L"   Не удалилось: " + std::to_wstring(GP.deleteSkipped);
    }
    if (!IsElevated())
        ui::DrawText(g, L"Для очистки некоторых системных файлов требуются права администратора.",
                     totalR, 12.5f, ui::ORANGE, false, 2);
    else
        ui::DrawText(g, total, totalR, 12.5f, ui::DIM, false, 2);

    RECT rt = GP.listRc;
    ui::DrawShadow(g, (REAL)rt.left, (REAL)rt.top, (REAL)(rt.right - rt.left),
                   (REAL)(rt.bottom - rt.top), 10, 35);
    ui::RoundedRectGradient(g, (REAL)rt.left, (REAL)rt.top, (REAL)(rt.right - rt.left),
                    (REAL)(rt.bottom - rt.top), 10,
                    Color(255, 24, 27, 34), Color(255, 18, 20, 28), true);
    ui::RoundedRect(g, (REAL)rt.left, (REAL)rt.top, (REAL)(rt.right - rt.left),
                    (REAL)(rt.bottom - rt.top), 10, false, Color(), 1.0f, ui::ToColorA(ui::BORDER, 140));
    Color ac = ui::ToColor(ui::ACCENT2);
    if (!ui::g_simpleUi)
        ui::DrawGlow(g, (REAL)rt.left, (REAL)rt.top - 2, (REAL)(rt.right - rt.left), 6, 3, Color(60, ac.GetR(), ac.GetG(), ac.GetB()), 5);
    ui::DrawCardTopLine(g, (REAL)rt.left, (REAL)rt.top, (REAL)(rt.right - rt.left),
                    (REAL)(rt.bottom - rt.top), 10, ac, 3.0f);

    // List header
    RECT hdrR = Fit(rt, 14, 10, 0, 24);
    ui::DrawText(g, L"Категория", hdrR, 12, ui::ACCENT, true, 0);
    RECT szHdr = { rt.right - 150, hdrR.top, rt.right - 14, hdrR.bottom };
    ui::DrawText(g, L"Размер", szHdr, 12, ui::ACCENT, true, 2);
    RECT sepR = Fit(rt, 14, 36, rt.right - rt.left - 28, 1);
    SolidBrush sep(ui::ToColorA(ui::BORDER, 160));
    g.FillRectangle(&sep, (REAL)sepR.left, (REAL)sepR.top, (REAL)(sepR.right - sepR.left), 1.0f);

    if (!GP.scanned) {
        RECT e = Fit(rt, 16, 90, 0, 26);
        if (GP.busyMode.load() == 1)
            ui::DrawText(g, L"Идёт сканирование... поиск временных файлов, кэшей и системных журналов",
                         e, 13, ui::ACCENT, false, 0);
        else
            ui::DrawText(g, L"Нажмите «Сканировать» — поиск временных файлов, кэшей и системных журналов",
                         e, 13, ui::DIM, false, 0);
        GP.sbTemp.Draw(g);
        return;
    }

    int vis = GP.sbTemp.visible;
    int maxScroll = ((int)GP.tempRows.size() > vis) ? (int)GP.tempRows.size() - vis : 0;
    if (GP.scrollTemp > maxScroll) GP.scrollTemp = maxScroll;
    if (GP.scrollTemp < 0) GP.scrollTemp = 0;
    GP.sbTemp.total = (int)GP.tempRows.size();
    GP.sbTemp.visible = vis;
    GP.sbTemp.pos = GP.scrollTemp;
    GP.sbTemp.Update();

    // Bottom summary strip
    RECT sumTop = { rt.left + 14, rt.bottom - TEMP_SUMMARY_H, rt.right - 14, rt.bottom - TEMP_SUMMARY_H + 1 };
    SolidBrush sepbr(ui::ToColorA(ui::BORDER, 150));
    g.FillRectangle(&sepbr, (REAL)sumTop.left, (REAL)sumTop.top,
                    (REAL)(sumTop.right - sumTop.left), 1.0f);

    uint64_t selSize = 0; int selFiles = 0;
    for (size_t i = 0; i < GP.cats.size(); i++) {
        if (GP.scanned && i < GP.catChecked.size() && GP.catChecked[i]
            && GP.cats[i].canClean && !GP.cats[i].scanOnly) {
            selSize += GP.cats[i].size;
            selFiles += GP.cats[i].count;
        }
    }
    RECT sumR = { rt.left + 14, rt.bottom - TEMP_SUMMARY_H + 6, rt.right - 14, rt.bottom - 4 };
    if (GP.deleteResult) {
        ui::DrawText(g,
                     L"Освобождено: " + FormatBytes(GP.deleteResult) +
                     L" · Удалено файлов: " + std::to_wstring(GP.deleteCount) +
                     L" · Пропущено: " + std::to_wstring(GP.deleteSkipped) +
                     (GP.deleteServiceIssue ? L" · службы: не восстановлены!" : L""),
                     sumR, 12.5f,
                     (GP.deleteSkipped > 0 || GP.deleteServiceIssue) ? ui::ORANGE : ui::GREEN, true, 0);
    } else {
        ui::DrawText(g, L"Можно очистить: " + FormatBytes(selSize) +
                     L"  ·  " + std::to_wstring(selFiles) + L" файлов (выбранные категории)",
                     sumR, 12.5f, ui::GREEN, true, 0);
    }

    for (int r = 0; r < vis; r++) {
        int ridx = r + GP.scrollTemp;
        if (ridx < 0 || ridx >= (int)GP.tempRows.size()) break;
        int idx = GP.tempRows[ridx];
        int y = rt.top + TEMP_TOP_OFF + r * TEMP_ROW_H;
        if (y + TEMP_ROW_H > rt.bottom - TEMP_SUMMARY_H) break;

        if (idx < 0) {
            // group header row
            int grp = CG_USER;
            for (int k = ridx; k < (int)GP.tempRows.size(); k++)
                if (GP.tempRows[k] >= 0) { grp = GP.cats[GP.tempRows[k]].group; break; }
            ui::DrawTextF(g, grp == CG_USER ? L"ПОЛЬЗОВАТЕЛЬ" : L"СИСТЕМА",
                          (REAL)rt.left + TEMP_PAD, (REAL)y + 3, 12, ui::ACCENT, true);
            ui::DrawLine(g, (REAL)rt.left + TEMP_PAD + 92, (REAL)y + 15,
                         (REAL)(rt.right - 20), (REAL)y + 15,
                         ui::ToColorA(ui::ACCENT, 90), 1.2f);
            continue;
        }

        auto& cat = GP.cats[idx];
        bool hover = idx == GP.hoverTemp;
        if (hover) {
            if (!ui::g_simpleUi)
                ui::DrawGlow(g, (REAL)rt.left + 6, (REAL)y - 2, (REAL)(rt.right - rt.left - 20), (REAL)(TEMP_ROW_H - 2),
                             6, Color(50, 96, 165, 250), 4.0f);
            SolidBrush hov(Color(60, 96, 165, 250));
            g.FillRectangle(&hov, (REAL)rt.left + 6, (REAL)y - 2, (REAL)(rt.right - rt.left - 20), (REAL)(TEMP_ROW_H - 2));
        } else if (r % 2 == 0) {
            SolidBrush alt(ui::ToColorA(ui::CARD2, 180));
            g.FillRectangle(&alt, (REAL)rt.left + 6, (REAL)y - 2, (REAL)(rt.right - rt.left - 20), (REAL)(TEMP_ROW_H - 2));
        }

        RECT box = { rt.left + TEMP_PAD, y + int(TEMP_ROW_H / 2) - 9, rt.left + TEMP_PAD + 18, y + int(TEMP_ROW_H / 2) + 9 };
        std::wstring sub;
        if (cat.count > 0) sub = std::to_wstring(cat.count) + L" файл.";
        if (cat.scanOnly || !cat.canClean) sub += (sub.empty() ? L"" : L" ") + std::wstring(L"· только просмотр");
        else if (cat.status == CS_PARTIAL) sub += (sub.empty() ? L"" : L" ") + std::wstring(L"· частично");
        bool two = !sub.empty();
        ui::Check ch;
        ch.box = box;
        ch.rc = { box.right + 10, y + (two ? 1 : 0), rt.right - 170, y + (two ? 22 : TEMP_ROW_H) };
        ch.text = cat.name;
        ch.checked = GP.catChecked[idx] != 0;
        ch.hover = hover;
        ch.disabled = !cat.canClean || cat.scanOnly;
        ch.Draw(g);

        if (cat.requiresAdmin) {
            Gdiplus::Font* nf = ui::GetFont(12.0f, false);
            RectF mr(0, 0, 0, 0);
            g.MeasureString(cat.name.c_str(), -1, nf, PointF(0, 0), &mr);
            float lx = (REAL)(box.right + 10) + mr.Width + 6.0f;
            if (lx < (REAL)(rt.right - 190))
                ui::DrawIconShield(g, lx, (REAL)(y + (two ? 11 : TEMP_ROW_H / 2)), 12.0f,
                                   IsElevated() ? ui::ToColorA(ui::ORANGE, 190) : ui::ToColor(ui::ORANGE));
        }
        if (two) {
            RECT subR = { box.right + 12, y + 18, rt.right - 170, y + TEMP_ROW_H };
            ui::DrawText(g, sub, subR, 9, ui::DIM, false, 0);
        }

        bool sizeTwo = cat.status == CS_PARTIAL || cat.scanOnly || !cat.canClean;
        RECT sr = { rt.right - 168, y, rt.right - TEMP_PAD - 6, y + (sizeTwo ? 20 : TEMP_ROW_H) };
        COLORREF sc = ui::DIM; bool sbold = false; std::wstring sv;
        if (cat.status == CS_DENIED) {
            sv = L"Доступ ограничен";
            sc = ui::RED; sbold = true;
        } else if (cat.status == CS_NOSRC) {
            sv = L"—";
        } else if (cat.size == 0) {
            sv = L"—";
        } else {
            sv = FormatBytes(cat.size);
            sc = ui::TEXT; sbold = true;
        }
        ui::DrawText(g, sv, sr, 12, sc, sbold, 2);
        RECT st2 = { rt.right - 150, y + 17, rt.right - TEMP_PAD - 8, y + TEMP_ROW_H };
        if (cat.status == CS_PARTIAL)
            ui::DrawText(g, L"частично доступно", st2, 9, ui::ORANGE, false, 2);
        else if (cat.scanOnly)
            ui::DrawText(g, L"не удаляется", st2, 9, ui::DIM, false, 2);
    }
    GP.sbTemp.Draw(g);
}

static void DrawProcs(Graphics& g, const RECT& c) {
    ui::DrawIconPlay(g, (REAL)c.left + 14, (REAL)c.top + 17, 22.0f, ui::ToColor(ui::PURPLE));
    ui::DrawTextF(g, L"Процессы", (REAL)c.left + 38, (REAL)c.top, 22, ui::TEXT, true);
    ui::DrawLine(g, (REAL)c.left, (REAL)c.top + 32, (REAL)c.left + 100, (REAL)c.top + 32,
                 ui::ToColor(ui::PURPLE), 2.5f);

    GP.btnRefresh.Draw(g);
    GP.btnHigh.Draw(g);
    GP.btnKill.Draw(g);
    RECT st = Fit(c, 0, 0, 0, 0);
    st.top = c.top + 40 + 46;
    st.right = c.right - 20;
    if (GP.procs.empty()) {
        ui::DrawText(g, L"Загрузка списка процессов...", st, 12, ui::DIM, false, 0);
    } else {
        ui::DrawText(g, std::to_wstring((int)GP.procView.size()) + L" процессов | выбран: " +
                     (GP.selProc >= 0 && GP.selProc < (int)GP.procView.size()
                          ? GP.procs[GP.procView[GP.selProc]].name : L"—"),
                     st, 12, ui::DIM, false, 0);
    }

    RECT rt = GP.listRc;
    ui::DrawShadow(g, (REAL)rt.left, (REAL)rt.top, (REAL)(rt.right - rt.left),
                   (REAL)(rt.bottom - rt.top), 10, 35);
    ui::RoundedRectGradient(g, (REAL)rt.left, (REAL)rt.top, (REAL)(rt.right - rt.left),
                    (REAL)(rt.bottom - rt.top), 10,
                    Color(255, 24, 27, 34), Color(255, 18, 20, 28), true);
    ui::RoundedRect(g, (REAL)rt.left, (REAL)rt.top, (REAL)(rt.right - rt.left),
                    (REAL)(rt.bottom - rt.top), 10, false, Color(), 1.0f, ui::ToColorA(ui::BORDER, 140));
    Color pc = ui::ToColor(ui::PURPLE);
    if (!ui::g_simpleUi)
        ui::DrawGlow(g, (REAL)rt.left, (REAL)rt.top - 2, (REAL)(rt.right - rt.left), 6, 3,
                     Color(60, pc.GetR(), pc.GetG(), pc.GetB()), 5);
    ui::DrawCardTopLine(g, (REAL)rt.left, (REAL)rt.top, (REAL)(rt.right - rt.left),
                    (REAL)(rt.bottom - rt.top), 10, pc, 3.0f);

    // Sortable header
    {
        auto hdr = [&](RECT rc, const wchar_t* t, int col) {
            std::wstring s = t;
            if (col == GP.sortCol) s = (GP.sortAsc ? L"▲ " : L"▼ ") + s;
            ui::DrawText(g, s, rc, 11.5f, col == GP.sortCol ? ui::PURPLE : ui::DIM,
                         col == GP.sortCol, 1);
        };
        hdr(GP.hdrName, L"Имя процесса", 2);
        hdr(GP.hdrPid, L"PID", 1);
        hdr(GP.hdrRam, L"RAM", 0);
    }
    // Separator below headers
    RECT sepR = Fit(rt, 14, 34, rt.right - rt.left - 28, 1);
    SolidBrush sep(ui::ToColorA(ui::BORDER, 160));
    g.FillRectangle(&sep, (REAL)sepR.left, (REAL)sepR.top, (REAL)(sepR.right - sepR.left), 1.0f);

    int rowH = 32, pad = 14;
    int topOff = 40;
    int vis = std::max<int>(0, ((int)rt.bottom - (int)rt.top - topOff - pad) / rowH);
    int maxScroll = ((int)GP.procView.size() > vis) ? (int)GP.procView.size() - vis : 0;
    if (GP.scrollProcs > maxScroll) GP.scrollProcs = maxScroll;
    if (GP.scrollProcs < 0) GP.scrollProcs = 0;
    GP.sbProcs.total = (int)GP.procView.size();
    GP.sbProcs.visible = vis;
    GP.sbProcs.pos = GP.scrollProcs;
    GP.sbProcs.Update();

    for (int i = 0; i < vis; i++) {
        int vidx = i + GP.scrollProcs;
        if (vidx >= (int)GP.procView.size()) break;
        int idx = GP.procView[vidx];
        int y = rt.top + pad + topOff + i * rowH;
        bool hover = vidx == GP.hoverProcs;
        bool selected = vidx == GP.selProc;
        if (selected) {
            if (!ui::g_simpleUi)
                ui::DrawGlow(g, (REAL)rt.left + 6, (REAL)y - 2,
                             (REAL)(rt.right - rt.left - 20), (REAL)rowH - 2,
                             6, Color(60, 96, 165, 250), 4.0f);
            SolidBrush sel(Color(200, 59, 130, 246));
            g.FillRectangle(&sel, (REAL)rt.left + 6, (REAL)y - 2, (REAL)(rt.right - rt.left - 20), (REAL)rowH - 2);
        } else if (hover) {
            if (!ui::g_simpleUi)
                ui::DrawGlow(g, (REAL)rt.left + 6, (REAL)y - 2, (REAL)(rt.right - rt.left - 20), (REAL)rowH - 2,
                             6, Color(50, 167, 139, 250), 4.0f);
            SolidBrush hov(Color(70, 167, 139, 250));
            g.FillRectangle(&hov, (REAL)rt.left + 6, (REAL)y - 2, (REAL)(rt.right - rt.left - 20), (REAL)rowH - 2);
        } else if (i % 2 == 0) {
            SolidBrush alt(ui::ToColorA(ui::CARD2, 180));
            g.FillRectangle(&alt, (REAL)rt.left + 6, (REAL)y - 2, (REAL)(rt.right - rt.left - 20), (REAL)rowH - 2);
        }
        // Protected shield icon
        if (GP.procs[idx].isProtected) {
            ui::DrawIconShield(g, (REAL)(rt.left + pad + 8), (REAL)(y + rowH / 2), 14.0f, ui::ToColor(ui::ORANGE));
        }
        int nameOff = GP.procs[idx].isProtected ? pad + 24 : pad;
        RECT nameR = { rt.left + nameOff, y, rt.right - 314, y + rowH };
        ui::DrawText(g, GP.procs[idx].name, nameR, 12,
                     selected ? RGB(255, 255, 255) :
                     (GP.procs[idx].isProtected ? ui::DIM : ui::TEXT),
                     (GP.procs[idx].isProtected || selected), 0);
        wchar_t pid[32];
        swprintf_s(pid, 32, L"PID %u", GP.procs[idx].pid);
        RECT pidR = { rt.right - 304, y, rt.right - 204, y + rowH };
        ui::DrawText(g, pid, pidR, 12, selected ? RGB(255,255,255) : ui::DIM, false, 1);
        RECT wsR = { rt.right - 194, y, rt.right - pad - 8, y + rowH };
        ui::DrawText(g, MBString(GP.procs[idx].ws), wsR, 12,
                     selected ? RGB(255,255,255) : ui::TEXT, true, 2);
    }
    GP.sbProcs.Draw(g);
}

static void DrawStream(Graphics& g, const RECT& c) {
    ui::DrawIconRocket(g, (REAL)c.left + 14, (REAL)c.top + 17, 22.0f,
        GP.streamOn ? ui::ToColor(ui::GREEN) : ui::ToColor(ui::ACCENT));
    ui::DrawTextF(g, L"Стрим-режим", (REAL)c.left + 38, (REAL)c.top, 22, ui::TEXT, true);
    ui::DrawLine(g, (REAL)c.left, (REAL)c.top + 32, (REAL)c.left + 100, (REAL)c.top + 32,
                 GP.streamOn ? ui::ToColor(ui::GREEN) : ui::ToColor(ui::ACCENT), 2.5f);

    GP.btnStreamToggle.Draw(g);
    GP.chkStreamNotifs.Draw(g);

    RECT g1 = GP.group1Rc;
    ui::DrawShadow(g, (REAL)g1.left, (REAL)g1.top, (REAL)(g1.right - g1.left),
                   (REAL)(g1.bottom - g1.top), 10, 28);
    ui::RoundedRectGradient(g, (REAL)g1.left, (REAL)g1.top, (REAL)(g1.right - g1.left),
                    (REAL)(g1.bottom - g1.top), 10,
                    Color(255, 26, 29, 37), Color(255, 20, 22, 30), true);
    ui::RoundedRect(g, (REAL)g1.left, (REAL)g1.top, (REAL)(g1.right - g1.left),
                    (REAL)(g1.bottom - g1.top), 10, false, Color(), 1.0f, ui::ToColorA(ui::BORDER, 130));
    Color rc = ui::ToColor(ui::RED);
    if (!ui::g_simpleUi)
        ui::DrawGlow(g, (REAL)g1.left, (REAL)g1.top - 2, (REAL)(g1.right - g1.left), 6, 3, Color(60, rc.GetR(), rc.GetG(), rc.GetB()), 4);
    ui::DrawCardTopLine(g, (REAL)g1.left, (REAL)g1.top, (REAL)(g1.right - g1.left),
                        (REAL)(g1.bottom - g1.top), 10, rc, 3.0f);
    ui::DrawIconTrash(g, (REAL)g1.left + 20, (REAL)g1.top + 24, 16.0f, rc);
    RECT h1 = Fit(g1, 42, 12, 0, 24);
    ui::DrawText(g, L"Закрыть фоновые приложения", h1, 13, ui::TEXT, true, 0);
    GP.btnCloseApps.Draw(g);
    int y = 56;
    int maxY = g1.bottom - 48;
    for (size_t ai = 0; ai < GP.st.closeApps.size(); ai++) {
        int ry = g1.top + y;
        if (ry + 26 > maxY) break;
        RECT itemRc = Fit(g1, 12, y, g1.right - g1.left - 24, 26);
        ui::RoundedRect(g, (REAL)itemRc.left, (REAL)itemRc.top,
            (REAL)(itemRc.right - itemRc.left), (REAL)(itemRc.bottom - itemRc.top),
            6, true, Color(35, 50, 35, 46));
        ui::RoundedRect(g, (REAL)itemRc.left, (REAL)itemRc.top,
            (REAL)(itemRc.right - itemRc.left), (REAL)(itemRc.bottom - itemRc.top),
            6, false, Color(), 1.0f, ui::ToColorA(ui::BORDER, 100));
        RECT tr = Fit(itemRc, 12, 0, itemRc.right - itemRc.left - 12, 26);
        ui::DrawText(g, L"• " + GP.st.closeApps[ai], tr, 12, ui::TEXT, false, 0);
        y += 30;
    }
    if (GP.st.closeApps.empty()) {
        ui::DrawText(g, L"Список пуст — добавьте процессы для закрытия при стриме",
            Fit(g1, 16, 60, g1.right - g1.left - 32, 26), 12, ui::DIM, false, 0);
    }
    GP.btnAddApp.Draw(g);

    RECT g2 = GP.group2Rc;
    ui::DrawShadow(g, (REAL)g2.left, (REAL)g2.top, (REAL)(g2.right - g2.left),
                   (REAL)(g2.bottom - g2.top), 10, 28);
    ui::RoundedRectGradient(g, (REAL)g2.left, (REAL)g2.top, (REAL)(g2.right - g2.left),
                    (REAL)(g2.bottom - g2.top), 10,
                    Color(255, 26, 29, 37), Color(255, 20, 22, 30), true);
    ui::RoundedRect(g, (REAL)g2.left, (REAL)g2.top, (REAL)(g2.right - g2.left),
                    (REAL)(g2.bottom - g2.top), 10, false, Color(), 1.0f, ui::ToColorA(ui::BORDER, 130));
    Color gc = ui::ToColor(ui::GREEN);
    if (!ui::g_simpleUi)
        ui::DrawGlow(g, (REAL)g2.left, (REAL)g2.top - 2, (REAL)(g2.right - g2.left), 6, 3, Color(60, gc.GetR(), gc.GetG(), gc.GetB()), 4);
    ui::DrawCardTopLine(g, (REAL)g2.left, (REAL)g2.top, (REAL)(g2.right - g2.left),
                        (REAL)(g2.bottom - g2.top), 10, gc, 3.0f);
    ui::DrawIconBolt(g, (REAL)g2.left + 20, (REAL)g2.top + 24, 16.0f, gc);
    RECT h2 = Fit(g2, 42, 12, 0, 24);
    ui::DrawText(g, L"Повысить приоритет (игры/приложения)", h2, 13, ui::TEXT, true, 0);
    int y2 = 56;
    int maxY2 = g2.bottom - 12;
    for (size_t ai = 0; ai < GP.st.highPrioApps.size(); ai++) {
        int ry = g2.top + y2;
        if (ry + 26 > maxY2) break;
        RECT itemRc = Fit(g2, 12, y2, g2.right - g2.left - 24, 26);
        ui::RoundedRect(g, (REAL)itemRc.left, (REAL)itemRc.top,
            (REAL)(itemRc.right - itemRc.left), (REAL)(itemRc.bottom - itemRc.top),
            6, true, Color(30, 50, 55, 46));
        ui::RoundedRect(g, (REAL)itemRc.left, (REAL)itemRc.top,
            (REAL)(itemRc.right - itemRc.left), (REAL)(itemRc.bottom - itemRc.top),
            6, false, Color(), 1.0f, ui::ToColorA(ui::BORDER, 100));
        RECT tr = Fit(itemRc, 12, 0, itemRc.right - itemRc.left - 12, 26);
        ui::DrawText(g, L"• " + GP.st.highPrioApps[ai], tr, 12, ui::TEXT, false, 0);
        y2 += 30;
    }
    if (GP.st.highPrioApps.empty())
        ui::DrawText(g, L"Список пуст — добавьте игры для повышения приоритета",
            Fit(g2, 16, 60, 0, 26), 12, ui::DIM, false, 0);
    GP.btnAddBoost.Draw(g);
    GP.btnApplyStream.Draw(g);
}

static void DrawSettings(Graphics& g, const RECT& c) {
    ui::DrawIconSettings(g, (REAL)c.left + 14, (REAL)c.top + 17, 22.0f, ui::ToColor(ui::ACCENT));
    ui::DrawTextF(g, L"Настройки", (REAL)c.left + 38, (REAL)c.top, 22, ui::TEXT, true);
    ui::DrawLine(g, (REAL)c.left, (REAL)c.top + 32, (REAL)c.left + 100, (REAL)c.top + 32,
                 ui::ToColor(ui::ACCENT), 2.5f);

    RECT sTop = c; sTop.top = c.top + 40; sTop.bottom = sTop.top + 80;
    ui::DrawShadow(g, (REAL)sTop.left, (REAL)sTop.top, (REAL)(sTop.right - sTop.left),
                   (REAL)(sTop.bottom - sTop.top), 8, 25);
    ui::RoundedRectGradient(g, (REAL)sTop.left, (REAL)sTop.top, (REAL)(sTop.right - sTop.left),
                    (REAL)(sTop.bottom - sTop.top), 10,
                    Color(255, 25, 28, 36), Color(255, 20, 22, 30), true);
    ui::RoundedRect(g, (REAL)sTop.left, (REAL)sTop.top, (REAL)(sTop.right - sTop.left),
                    (REAL)(sTop.bottom - sTop.top), 10, false, Color(), 1.0f, ui::ToColorA(ui::BORDER, 130));

    GP.chkAutostart.Draw(g);
    GP.chkTray.Draw(g);
    GP.chkNotifs.Draw(g);
    GP.chkAutoClean.Draw(g);

    RECT l1 = Fit(c, 0, GP.thrBar.top - 26, 0, 18);
    ui::DrawText(g, L"Авто-очистка при занятости:", l1, 12, ui::DIM, false, 0);

    ui::DrawShadow(g, (REAL)GP.thrBar.left, (REAL)GP.thrBar.top,
                   (REAL)(GP.thrBar.right - GP.thrBar.left),
                   (REAL)(GP.thrBar.bottom - GP.thrBar.top), 5, 20);
    ui::RoundedRect(g, (REAL)GP.thrBar.left, (REAL)GP.thrBar.top,
                    (REAL)(GP.thrBar.right - GP.thrBar.left), (REAL)(GP.thrBar.bottom - GP.thrBar.top),
                    5, true, Color(50, 40, 45, 60));
    int pct = GP.st.autoThreshold;
    int hx = GP.thrBar.left + (int)((double)(GP.thrBar.right - GP.thrBar.left) * pct / 100.0);
    ui::DrawBarHGlow(g, (REAL)GP.thrBar.left, (REAL)GP.thrBar.top,
                     (REAL)(GP.thrBar.right - GP.thrBar.left), (REAL)(GP.thrBar.bottom - GP.thrBar.top),
                     (double)pct / 100.0, ui::ToColor(ui::ACCENT));
    ui::DrawGlow(g, (REAL)GP.thrHandle.left, (REAL)GP.thrHandle.top,
                 (REAL)(GP.thrHandle.right - GP.thrHandle.left),
                 (REAL)(GP.thrHandle.bottom - GP.thrHandle.top),
                 8, Color(120, 96, 165, 250), 6.0f);
    ui::RoundedRectGradient(g, (REAL)GP.thrHandle.left, (REAL)GP.thrHandle.top,
                    (REAL)(GP.thrHandle.right - GP.thrHandle.left),
                    (REAL)(GP.thrHandle.bottom - GP.thrHandle.top),
                    8, Color(255, 52, 211, 153), Color(255, 34, 197, 94), true);
    ui::RoundedRect(g, (REAL)GP.thrHandle.left, (REAL)GP.thrHandle.top,
                    (REAL)(GP.thrHandle.right - GP.thrHandle.left),
                    (REAL)(GP.thrHandle.bottom - GP.thrHandle.top),
                    8, false, Color(), 1.0f, Color(180, 255, 255, 255));
    ui::DrawLine(g, (REAL)GP.thrHandle.left + 4, (REAL)GP.thrHandle.top + 2,
                 (REAL)GP.thrHandle.right - 4, (REAL)GP.thrHandle.top + 2,
                 Color(180, 255, 255, 255), 1.5f);
    RECT l2 = Fit(c, GP.thrBar.right + 18, GP.thrBar.top - 10, 60, 28);
    ui::DrawText(g, std::to_wstring(pct) + L"%", l2, 15, ui::GREEN, true, 0);

    RECT sLab = Fit(c, 0, GP.editSchedRc.top, 0, 28);
    sLab.right = GP.editSchedRc.left - 10;
    ui::DrawText(g, L"Время (HH:MM):", sLab, 12, ui::DIM, false, 2);

    RECT hLab = Fit(c, 0, GP.editHotkeyRc.top, 0, 28);
    hLab.right = GP.editHotkeyRc.left - 10;
    ui::DrawText(g, L"Горячая клавиша:", hLab, 12, ui::DIM, false, 2);

    RECT pLab = Fit(c, 0, GP.editAddProtRc.top, 0, 28);
    pLab.right = GP.editAddProtRc.left - 10;
    ui::DrawText(g, L"Защищённые процессы:", pLab, 12, ui::DIM, false, 2);

    RECT name = Fit(c, GP.editAddProtRc.right + 10, GP.editAddProtRc.top, 0, 28);
    name.right = c.right - 20;
    std::wstring plist = L"—";
    if (!GP.st.customProtected.empty()) {
        plist = L"";
        for (size_t i = 0; i < GP.st.customProtected.size(); i++) {
            plist += GP.st.customProtected[i];
            if (i + 1 < GP.st.customProtected.size()) plist += L", ";
        }
    }
    ui::DrawText(g, plist, name, 12, ui::DIM, false, 0);
    GP.chkSched.Draw(g);
    GP.btnAddProt.Draw(g);
    GP.btnSaveSettings.Draw(g);
    GP.chkSimpleUi.Draw(g);
}

static void PaintTabContents(Graphics& g, RECT content) {
    switch (GP.tab) {
    case T_OVERVIEW: DrawOverview(g, content); break;
    case T_CLEAN:    DrawClean(g, content); break;
    case T_TEMP:     DrawTemp(g, content); break;
    case T_PROCS:    DrawProcs(g, content); break;
    case T_STREAM:   DrawStream(g, content); break;
    case T_SETTINGS: DrawSettings(g, content); break;
    }
}

// ------------------------------------------------------------------ caption
static void DrawCaption(Graphics& g, int W) {
    LinearGradientBrush cb(PointF(0, 0), PointF(0, (REAL)CAP_H),
                           Color(255, 26, 30, 38),
                           Color(255, 17, 19, 26));
    g.FillRectangle(&cb, 0.0f, 0.0f, (REAL)W, (REAL)CAP_H);

    // power glyph — ring with a gap at 12 o'clock and a stem through the gap
    {
        float cx = 20.0f, cy = 19.0f;
        ui::DrawCircle(g, cx, cy, 9.0f, true, Color(55, 96, 165, 250));
        Pen wp(Color(255, 243, 244, 246), 1.8f);
        wp.SetStartCap(LineCapRound);
        wp.SetEndCap(LineCapRound);
        g.DrawArc(&wp, cx - 5.5f, cy - 4.0f, 11.0f, 11.0f, 125.0f, 290.0f);
        g.DrawLine(&wp, cx, cy - 7.2f, cx, cy - 1.2f);
    }
    ui::DrawTextF(g, L"RamBoost Pro", 40.0f, 10.0f, 13.0f, ui::TEXT, true);

    auto capBtn = [&](RECT rc, bool hov, bool pr, int type) {
        Color bg;
        if (pr)        bg = Color(255, 34, 38, 48);
        else if (hov)  bg = type == 3 ? Color(255, 220, 53, 69) : Color(255, 40, 44, 56);
        else           bg = Color(0, 0, 0, 0);

        if (bg.GetAlpha() != 0) {
            ui::RoundedRect(g, (REAL)rc.left, (REAL)rc.top,
                            (REAL)(rc.right - rc.left), (REAL)(rc.bottom - rc.top),
                            6, true, bg);
        }

        Color lc = (hov || pr) ? Color(255, 255, 255) : ui::ToColor(ui::DIM);
        if (type == 3 && (hov || pr)) lc = Color(255, 255, 255);
        Pen pen(lc, 1.8f);
        pen.SetStartCap(LineCapRound);
        pen.SetEndCap(LineCapRound);
        float cx = (REAL)((rc.left + rc.right) / 2);
        float cy = (REAL)((rc.top + rc.bottom) / 2);

        switch (type) {
        case 1:
            g.DrawLine(&pen, cx - 7, cy, cx + 7, cy);
            break;
        case 2:
            if (GP.capMax) {
                g.DrawRectangle(&pen, (REAL)(cx - 2), (REAL)(cy - 5), (REAL)10, (REAL)10);
                g.DrawRectangle(&pen, (REAL)(cx - 6), (REAL)(cy - 9), (REAL)10, (REAL)10);
            } else {
                g.DrawRectangle(&pen, (REAL)(cx - 6), (REAL)(cy - 5), (REAL)12, (REAL)10);
            }
            break;
        case 3:
            g.DrawLine(&pen, cx - 7, cy - 7, cx + 7, cy + 7);
            g.DrawLine(&pen, cx + 7, cy - 7, cx - 7, cy + 7);
            break;
        }
    };

    capBtn(GP.capMinRc,   GP.capMinHov,   GP.capMinPr,   1);
    capBtn(GP.capMaxRc,   GP.capMaxHov,   GP.capMaxPr,   2);
    capBtn(GP.capCloseRc, GP.capCloseHov, GP.capClosePr, 3);
}

static void ToggleMaximize() {
    if (GP.capMax) {
        GP.capMax = false;
        RECT& r = GP.capRestoredRc;
        MoveWindow(GP.hwnd, r.left, r.top, r.right - r.left, r.bottom - r.top, TRUE);
    } else {
        GetWindowRect(GP.hwnd, &GP.capRestoredRc);
        RECT wa;
        SystemParametersInfoW(SPI_GETWORKAREA, 0, &wa, 0);
        GP.capMax = true;
        MoveWindow(GP.hwnd, wa.left, wa.top, wa.right - wa.left, wa.bottom - wa.top, TRUE);
    }
    ApplyLayout();
    InvalidateRect(GP.hwnd, nullptr, FALSE);
}

// ------------------------------------------------------------------ render
static void Render(HWND hwnd) {
    PAINTSTRUCT ps;
    HDC hdc = BeginPaint(hwnd, &ps);
    RECT c;
    GetClientRect(hwnd, &c);
    int W = c.right - c.left, H = c.bottom - c.top;
    HDC mdc = CreateCompatibleDC(hdc);
    HBITMAP bmp = CreateCompatibleBitmap(hdc, W, H);
    HGDIOBJ obOld = SelectObject(mdc, bmp);
    Graphics g(mdc);
    g.SetSmoothingMode(SmoothingModeAntiAlias);
    g.SetTextRenderingHint(TextRenderingHintClearTypeGridFit);
    g.SetInterpolationMode(InterpolationModeHighQualityBicubic);
    g.Clear(ui::ToColor(ui::BG));
    g.SetClip(RectF(0, 0, (REAL)W, (REAL)H));

    // Subtle background gradient
    LinearGradientBrush bgBr(PointF(0, 0), PointF(0, (REAL)H),
                             Color(255, 15, 16, 22),
                             Color(255, 10, 11, 16));
    g.FillRectangle(&bgBr, 0.0f, 0.0f, (REAL)W, (REAL)H);

    DrawCaption(g, W);

    // Tab buttons
    for (auto& b : GP.tabs) b.Draw(g);

    RECT content = Fit(c, 20, 96, c.right - 40, c.bottom - 116);
    PaintTabContents(g, content);

    // Context tooltip for action checkboxes
    if (GP.tipVisible && !GP.tipText.empty()) {
        HDC th = g.GetHDC();
        SIZE sz = ui::MeasureText(th, GP.tipText, 12, false);
        g.ReleaseHDC(th);
        int ttw = (sz.cx > 130 ? sz.cx : 130) + 28;
        if (ttw > W - 40) ttw = W - 40;
        int tth = sz.cy + 18;
        int tx = GP.tipPos.x, ty = GP.tipPos.y;
        if (tx + ttw > W - 16) tx = W - 16 - ttw;
        if (ty + tth > H - 16) ty = H - 16 - tth;
        if (tx < 16) tx = 16;
        if (ty < 16) ty = 16;
        ui::DrawShadow(g, (REAL)tx, (REAL)ty, (REAL)ttw, (REAL)tth, 8, 40);
        ui::RoundedRect(g, (REAL)tx, (REAL)ty, (REAL)ttw, (REAL)tth, 8, true, ui::ToColor(ui::CARD2));
        ui::RoundedRect(g, (REAL)tx, (REAL)ty, (REAL)ttw, (REAL)tth, 8, false, Color(),
                        1.0f, ui::ToColor(ui::BORDER));
        RECT tr = { tx + 14, ty + 4, tx + ttw - 14, ty + tth - 4 };
        ui::DrawText(g, GP.tipText, tr, 12, ui::TEXT, false, 0);
    }

    BitBlt(hdc, 0, 0, W, H, mdc, 0, 0, SRCCOPY);
    SelectObject(mdc, obOld);
    DeleteObject(bmp);
    DeleteDC(mdc);
EndPaint(hwnd, &ps);
}

// ------------------------------------------------------------------ actions

static void ShowBalloon(const std::wstring& title, const std::wstring& msg, bool err) {
    if (GP.streamOn && GP.st.disableNotifsInStream) return;
    NOTIFYICONDATAW n = {};
    n.cbSize = sizeof(n);
    n.hWnd = GP.hwnd;
    n.uID = 1;
    n.uFlags = NIF_INFO;
    n.dwInfoFlags = err ? NIIF_ERROR : NIIF_INFO;
    wcscpy_s(n.szInfoTitle, 64, title.c_str());
    wcscpy_s(n.szInfo, 256, msg.c_str());
    Shell_NotifyIconW(NIM_MODIFY, &n);
}

static void StartClean(bool confirmAggressive) {
    if (GP.cleaning.load()) return;
    if (confirmAggressive && GP.st.mode == CM_AGGRESSIVE) {
        int r = MessageBoxW(GP.hwnd,
            L"Выбран агрессивный режим очистки: будут выполнены глубокие операции "
            L"(полный сброс standby-списка, обрезка рабочих множеств и т.п.). "
            L"Это может на время замедлить систему.\n\nПродолжить?",
            L"Агрессивная очистка", MB_YESNO | MB_ICONWARNING | MB_DEFBUTTON2);
        if (r != IDYES) return;
    }
    GP.cleaning.store(true);
    GP.lastCleanTick = GetTickCount();
    ApplyLayout();
    InvalidateRect(GP.hwnd, nullptr, FALSE);

    CleanMode mode = GP.st.mode;
    bool actions[ACT_COUNT];
    memcpy(actions, GP.st.actions, sizeof(actions));
    std::vector<std::wstring> prot = BuiltinProtectedNames();
    for (auto& p : GP.st.customProtected) prot.push_back(p);

    std::thread([mode, actions, prot]() mutable {
        CleanReport r = RunClean(mode, actions, prot);
        GP.pendingReport = r;
        PostMessage(GP.hwnd, WM_CLEAN_DONE, 0, 0);
    }).detach();
}

static void CleanDone() {
    GP.cleaning.store(false);
    GP.report = GP.pendingReport;
    GP.hasClean = true;
    GP.lastCleanBefore = GP.report.beforeAvail;
    GP.lastCleanDelta = GP.report.delta;
    if (GP.report.delta > 0) GP.sessionFreed += (uint64_t)GP.report.delta;
    GP.lastCleanDoneTick = GetTickCount();
    wchar_t buf[128];
    swprintf_s(buf, 128, L"Очистка завершена: освобождено %.2f ГБ", GP.report.delta / 1073741824.0);
    ShowBalloon(L"RamBoost Pro", buf, GP.report.delta <= 0);
    GP.snap = GetSnapshot();
    ApplyLayout();
    InvalidateRect(GP.hwnd, nullptr, FALSE);
}

static void StartScan() {
    if (GP.busyIo.load()) return;
    GP.busyIo.store(true);
    GP.busyMode.store(1);
    GP.deleteResult = 0; GP.deleteCount = 0; GP.deleteSkipped = 0; GP.deleteServiceIssue = false;
    InvalidateRect(GP.hwnd, nullptr, FALSE);
    auto p = std::make_shared<std::vector<CleanCategory>>();
    GP.tempPending = p;
    std::thread([p] {
        std::vector<CleanCategory> cats = BuildCategories();
        std::atomic<bool> cancel{false};
        ScanCategories(cats, &cancel, nullptr);
        *p = std::move(cats);
        PostMessage(GP.hwnd, WM_SCAN_DONE, 0, 0);
    }).detach();
}

static void ScanDone() {
    if (GP.tempPending) {
        GP.cats = std::move(*GP.tempPending);
        GP.tempPending.reset();
        GP.scannedTotal = 0;
        GP.scannedFiles = 0;
        GP.catChecked.assign(GP.cats.size(), 0);
        for (size_t i = 0; i < GP.cats.size(); i++) {
            GP.scannedTotal += GP.cats[i].size;
            GP.scannedFiles += GP.cats[i].count;
            GP.catChecked[i] = (GP.cats[i].canClean && !GP.cats[i].scanOnly) ? 1 : 0;
        }
        GP.scanned = true;
        GP.scrollTemp = 0;
    }
    GP.busyIo.store(false);
    GP.busyMode.store(0);
    ApplyLayout();
    InvalidateRect(GP.hwnd, nullptr, FALSE);
}

static void StartDelete() {
    if (GP.busyIo.load() || GP.cats.empty()) return;
    std::vector<CleanCategory> chosen;
    std::vector<int> idx;
    for (size_t i = 0; i < GP.cats.size() && i < GP.catChecked.size(); i++) {
        if (!GP.catChecked[i]) continue;
        if (!GP.cats[i].canClean || GP.cats[i].scanOnly) continue;
        chosen.push_back(GP.cats[i]);
        idx.push_back((int)i);
    }
    if (chosen.empty()) return;

    if (!IsElevated()) {
        bool needAdmin = false;
        for (auto& c : chosen) if (c.requiresAdmin) { needAdmin = true; break; }
        if (needAdmin) {
            int ans = MessageBoxW(GP.hwnd,
                L"Для полной очистки выбранных системных категорий требуются права администратора.\n\n"
                L"Перезапустить программу с правами администратора?",
                L"RamBoost Pro", MB_YESNO | MB_ICONQUESTION);
            if (ans != IDYES) return;
            wchar_t exe[MAX_PATH];
            HINSTANCE rc = nullptr;
            if (GetModuleFileNameW(nullptr, exe, MAX_PATH))
                rc = ShellExecuteW(GP.hwnd, L"runas", exe, L"", L"", SW_SHOWNORMAL);
            if ((INT_PTR)rc > 32) {
                PostMessageW(GP.hwnd, WM_CLOSE, 0, 0);
                return;
            }
            int ans2 = MessageBoxW(GP.hwnd,
                L"Не удалось перезапустить с правами администратора\n"
                L"(возможно, отключён контроль учётных записей UAC).\n\n"
                L"Удалить только пользовательские категории, доступные сейчас?",
                L"RamBoost Pro", MB_YESNO | MB_ICONWARNING);
            if (ans2 != IDYES) return;
            std::vector<CleanCategory> keep;
            std::vector<int> keepIdx;
            for (size_t i = 0; i < chosen.size(); i++) {
                if (chosen[i].requiresAdmin) continue;
                keep.push_back(std::move(chosen[i]));
                keepIdx.push_back(idx[i]);
            }
            chosen.swap(keep);
            idx.swap(keepIdx);
            if (chosen.empty()) {
                MessageBoxW(GP.hwnd,
                    L"Без прав администратора удалять нечего: выбраны только системные категории.",
                    L"RamBoost Pro", MB_OK | MB_ICONINFORMATION);
                return;
            }
        }
    }

    GP.busyIo.store(true);
    GP.busyMode.store(2);
    auto job = std::make_shared<PendingDeleteData>();
    job->cats = std::move(chosen);
    job->idx = std::move(idx);
    GP.pendingDelete = job;
    InvalidateRect(GP.hwnd, nullptr, FALSE);
    std::thread([job] {
        std::atomic<bool> cancel{false};
        job->r = CleanCategories(job->cats, &cancel, nullptr);
        ScanCategories(job->cats, &cancel, nullptr);
        PostMessage(GP.hwnd, WM_DELETE_DONE, 0, 0);
    }).detach();
}

static void DeleteDone() {
    GP.busyIo.store(false);
    GP.busyMode.store(0);
    if (GP.pendingDelete) {
        GP.deleteResult      = GP.pendingDelete->r.removed;
        GP.deleteCount       = GP.pendingDelete->r.deleted;
        GP.deleteSkipped     = GP.pendingDelete->r.skipped;
        GP.deleteServiceIssue = GP.pendingDelete->r.serviceIssue;
        for (size_t k = 0; k < GP.pendingDelete->idx.size(); k++) {
            int idx = GP.pendingDelete->idx[k];
            if (idx >= 0 && idx < (int)GP.cats.size())
                GP.cats[idx] = GP.pendingDelete->cats[k];
        }
        GP.pendingDelete.reset();
    }
    GP.scannedTotal = 0;
    GP.scannedFiles = 0;
    for (size_t i = 0; i < GP.cats.size(); i++) {
        GP.scannedTotal += GP.cats[i].size;
        GP.scannedFiles += GP.cats[i].count;
    }
    ApplyLayout();
    if (GP.deleteServiceIssue) {
        ShowBalloon(L"RamBoost Pro",
                    L"Очистка завершена, но службы Windows не удалось вернуть в исходное состояние.", true);
    } else {
        wchar_t buf[200];
        swprintf_s(buf, 200, L"Освобождено: %s · Удалено файлов: %d · Пропущено: %d"
                             L"%s", FormatBytes(GP.deleteResult).c_str(), GP.deleteCount,
                   GP.deleteSkipped, GP.deleteSkipped > 0
                       ? L" (часть файлов занята Windows)" : L"");
        ShowBalloon(L"RamBoost Pro", buf, GP.deleteSkipped > 0);
    }
    InvalidateRect(GP.hwnd, nullptr, FALSE);
}

static void RefreshProcs() {
    if (GP.procsPending) return;
    auto p = std::make_shared<std::vector<ProcInfo>>();
    GP.procsPending = p;
    Settings st = GP.st;
    std::thread([p, st] {
        std::vector<ProcInfo> v = GetTopProcesses(128);
        for (auto& pi : v) pi.isProtected = IsProtectedName(pi.name, st);
        *p = std::move(v);
        PostMessage(GP.hwnd, WM_PROCS_DONE, 0, 0);
    }).detach();
}

static void ProcsDone() {
    if (GP.procsPending) {
        GP.procs = std::move(*GP.procsPending);
        GP.procsPending.reset();
    }
    RebuildProcView();
    InvalidateRect(GP.hwnd, nullptr, FALSE);
}

static void RebuildProcView() {
    GP.procView.clear();
    if (GP.procFilter.empty()) {
        for (size_t i = 0; i < GP.procs.size(); i++) GP.procView.push_back((int)i);
    } else {
        std::wstring fLow;
        for (auto c : GP.procFilter) fLow += (wchar_t)towlower(c);
        for (size_t i = 0; i < GP.procs.size(); i++) {
            std::wstring nLow;
            for (auto c : GP.procs[i].name) nLow += (wchar_t)towlower(c);
            if (nLow.find(fLow) != std::wstring::npos) GP.procView.push_back((int)i);
        }
    }
    std::sort(GP.procView.begin(), GP.procView.end(),
        [](int a, int b) {
            if (GP.sortCol == 1) {
                if (GP.procs[a].pid != GP.procs[b].pid)
                    return GP.sortAsc ? GP.procs[a].pid < GP.procs[b].pid : GP.procs[a].pid > GP.procs[b].pid;
            } else if (GP.sortCol == 2) {
                int c = _wcsicmp(GP.procs[a].name.c_str(), GP.procs[b].name.c_str());
                if (c != 0) return GP.sortAsc ? c < 0 : c > 0;
            } else {
                if (GP.procs[a].ws != GP.procs[b].ws)
                    return GP.sortAsc ? GP.procs[a].ws > GP.procs[b].ws : GP.procs[a].ws < GP.procs[b].ws;
            }
            return a < b;
        });
    GP.selProc = -1;
}

static void ToggleStream() {
    GP.streamOn = !GP.streamOn;
    GP.lastStreamClean = 0;
    if (GP.streamOn) StartClean();
    ApplyLayout();
    InvalidateRect(GP.hwnd, nullptr, FALSE);
}

static void RegisterHotkeys() {
    int vk = HotkeyToVK(GP.st.hotkeyKey);
    UnregisterHotKey(GP.hwnd, 1);
    UnregisterHotKey(GP.hwnd, 2);
    if (vk) RegisterHotKey(GP.hwnd, 1, 0, (UINT)vk);
    RegisterHotKey(GP.hwnd, 2, MOD_CONTROL, VK_OEM_3);
}

// ------------------------------------------------------------------ events

static void OnClick(DWORD id) {
    if (id >= 200 && id < 200 + T_COUNT) {
        GP.tab = (int)(id - 200);
        GP.tipTarget = -1; GP.tipVisible = false;
        ApplyLayout();
        if (GP.tab == T_PROCS && GP.procView.empty()) RefreshProcs();
        InvalidateRect(GP.hwnd, nullptr, FALSE);
        return;
    }
    switch (id) {
    case 1: StartClean(true); break;
    case 2: ToggleStream(); break;
    case 3: StartClean(true); break;
    case 20: case 21: case 22:
        GP.st.mode = (CleanMode)(id - 20);
        ApplyLayout();
        InvalidateRect(GP.hwnd, nullptr, FALSE);
        break;
    case 40: case 41: if (id == 40) StartScan(); else StartDelete(); break;
    case 68: {
        wchar_t exe[MAX_PATH];
        if (GetModuleFileNameW(nullptr, exe, MAX_PATH)) {
            ShellExecuteW(GP.hwnd, L"runas", exe, L"", L"", SW_SHOWNORMAL);
            PostMessageW(GP.hwnd, WM_CLOSE, 0, 0);
        }
        break;
    }
    case 66:
        for (size_t i = 0; i < GP.catChecked.size() && i < GP.cats.size(); i++)
            GP.catChecked[i] = (GP.cats[i].canClean && !GP.cats[i].scanOnly) ? 1 : 0;
        InvalidateRect(GP.hwnd, nullptr, FALSE);
        break;
    case 67:
        for (size_t i = 0; i < GP.catChecked.size(); i++) GP.catChecked[i] = 0;
        InvalidateRect(GP.hwnd, nullptr, FALSE);
        break;
    case 50: RefreshProcs(); break;
    case 51: case 302: {
        if (GP.selProc >= 0 && GP.selProc < (int)GP.procView.size()) {
            int idx = GP.procView[GP.selProc];
            SetProcPriority(GP.procs[idx].pid, HIGH_PRIORITY_CLASS);
            ShowBalloon(L"RamBoost Pro", L"Приоритет повышен", false);
        }
        break;
    }
    case 52: case 301: {
        if (GP.selProc >= 0 && GP.selProc < (int)GP.procView.size()) {
            ProcInfo& p = GP.procs[GP.procView[GP.selProc]];
            if (p.isProtected) {
                ShowBalloon(L"RamBoost Pro", L"Процесс защищён", true);
            } else {
                wchar_t msg[256];
                swprintf_s(msg, 256, L"Завершить процесс %s (PID %u)?", p.name.c_str(), p.pid);
                if (MessageBoxW(GP.hwnd, msg, L"RamBoost Pro", MB_YESNO | MB_ICONQUESTION) == IDYES) {
                    HANDLE h = OpenProcess(PROCESS_TERMINATE, FALSE, p.pid);
                    if (h) { TerminateProcess(h, 1); CloseHandle(h); }
                    RefreshProcs();
                }
            }
        }
        break;
    }
    case 303: {
        if (GP.selProc >= 0 && GP.selProc < (int)GP.procView.size()) {
            const ProcInfo& p = GP.procs[GP.procView[GP.selProc]];
            bool dup = false;
            for (auto& c : GP.st.customProtected)
                if (_wcsicmp(c.c_str(), p.name.c_str()) == 0) { dup = true; break; }
            if (!dup) {
                GP.st.customProtected.push_back(p.name);
                ShowBalloon(L"RamBoost Pro", p.name + L" добавлен в защищённые", false);
            }
            InvalidateRect(GP.hwnd, nullptr, FALSE);
        }
        break;
    }
    case 60: {
        wchar_t buf[128] = {};
        GetWindowTextW(GP.hEditAddApp, buf, 128);
        if (buf[0] && std::find(GP.st.closeApps.begin(), GP.st.closeApps.end(), buf) == GP.st.closeApps.end())
            GP.st.closeApps.push_back(buf);
        SetWindowTextW(GP.hEditAddApp, L"");
        InvalidateRect(GP.hwnd, nullptr, FALSE);
        break;
    }
    case 61: {
        wchar_t buf[128] = {};
        GetWindowTextW(GP.hEditAddBoost, buf, 128);
        if (buf[0] && std::find(GP.st.highPrioApps.begin(), GP.st.highPrioApps.end(), buf) == GP.st.highPrioApps.end())
            GP.st.highPrioApps.push_back(buf);
        SetWindowTextW(GP.hEditAddBoost, L"");
        InvalidateRect(GP.hwnd, nullptr, FALSE);
        break;
    }
    case 62:
        for (auto& app : GP.st.closeApps) CloseProcByName(app, 900);
        ShowBalloon(L"RamBoost Pro", L"Фоновые приложения закрыты", false);
        break;
    case 63: {
        int boosted = BoostPriorities(GP.st.highPrioApps);
        ShowBalloon(L"RamBoost Pro", L"Буст применён: " + std::to_wstring(boosted) + L" процессов", false);
        break;
    }
    case 64: {
        wchar_t buf[128] = {};
        GetWindowTextW(GP.hEditAddProt, buf, 128);
        if (buf[0]) GP.st.customProtected.push_back(buf);
        SetWindowTextW(GP.hEditAddProt, L"");
        InvalidateRect(GP.hwnd, nullptr, FALSE);
        break;
    }
    case 65: {
        wchar_t buf[128] = {};
        GetWindowTextW(GP.hEditHotkey, buf, 128);
        if (buf[0]) GP.st.hotkeyKey = buf;
        GetWindowTextW(GP.hEditSched, buf, 128);
        if (wcslen(buf) == 5) GP.st.schedTime = buf;
        GP.st.Save();
        GP.st.ApplyAutostart();
        RegisterHotkeys();
        GP.st.Load();
        ui::g_simpleUi = GP.st.simpleUi;
        SetWindowTextW(GP.hEditSched, GP.st.schedTime.c_str());
        SetWindowTextW(GP.hEditHotkey, GP.st.hotkeyKey.c_str());
        ShowBalloon(L"RamBoost Pro", L"Настройки сохранены", false);
        ApplyLayout();
        InvalidateRect(GP.hwnd, nullptr, FALSE);
        break;
    }
    default: break;
    }
}

static void OnToggle(DWORD id) {
    auto flip = [](ui::Check& ch) { ch.checked = !ch.checked; };
    switch (id) {
    case 70:
        GP.st.disableNotifsInStream = !GP.st.disableNotifsInStream;
        GP.chkStreamNotifs.checked = GP.st.disableNotifsInStream;
        break;
    case 80: { flip(GP.chkAutostart); GP.st.autostart = GP.chkAutostart.checked; break; }
    case 81: { flip(GP.chkTray); GP.st.minimizeToTray = GP.chkTray.checked; break; }
    case 82: { flip(GP.chkNotifs); GP.st.showNotifications = GP.chkNotifs.checked; break; }
    case 83: { flip(GP.chkAutoClean); GP.st.autoClean = GP.chkAutoClean.checked; break; }
    case 84: { flip(GP.chkSched); GP.st.scheduledEnabled = GP.chkSched.checked; break; }
    case 85: {
        flip(GP.chkSimpleUi);
        GP.st.simpleUi = GP.chkSimpleUi.checked;
        ui::g_simpleUi = GP.st.simpleUi;
        break;
    }
    default: {
        int ai = (int)id - 30;
        if (ai >= 0 && ai < ACT_COUNT) {
            GP.st.actions[ai] = !GP.st.actions[ai];
            for (auto& ch : GP.actionChecks) if (ch.id == id) ch.checked = GP.st.actions[ai];
        }
    } break;
    }
    InvalidateRect(GP.hwnd, nullptr, FALSE);
}

static std::vector<ui::Button*> ActiveButtons() {
    std::vector<ui::Button*> v;
    switch (GP.tab) {
    case T_OVERVIEW: v.push_back(&GP.btnCleanNow); v.push_back(&GP.btnStreamToggle); break;
    case T_CLEAN:
        for (auto& b : GP.modeBtns) v.push_back(&b);
        v.push_back(&GP.btnStartClean);
        break;
    case T_TEMP: v.push_back(&GP.btnScan); v.push_back(&GP.btnDelete);
        v.push_back(&GP.btnSelAll); v.push_back(&GP.btnSelNone);
        if (!IsElevated()) v.push_back(&GP.btnAdminRelaunch);
        break;
    case T_PROCS: v.push_back(&GP.btnRefresh); v.push_back(&GP.btnHigh); v.push_back(&GP.btnKill); break;
    case T_STREAM:
        v.push_back(&GP.btnStreamToggle);
        v.push_back(&GP.btnAddApp); v.push_back(&GP.btnAddBoost);
        v.push_back(&GP.btnCloseApps); v.push_back(&GP.btnApplyStream);
        break;
    case T_SETTINGS: v.push_back(&GP.btnAddProt); v.push_back(&GP.btnSaveSettings); break;
    }
    return v;
}

static std::vector<ui::Check*> ActiveChecks() {
    std::vector<ui::Check*> v;
    switch (GP.tab) {
    case T_CLEAN: for (auto& c : GP.actionChecks) v.push_back(&c); break;
    case T_STREAM: v.push_back(&GP.chkStreamNotifs); break;
    case T_SETTINGS:
        v.push_back(&GP.chkAutostart); v.push_back(&GP.chkTray);
        v.push_back(&GP.chkNotifs); v.push_back(&GP.chkAutoClean); v.push_back(&GP.chkSched);
        v.push_back(&GP.chkSimpleUi);
        break;
    }
    return v;
}

static void OnMouseMove(int x, int y) {
    bool anyHover = false;
    POINT p{ x, y };
    GP.capMinHov   = PtInRect(&GP.capMinRc,   p);
    GP.capMaxHov   = PtInRect(&GP.capMaxRc,   p);
    GP.capCloseHov = PtInRect(&GP.capCloseRc, p);
    if (GP.capMinHov || GP.capMaxHov || GP.capCloseHov) anyHover |= true;
    for (auto& b : GP.tabs) { b.hover = b.Hit(x, y); anyHover |= b.hover; }
    for (auto* b : ActiveButtons()) { b->hover = b->Hit(x, y); anyHover |= b->hover; }
    for (auto* c : ActiveChecks()) { c->hover = c->Hit(x, y); anyHover |= c->hover; }

    GP.sbTemp.hover = GP.sbTemp.HitTrack(x, y);
    GP.sbProcs.hover = GP.sbProcs.HitTrack(x, y);
    anyHover |= GP.sbTemp.hover || GP.sbProcs.hover;

    // Drag scrollbar thumbs
    if (GP.draggingSbTemp) {
        int p = GP.sbTemp.ComputePos(y);
        int maxPos = std::max(0, GP.sbTemp.total - GP.sbTemp.visible);
        if (p < 0) p = 0; if (p > maxPos) p = maxPos;
        if (p != GP.scrollTemp) { GP.scrollTemp = p; InvalidateRect(GP.hwnd, nullptr, FALSE); }
    }
    if (GP.draggingSbProcs) {
        int p = GP.sbProcs.ComputePos(y);
        int maxPos = std::max(0, GP.sbProcs.total - GP.sbProcs.visible);
        if (p < 0) p = 0; if (p > maxPos) p = maxPos;
        if (p != GP.scrollProcs) { GP.scrollProcs = p; InvalidateRect(GP.hwnd, nullptr, FALSE); }
    }

    // Hover rows
    int newHoverT = -1, newHoverP = -1;
    if (GP.tab == T_TEMP) {
        RECT rt = GP.listRc;
        int vis = GP.sbTemp.visible;
        int vidx = (y - rt.top - TEMP_TOP_OFF) / TEMP_ROW_H;
        if (vidx >= 0 && vidx < vis && (vidx + GP.scrollTemp) < (int)GP.tempRows.size() && PtInRect(&rt, p)) {
            int cat = GP.tempRows[vidx + GP.scrollTemp];
            if (cat >= 0) newHoverT = cat;
        }
    }
    if (GP.tab == T_PROCS) {
        RECT rt = GP.listRc;
        int rowH = 32, pad = 14, topOff = 40;
        int vis = std::max<int>(0, ((int)rt.bottom - (int)rt.top - topOff - pad) / rowH);
        int vidx = (y - rt.top - pad - topOff) / rowH;
        if (vidx >= 0 && vidx < vis && (vidx + GP.scrollProcs) < (int)GP.procView.size() && PtInRect(&rt, p))
            newHoverP = vidx + GP.scrollProcs;
    }
    if (newHoverT != GP.hoverTemp || newHoverP != GP.hoverProcs) {
        GP.hoverTemp = newHoverT;
        GP.hoverProcs = newHoverP;
        InvalidateRect(GP.hwnd, nullptr, FALSE);
    }
    anyHover |= (newHoverT >= 0 || newHoverP >= 0);

    SetCursor(LoadCursorW(nullptr, anyHover ? IDC_HAND : IDC_ARROW));

    int tipId = -1;
    if (GP.tab == T_CLEAN) {
        for (auto& ch : GP.actionChecks)
            if (ch.Hit(x, y)) { tipId = (int)ch.id; break; }
    }
    if (tipId != GP.tipTarget) {
        GP.tipTarget = tipId;
        GP.tipVisible = false;
        GP.tipHoverTick = GetTickCount();
    }
}

static void OnWheel(int delta, int x, int y) {
    if (GP.tab == T_TEMP || GP.tab == T_PROCS) {
        if (!PtInRect(&GP.listRc, POINT{ x, y })) return;
        if (GP.tab == T_TEMP) GP.scrollTemp -= delta / 120;
        else GP.scrollProcs -= delta / 120;
        InvalidateRect(GP.hwnd, nullptr, FALSE);
    }
}

// ------------------------------------------------------------------ window

static LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
    switch (msg) {
    case WM_CREATE: {
        GP.editBrush = CreateSolidBrush(ui::CARD);
        auto mkEdit = [&](int id) {
            HWND e = CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", L"",
                                     WS_CHILD | WS_TABSTOP | ES_AUTOHSCROLL,
                                     0, 0, 1, 1, hwnd, (HMENU)(INT_PTR)id, GetModuleHandleW(nullptr), nullptr);
            // Use custom font
            LOGFONTW lf{};
            lf.lfHeight = -14;
            lf.lfWeight = FW_NORMAL;
            wcscpy_s(lf.lfFaceName, LF_FACESIZE, L"Segoe UI");
            HFONT hf = CreateFontIndirectW(&lf);
            SendMessageW(e, WM_SETFONT, (WPARAM)hf, TRUE);
            // Subclass for dark theming (first edit captures the original proc)
            if (!GP.origEditProc)
                GP.origEditProc = (WNDPROC)SetWindowLongPtrW(e, GWLP_WNDPROC, (LONG_PTR)DarkEditProc);
            else
                SetWindowLongPtrW(e, GWLP_WNDPROC, (LONG_PTR)DarkEditProc);
            return e;
        };
        GP.hEditHotkey = mkEdit(101);
        GP.hEditSched = mkEdit(102);
        GP.hEditAddApp = mkEdit(103);
        GP.hEditAddBoost = mkEdit(104);
        GP.hEditAddProt = mkEdit(105);
        GP.hEditProcs = mkEdit(106);
        SetWindowTextW(GP.hEditHotkey, GP.st.hotkeyKey.c_str());
        SetWindowTextW(GP.hEditSched, GP.st.schedTime.c_str());
        RegisterHotkeys();
        GP.snap = GetSnapshot();
        RefreshProcs();
        ApplyLayout();
        SetTimer(hwnd, TIMER_MAIN, 1000, nullptr);
        return 0;
    }
    case WM_ERASEBKGND: return 1;
    case WM_NCCALCSIZE:
        return 0;
    case WM_NCPAINT:
        return 0;
    case WM_SIZE:
        ApplyLayout();
        InvalidateRect(hwnd, nullptr, FALSE);
        return 0;
    case WM_EXITSIZEMOVE: SaveWindowPos(); return 0;
    case WM_PAINT: {
        Render(hwnd);
        return 0;
    }
    case WM_LBUTTONDOWN: {
        int x = GET_X_LPARAM(lp), y = GET_Y_LPARAM(lp);
        POINT p{ x, y };
        GP.tipVisible = false;
        GP.capMinPr   = PtInRect(&GP.capMinRc,   p);
        GP.capMaxPr   = PtInRect(&GP.capMaxRc,   p);
        GP.capClosePr = PtInRect(&GP.capCloseRc, p);
        if (GP.capMinPr || GP.capMaxPr || GP.capClosePr) {
            InvalidateRect(hwnd, nullptr, FALSE);
            return 0;
        }
        GP.draggingThr = GP.tab == T_SETTINGS && PtInRect(&GP.thrBar, POINT{ x, y });
        // Scrollbar thumbs
        GP.draggingSbTemp = GP.tab == T_TEMP && GP.sbTemp.HitThumb(x, y);
        GP.draggingSbProcs = GP.tab == T_PROCS && GP.sbProcs.HitThumb(x, y);
        // Scrollbar track click (page scroll)
        if (!GP.draggingSbTemp && GP.tab == T_TEMP && GP.sbTemp.HitTrack(x, y)) {
            int vis = std::max(1, GP.sbTemp.visible / 2);
            if (y < GP.sbTemp.thumbRc.top) GP.scrollTemp = std::max(0, GP.scrollTemp - vis);
            else GP.scrollTemp = std::min(std::max(0, GP.sbTemp.total - GP.sbTemp.visible), GP.scrollTemp + vis);
            ApplyLayout();
            InvalidateRect(hwnd, nullptr, FALSE);
        }
        if (!GP.draggingSbProcs && GP.tab == T_PROCS && GP.sbProcs.HitTrack(x, y)) {
            int vis = std::max(1, GP.sbProcs.visible / 2);
            if (y < GP.sbProcs.thumbRc.top) GP.scrollProcs = std::max(0, GP.scrollProcs - vis);
            else GP.scrollProcs = std::min(std::max(0, GP.sbProcs.total - GP.sbProcs.visible), GP.scrollProcs + vis);
            ApplyLayout();
            InvalidateRect(hwnd, nullptr, FALSE);
        }
        if (GP.draggingSbTemp) GP.sbTemp.pressed = true;
        if (GP.draggingSbProcs) GP.sbProcs.pressed = true;

        if (GP.draggingThr) {
            int pct = (int)((double)(x - GP.thrBar.left) * 100.0 / (double)(GP.thrBar.right - GP.thrBar.left));
            if (pct < 40) pct = 40;
            if (pct > 95) pct = 95;
            if (pct != GP.st.autoThreshold) {
                GP.st.autoThreshold = pct;
                ApplyLayout();
                InvalidateRect(hwnd, nullptr, FALSE);
            }
            SetCapture(hwnd);
        } else if (GP.draggingSbTemp || GP.draggingSbProcs) {
            SetCapture(hwnd);
        } else {
            bool hit = false;
            for (auto& b : GP.tabs) if (b.Hit(x, y)) { b.pressed = true; hit = true; }
            for (auto* b : ActiveButtons()) if (b->Hit(x, y)) { b->pressed = true; hit = true; }
            for (auto* c : ActiveChecks()) if (c->Hit(x, y)) { c->pressed = true; hit = true; }
            if (hit) InvalidateRect(hwnd, nullptr, FALSE);
        }
        return 0;
    }
    case WM_MOUSEMOVE: {
        int x = GET_X_LPARAM(lp), y = GET_Y_LPARAM(lp);
        if (GP.draggingThr) {
            int pct = (int)((double)(x - GP.thrBar.left) * 100.0 / (double)(GP.thrBar.right - GP.thrBar.left));
            if (pct < 40) pct = 40;
            if (pct > 95) pct = 95;
            if (pct != GP.st.autoThreshold) {
                GP.st.autoThreshold = pct;
                ApplyLayout();
                InvalidateRect(hwnd, nullptr, FALSE);
            }
        } else {
            OnMouseMove(x, y);
        }
        return 0;
    }
    case WM_LBUTTONUP: {
        int x = GET_X_LPARAM(lp), y = GET_Y_LPARAM(lp);
        POINT p{ x, y };
        if (GP.capMinPr || GP.capMaxPr || GP.capClosePr) {
            bool min   = GP.capMinPr   && PtInRect(&GP.capMinRc,   p);
            bool max   = GP.capMaxPr   && PtInRect(&GP.capMaxRc,   p);
            bool close = GP.capClosePr && PtInRect(&GP.capCloseRc, p);
            GP.capMinPr = GP.capMaxPr = GP.capClosePr = false;
            if (close) PostMessageW(hwnd, WM_CLOSE, 0, 0);
            else if (max) ToggleMaximize();
            else if (min) ShowWindow(hwnd, SW_MINIMIZE);
            InvalidateRect(hwnd, nullptr, FALSE);
            return 0;
        }
        bool dragActive = GP.draggingThr || GP.draggingSbTemp || GP.draggingSbProcs;
        if (GP.draggingThr) { GP.draggingThr = false; ReleaseCapture(); }
        if (GP.draggingSbTemp) { GP.draggingSbTemp = false; GP.sbTemp.pressed = false; ReleaseCapture(); ApplyLayout(); }
        if (GP.draggingSbProcs) { GP.draggingSbProcs = false; GP.sbProcs.pressed = false; ReleaseCapture(); ApplyLayout(); }
        if (dragActive) { InvalidateRect(hwnd, nullptr, FALSE); return 0; }
        // Reset pressed states
        for (auto& b : GP.tabs) b.pressed = false;
        for (auto* b : ActiveButtons()) b->pressed = false;
        for (auto* c : ActiveChecks()) c->pressed = false;
        // Handle clicks
        for (auto& b : GP.tabs) if (b.Hit(x, y)) { OnClick(b.id); return 0; }
        for (auto* b : ActiveButtons()) if (b->Hit(x, y)) { OnClick(b->id); return 0; }
        for (auto* c : ActiveChecks()) if (c->Hit(x, y)) { OnToggle(c->id); return 0; }
        if (GP.tab == T_TEMP) {
            RECT rt = GP.listRc;
            int vis = GP.sbTemp.visible;
            int vidx = (y - rt.top - TEMP_TOP_OFF) / TEMP_ROW_H;
            int ridx = vidx + GP.scrollTemp;
            if (vidx >= 0 && ridx >= 0 && ridx < (int)GP.tempRows.size()) {
                int cat = GP.tempRows[ridx];
                if (cat >= 0 && cat < (int)GP.cats.size() && GP.cats[cat].canClean && !GP.cats[cat].scanOnly) {
                    RECT hit = { rt.left + 4,
                                 rt.top + TEMP_TOP_OFF + vidx * TEMP_ROW_H,
                                 rt.right - 150,
                                 rt.top + TEMP_TOP_OFF + (vidx + 1) * TEMP_ROW_H };
                    if (PtInRect(&hit, POINT{ x, y })) {
                        GP.catChecked[cat] = GP.catChecked[cat] ? 0 : 1;
                        InvalidateRect(hwnd, nullptr, FALSE);
                    }
                }
                return 0;
            }
        }
        if (GP.tab == T_PROCS) {
            POINT p{ x, y };
            if (PtInRect(&GP.hdrPid, p) || PtInRect(&GP.hdrRam, p) || PtInRect(&GP.hdrName, p)) {
                int col = PtInRect(&GP.hdrPid, p) ? 1 : (PtInRect(&GP.hdrRam, p) ? 0 : 2);
                if (col == GP.sortCol) GP.sortAsc = !GP.sortAsc;
                else { GP.sortCol = col; GP.sortAsc = true; }
                RebuildProcView();
                InvalidateRect(hwnd, nullptr, FALSE);
                return 0;
            }
            RECT rt = GP.listRc;
            int rowH = 32, pad = 14, topOff = 40;
            int vis = (rt.bottom - rt.top - topOff) / rowH;
            if (vis < 0) vis = 0;
            int vidx = (y - rt.top - pad - topOff) / rowH + GP.scrollProcs;
            if (vidx >= 0 && vidx < (int)GP.procView.size()) {
                GP.selProc = vidx;
                InvalidateRect(hwnd, nullptr, FALSE);
                return 0;
            }
        }
        return 0;
    }
    case WM_RBUTTONUP: {
        int x = GET_X_LPARAM(lp), y = GET_Y_LPARAM(lp);
        if (GP.tab == T_PROCS && PtInRect(&GP.listRc, POINT{ x, y })) {
            int rowH = 32, pad = 14, topOff = 40;
            int vidx = (y - GP.listRc.top - pad - topOff) / rowH + GP.scrollProcs;
            if (vidx >= 0 && vidx < (int)GP.procView.size()) {
                GP.selProc = vidx;
                InvalidateRect(hwnd, nullptr, FALSE);
                HMENU m = CreatePopupMenu();
                AppendMenuW(m, MF_STRING, 301, L"Завершить процесс");
                AppendMenuW(m, MF_STRING, 302, L"Приоритет High");
                AppendMenuW(m, MF_STRING, 303, L"Добавить в защищённые");
                POINT p{ x, y };
                ClientToScreen(hwnd, &p);
                int cmd = TrackPopupMenu(m, TPM_RETURNCMD | TPM_NONOTIFY | TPM_RIGHTBUTTON,
                                         p.x, p.y, 0, hwnd, nullptr);
                DestroyMenu(m);
                if (cmd == 301 || cmd == 302 || cmd == 303) OnClick((DWORD)cmd);
            }
        }
        return 0;
    }
    case WM_GETMINMAXINFO: {
        MINMAXINFO* mmi = (MINMAXINFO*)lp;
        mmi->ptMinTrackSize.x = 800;
        mmi->ptMinTrackSize.y = 550;
        return 0;
    }
    case WM_NCHITTEST: {
        POINT sp{ GET_X_LPARAM(lp), GET_Y_LPARAM(lp) };
        POINT cp = sp;
        ScreenToClient(hwnd, &cp);
        if (cp.y >= 0 && cp.y < CAP_H &&
            !PtInRect(&GP.capMinRc, cp) && !PtInRect(&GP.capMaxRc, cp) && !PtInRect(&GP.capCloseRc, cp))
            return GP.capMax ? HTCLIENT : HTCAPTION;
        if (GP.capMax) return HTCLIENT;
        RECT w;
        GetWindowRect(hwnd, &w);
        const int b = 6;
        bool L = sp.x < w.left + b, Rc = sp.x >= w.right - b;
        bool Tp = sp.y < w.top + b, Bm = sp.y >= w.bottom - b;
        if (Tp && L) return HTTOPLEFT;    if (Tp && Rc) return HTTOPRIGHT;
        if (Bm && L) return HTBOTTOMLEFT; if (Bm && Rc) return HTBOTTOMRIGHT;
        if (Tp) return HTTOP;             if (Bm) return HTBOTTOM;
        if (L)  return HTLEFT;            if (Rc) return HTRIGHT;
        return HTCLIENT;
    }
    case WM_COMMAND:
        if (LOWORD(wp) == 106 && HIWORD(wp) == EN_CHANGE) {
            wchar_t buf[64];
            GetWindowTextW(GP.hEditProcs, buf, 64);
            GP.procFilter = buf;
            RebuildProcView();
            InvalidateRect(hwnd, nullptr, FALSE);
        }
        return 0;
    case WM_MOUSEWHEEL: {
        POINT pt{ GET_X_LPARAM(lp), GET_Y_LPARAM(lp) };
        ScreenToClient(hwnd, &pt);
        OnWheel((short)HIWORD(wp), pt.x, pt.y);
        return 0;
    }
    case WM_TIMER: {
        if (wp == TIMER_MAIN) {
            GP.snap = GetSnapshot();
            UpdateTrayTip();
            GP.hist[GP.histIdx] = (float)GP.snap.usagePct;
            GP.histIdx = (GP.histIdx + 1) % 60;
            if (GP.histCount < 60) GP.histCount++;
            UpdateTrayIcon();
            if (GP.tipTarget >= 0 && !GP.tipVisible &&
                GetTickCount() - GP.tipHoverTick > 600) {
                int ti = GP.tipTarget - 30;
                if (ti >= 0 && ti < ACT_COUNT) GP.tipText = ACTION_TOOLTIPS[ti];
                for (auto& ch : GP.actionChecks)
                    if ((int)ch.id == GP.tipTarget) {
                        GP.tipPos.x = ch.rc.left;
                        GP.tipPos.y = ch.rc.bottom + 8;
                        break;
                    }
                GP.tipVisible = true;
            } else if (GP.tipTarget < 0) {
                GP.tipVisible = false;
            }
            SYSTEMTIME lt;
            GetLocalTime(&lt);
            int todayKey = lt.wYear * 10000 + lt.wMonth * 100 + lt.wDay;
            if (todayKey != GP.lastCleanDayKey) GP.cleanedToday = false;
            if (GP.st.scheduledEnabled && !GP.cleanedToday) {
                int hh = _wtoi(GP.st.schedTime.c_str());
                int mm = _wtoi(GP.st.schedTime.c_str() + 3);
                int nowMin = lt.wHour * 60 + lt.wMinute;
                int schedMin = hh * 60 + mm;
                if (nowMin >= schedMin && nowMin < schedMin + 10) {
                    GP.cleanedToday = true;
                    GP.lastCleanDayKey = todayKey;
                    StartClean();
                }
            }
            if (GP.st.autoClean && !GP.cleaning.load()) {
                DWORD now = GetTickCount();
                if (now - GP.lastCleanTick > 45000 &&
                    GP.snap.usagePct >= GP.st.autoThreshold) {
                    StartClean();
                }
            }
            if (GP.streamOn && !GP.cleaning.load()) {
                DWORD now = GetTickCount();
                if (now - GP.lastStreamClean > 90000) {
                    GP.lastStreamClean = now;
                    StartClean();
                }
            }
            if (GP.tab == T_OVERVIEW && GP.pressureRow.right > GP.pressureRow.left) {
                RECT wr; GetClientRect(hwnd, &wr);
                int needH = StatusNeedsTwoLines(wr.right - 40) ? 46 : 28;
                int curH = GP.pressureRow.bottom - GP.pressureRow.top;
                if (curH != needH) ApplyLayout();
            }
            InvalidateRect(hwnd, nullptr, FALSE);
        }
        return 0;
    }
    case WM_HOTKEY:
        if (wp == 1) StartClean(true);
        else if (wp == 2) {
            if (IsWindowVisible(hwnd) && !IsIconic(hwnd)) ShowWindow(hwnd, SW_HIDE);
            else {
                if (IsIconic(hwnd)) ShowWindow(hwnd, SW_RESTORE);
                ShowWindow(hwnd, SW_SHOW);
                SetForegroundWindow(hwnd);
            }
        }
        return 0;
    case WM_CLEAN_DONE: CleanDone(); return 0;
    case WM_SCAN_DONE: ScanDone(); return 0;
    case WM_DELETE_DONE: DeleteDone(); return 0;
    case WM_PROCS_DONE: ProcsDone(); return 0;
    case WM_CTLCOLOREDIT: case WM_CTLCOLORSTATIC: {
        HDC hdc = (HDC)wp;
        SetBkColor(hdc, ui::CARD);
        SetTextColor(hdc, ui::TEXT);
        return (LRESULT)GP.editBrush;
    }
    case WM_TRAY: {
        if (lp == WM_LBUTTONDBLCLK || lp == WM_LBUTTONUP) {
            ShowWindow(hwnd, SW_SHOW);
            SetForegroundWindow(hwnd);
        } else if (lp == WM_RBUTTONUP) {
            HMENU m = CreatePopupMenu();
            AppendMenuW(m, MF_STRING, IDM_TRAY_OPEN, L"Открыть");
            AppendMenuW(m, MF_STRING, IDM_TRAY_CLEAN, L"Очистить сейчас");
            AppendMenuW(m, MF_SEPARATOR, 0, nullptr);
            AppendMenuW(m, MF_STRING, IDM_TRAY_EXIT, L"Выход");
            POINT p;
            GetCursorPos(&p);
            SetForegroundWindow(hwnd);
            int cmd = TrackPopupMenu(m, TPM_RETURNCMD | TPM_NONOTIFY, p.x, p.y, 0, hwnd, nullptr);
            DestroyMenu(m);
            if (cmd == IDM_TRAY_OPEN) { ShowWindow(hwnd, SW_SHOW); SetForegroundWindow(hwnd); }
            else if (cmd == IDM_TRAY_CLEAN) StartClean(true);
            else if (cmd == IDM_TRAY_EXIT) { DestroyWindow(hwnd); }
        }
        return 0;
    }
    case WM_CLOSE:
        if (GP.st.minimizeToTray) {
            ShowWindow(hwnd, SW_HIDE);
        } else {
            DestroyWindow(hwnd);
        }
        return 0;
    case WM_DESTROY: {
        KillTimer(hwnd, TIMER_MAIN);
        UnregisterHotKey(hwnd, 1);
        NOTIFYICONDATAW n = {};
        n.cbSize = sizeof(n);
        n.hWnd = hwnd;
        n.uID = 1;
        Shell_NotifyIconW(NIM_DELETE, &n);
if (GP.editBrush) DeleteObject(GP.editBrush);
        if (GP.trayIcon) { DestroyIcon(GP.trayIcon); GP.trayIcon = nullptr; }
        if (!GP.selftestMode) { SaveWindowPos(); GP.st.Save(); }
        PostQuitMessage(0);
        return 0;
    }
    default:
        return DefWindowProcW(hwnd, msg, wp, lp);
    }
}

static void AddTrayIcon(HWND hwnd) {
    NOTIFYICONDATAW n = {};
    n.cbSize = sizeof(n);
    n.hWnd = hwnd;
    n.uID = 1;
    n.uFlags = NIF_ICON | NIF_MESSAGE | NIF_TIP;
    n.uCallbackMessage = WM_TRAY;
    n.hIcon = GP.icon;
    wcscpy_s(n.szTip, 128, L"RamBoost Pro");
    Shell_NotifyIconW(NIM_ADD, &n);
}

static void UpdateTrayTip() {
    NOTIFYICONDATAW n = {};
    n.cbSize = sizeof(n);
    n.hWnd = GP.hwnd;
    n.uID = 1;
    n.uFlags = NIF_TIP;
    swprintf_s(n.szTip, 128, L"RAM: %.2f / %.2f ГБ (%.0f%%)",
               GP.snap.availGB(), GP.snap.totalGB(), GP.snap.usagePct);
    Shell_NotifyIconW(NIM_MODIFY, &n);
}

static HICON MakeTrayIcon(COLORREF col) {
    HWND desk = GetDesktopWindow();
    HDC sdc = GetDC(desk);
    BITMAPINFO bi = {};
    bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bi.bmiHeader.biWidth = 32;
    bi.bmiHeader.biHeight = -32;
    bi.bmiHeader.biPlanes = 1;
    bi.bmiHeader.biBitCount = 32;
    bi.bmiHeader.biCompression = BI_RGB;
    void* bits = nullptr;
    HBITMAP dib = CreateDIBSection(sdc, &bi, DIB_RGB_COLORS, &bits, nullptr, 0);
    std::vector<BYTE> pix(32 * 32 * 4, 0);
    HICON h = nullptr;
    if (dib && bits) {
        HDC mdc = CreateCompatibleDC(sdc);
        HGDIOBJ ob = mdc ? SelectObject(mdc, dib) : nullptr;
        memset(bits, 0, 32 * 32 * 4);
        Gdiplus::Graphics g(mdc);
        g.SetSmoothingMode(SmoothingModeAntiAlias);
        g.Clear(Color(0, 0, 0, 0));
        Color c = ui::ToColor(col);
        if (!ui::g_simpleUi)
            ui::DrawGlow(g, 1.0f, 1.0f, 30.0f, 30.0f, 15.0f,
                         Color(90, GetRValue(col), GetGValue(col), GetBValue(col)), 4.0f);
        SolidBrush br(c);
        g.FillEllipse(&br, 3.0f, 3.0f, 26.0f, 26.0f);
        Pen hl(Color(150, 255, 255, 255), 2.0f);
        g.DrawArc(&hl, 8.0f, 7.0f, 16.0f, 12.0f, 200, 130);
        g.Flush();
        if (ob) SelectObject(mdc, ob);
        if (mdc) DeleteDC(mdc);
        memcpy(pix.data(), bits, pix.size());
        BYTE andm[32 * 32 / 8] = {};
        HBITMAP cbm = CreateBitmap(32, 32, 1, 32, pix.data());
        HBITMAP mbm = CreateBitmap(32, 32, 1, 1, andm);
        if (cbm && mbm) {
            ICONINFO ii = {};
            ii.fIcon = TRUE;
            ii.hbmColor = cbm;
            ii.hbmMask = mbm;
            h = CreateIconIndirect(&ii);
        }
        if (cbm) DeleteObject(cbm);
        if (mbm) DeleteObject(mbm);
    }
    if (dib) DeleteObject(dib);
    ReleaseDC(desk, sdc);
    return h;
}

static void UpdateTrayIcon() {
    DWORD key = GP.snap.usagePct > 85 ? 2 : GP.snap.usagePct > 60 ? 1 : 0;
    if (GP.trayIcon && key == GP.trayColKey) return;
    COLORREF col = key == 2 ? ui::RED : key == 1 ? ui::ORANGE : ui::GREEN;
    HICON ni = MakeTrayIcon(col);
    if (!ni) return;
    NOTIFYICONDATAW n = {};
    n.cbSize = sizeof(n);
    n.hWnd = GP.hwnd;
    n.uID = 1;
    n.uFlags = NIF_ICON;
    n.hIcon = ni;
    Shell_NotifyIconW(NIM_MODIFY, &n);
    if (GP.trayIcon) DestroyIcon(GP.trayIcon);
    GP.trayIcon = ni;
    GP.trayColKey = key;
}

static void SaveWindowPos() {
    if (!GP.hwnd || IsZoomed(GP.hwnd) || IsIconic(GP.hwnd) || GP.capMax) return;
    RECT r;
    if (!GetWindowRect(GP.hwnd, &r)) return;
    MONITORINFO mi = { sizeof(mi) };
    HMONITOR m = MonitorFromRect(&r, MONITOR_DEFAULTTONEAREST);
    if (GetMonitorInfoW(m, &mi)) {
        RECT inter;
        if (!IntersectRect(&inter, &mi.rcWork, &r)) return;
    }
    GP.st.winX = r.left; GP.st.winY = r.top;
    GP.st.winW = r.right - r.left; GP.st.winH = r.bottom - r.top;
}

static LRESULT CALLBACK DarkEditProc(HWND h, UINT m, WPARAM w, LPARAM l) {
    if (!GP.origEditProc) return DefWindowProcW(h, m, w, l);
    switch (m) {
    case WM_NCPAINT:
    case WM_PAINT: {
        LRESULT r = CallWindowProcW(GP.origEditProc, h, m, w, l);
        HDC hdc = GetWindowDC(h);
        if (hdc) {
            RECT rc; GetWindowRect(h, &rc);
            int w_ = rc.right - rc.left, h_ = rc.bottom - rc.top;
            HPEN pn = CreatePen(PS_INSIDEFRAME | PS_SOLID, 1, RGB(46, 50, 60));
            HPEN op = (HPEN)SelectObject(hdc, pn);
            HBRUSH ob = (HBRUSH)GetStockObject(NULL_BRUSH);
            HBRUSH sb = (HBRUSH)SelectObject(hdc, ob);
            Rectangle(hdc, 0, 0, w_, h_);
            SelectObject(hdc, sb); SelectObject(hdc, op);
            DeleteObject(pn);
            ReleaseDC(h, hdc);
        }
        return r;
    }
    case WM_SETFOCUS:
    case WM_KILLFOCUS: {
        LRESULT r = CallWindowProcW(GP.origEditProc, h, m, w, l);
        InvalidateRect(h, nullptr, TRUE);
        return r;
    }
    default:
        return CallWindowProcW(GP.origEditProc, h, m, w, l);
    }
}

static void EnsureOnScreen(int& x, int& y, int w, int h);

static void EnsureOnScreen(int& x, int& y, int w, int h) {
    struct Mon { RECT work; };
    std::vector<Mon> mons;
    EnumDisplayMonitors(nullptr, nullptr, [](HMONITOR hm, HDC, LPRECT, LPARAM lp) -> BOOL {
        MONITORINFO mi = { sizeof(mi) };
        if (GetMonitorInfoW(hm, &mi))
            ((std::vector<Mon>*)lp)->push_back({ mi.rcWork });
        return TRUE;
    }, (LPARAM)&mons);
    if (mons.empty()) {
        Mon m; RECT wa;
        if (SystemParametersInfoW(SPI_GETWORKAREA, 0, &wa, 0)) { m.work = wa; mons.push_back(m); }
    }
    RECT r{ x, y, x + w, y + h };
    RECT* best = nullptr;
    long bestArea = 0;
    for (auto& m : mons) {
        RECT inter;
        if (IntersectRect(&inter, &m.work, &r)) {
            long a = (long)(inter.right - inter.left) * (inter.bottom - inter.top);
            if (a > bestArea) { bestArea = a; best = &m.work; }
        }
    }
    if (!best) {
        RECT wa;
        if (SystemParametersInfoW(SPI_GETWORKAREA, 0, &wa, 0)) {
            x = wa.left + (wa.right - wa.left - w) / 2;
            y = wa.top + (wa.bottom - wa.top - h) / 2;
        } else { x = 40; y = 40; }
        return;
    }
    long full = (long)w * h;
    if (bestArea < full / 2) {
        POINT c = { x + w / 2, y + h / 2 };
        HMONITOR hm = MonitorFromPoint(c, MONITOR_DEFAULTTONEAREST);
        MONITORINFO mi = { sizeof(mi) };
        RECT wa;
        if (GetMonitorInfoW(hm, &mi)) wa = mi.rcWork;
        else if (!SystemParametersInfoW(SPI_GETWORKAREA, 0, &wa, 0)) wa = RECT{ 0, 0, 1280, 720 };
        x = wa.left + (wa.right - wa.left - w) / 2;
        y = wa.top + (wa.bottom - wa.top - h) / 2;
        return;
    }
    const int mw = 160, mh = 60;
    if (x + mw > best->right) x = best->right - mw;
    if (y + mh > best->bottom) y = best->bottom - mh;
    if (x < best->left - w + mw) x = best->left - w + mw;
    if (y < best->top - h + mh) y = best->top - h + mh;
}

// ------------------------------------------------------------------ selftest

static void ST_Log(HANDLE f, const wchar_t* s) {
    if (!f || f == INVALID_HANDLE_VALUE) return;
    DWORD w = (DWORD)(wcslen(s) * sizeof(wchar_t));
    WriteFile(f, s, w, &w, nullptr);
    const wchar_t nl[] = L"\r\n";
    DWORD nw = (DWORD)(sizeof(nl) - sizeof(wchar_t));
    WriteFile(f, nl, nw, &nw, nullptr);
}

static void ST_Note(HANDLE f, const wchar_t* fmt, ...) {
    wchar_t b[700];
    va_list ap;
    va_start(ap, fmt);
    vswprintf_s(b, 700, fmt, ap);
    va_end(ap);
    ST_Log(f, b);
}

static int ST_Phase(HANDLE f, const wchar_t* name, bool ok) {
    std::wstring s = name;
    s += ok ? L"  [OK]" : L"  [FAIL]";
    ST_Log(f, s.c_str());
    return ok ? 0 : 1;
}

static void ST_Click(HWND hwnd, int x, int y) {
    SendMessageW(hwnd, WM_MOUSEMOVE, 0, MAKELPARAM(x, y));
    SendMessageW(hwnd, WM_LBUTTONDOWN, MK_LBUTTON, MAKELPARAM(x, y));
    SendMessageW(hwnd, WM_LBUTTONUP, 0, MAKELPARAM(x, y));
}

static void ST_Pump(DWORD ms) {
    DWORD end = GetTickCount() + ms;
    while (GetTickCount() < end) {
        MSG msg;
        while (PeekMessageW(&msg, nullptr, 0, 0, PM_REMOVE)) {
            TranslateMessage(&msg);
            DispatchMessageW(&msg);
        }
        Sleep(5);
    }
}

static bool ST_HasArg(const wchar_t* flag) {
    int n = 0;
    LPWSTR* a = CommandLineToArgvW(GetCommandLineW(), &n);
    if (!a) return false;
    bool found = false;
    for (int i = 1; i < n; i++)
        if (_wcsicmp(a[i], flag) == 0) { found = true; break; }
    LocalFree(a);
    return found;
}

// ------------------------------------------------------------------ shot: UI preview renderer (visual check)

static void Shot_SaveWindow(HWND hwnd, const wchar_t* file) {
    RECT cr;
    GetClientRect(hwnd, &cr);
    int W = cr.right, H = cr.bottom;
    HDC sdc = GetDC(hwnd);
    HDC mdc = CreateCompatibleDC(sdc);
    HBITMAP bmp = CreateCompatibleBitmap(sdc, W, H);
    HGDIOBJ old = SelectObject(mdc, bmp);
    BitBlt(mdc, 0, 0, W, H, sdc, 0, 0, SRCCOPY);
    SelectObject(mdc, old);
    Gdiplus::Bitmap img(bmp, nullptr);
    CLSID png = { 0x557cf406, 0x1a04, 0x11d3, { 0x9a, 0x73, 0x00, 0x00, 0xf8, 0x1e, 0xf3, 0x2e } };
    img.Save(file, &png, nullptr);
    DeleteObject(bmp);
    DeleteDC(mdc);
    ReleaseDC(hwnd, sdc);
}

static void Shot_Repaint() {
    InvalidateRect(GP.hwnd, nullptr, FALSE);
    UpdateWindow(GP.hwnd);
}

// Full window capture including the actual on-screen rendering (which on
// some Windows versions includes a DWM non-client frame). Used to verify
// that no white system border is left on the window edges.
static void Shot_SaveFrame(HWND hwnd, const wchar_t* file) {
    RECT wr;
    GetWindowRect(hwnd, &wr);
    int W = wr.right - wr.left, H = wr.bottom - wr.top;
    HDC sdc = GetDC(nullptr);   // screen DC: what is actually on screen
    HDC mdc = CreateCompatibleDC(sdc);
    HBITMAP bmp = CreateCompatibleBitmap(sdc, W, H);
    HGDIOBJ old = SelectObject(mdc, bmp);
    BitBlt(mdc, 0, 0, W, H, sdc, wr.left, wr.top, SRCCOPY);
    SelectObject(mdc, old);
    Gdiplus::Bitmap img(bmp, nullptr);
    CLSID png = { 0x557cf406, 0x1a04, 0x11d3, { 0x9a, 0x73, 0x00, 0x00, 0xf8, 0x1e, 0xf3, 0x2e } };
    img.Save(file, &png, nullptr);
    DeleteObject(bmp);
    DeleteDC(mdc);
    ReleaseDC(nullptr, sdc);
}

static int ShotMain(HINSTANCE hInst) {
    GP.icon = (HICON)LoadImageW(hInst, MAKEINTRESOURCEW(IDI_APP), IMAGE_ICON, 32, 32, LR_DEFAULTCOLOR);
    if (!GP.icon) GP.icon = LoadIconW(nullptr, IDI_APPLICATION);
    GP.st.Load();
    ui::Init();
    ui::g_simpleUi = false;

    WNDCLASSW wc = {};
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInst;
    wc.hCursor = LoadCursorW(nullptr, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
    wc.lpszClassName = L"RamBoostProMain";
    wc.hIcon = GP.icon;
    RegisterClassW(&wc);

    RECT wa;
    SystemParametersInfoW(SPI_GETWORKAREA, 0, &wa, 0);

    // Stress values: long texts that must survive layout untouched
    GP.hasClean = true;
    GP.lastCleanDoneTick = GetTickCount() - 15000;   // "Только что"
    GP.lastCleanDelta = 60000000;                     // ~0.06 GB
    GP.sessionFreed = 2620000000ull;                  // ~2.62 GB
    GP.streamOn = false;

    // Clean-tab result panel stress content
    GP.lastCleanBefore = 12000000000ull;
    GP.lastCleanDelta = 660000000;
    {
        CleanReport r;
        auto add = [&](const wchar_t* n, int64_t d, int ms) {
            StepResult sr;
            sr.name = n; sr.ok = true; sr.deltaBytes = d; sr.ms = ms;
            r.steps.push_back(sr);
        };
        add(L"Working Sets процессов", 180000000, 300);
        add(L"Standby List (низк.)", 120000000, 250);
        add(L"Файловый кэш", 420000000, 300);
        add(L"Standby List (полная)", -20000000, 200);
        GP.report = r;
    }

    auto makeWindow = [&](int ww, int wh) {
        int wx = wa.left + (wa.right - wa.left - ww) / 2;
        int wy = wa.top + (wa.bottom - wa.top - wh) / 2;
        GP.hwnd = CreateWindowExW(WS_EX_APPWINDOW, L"RamBoostProMain", L"RamBoost Pro",
                                  WS_POPUP | WS_MINIMIZEBOX | WS_MAXIMIZEBOX,
                                  wx, wy, ww, wh, nullptr, nullptr, hInst, nullptr);
        GP.tab = T_OVERVIEW;
        ApplyLayout();
        ShowWindow(GP.hwnd, SW_SHOWNOACTIVATE);
        Shot_Repaint();
    };

    // Default window size
    makeWindow(1000, 700);
    Shot_SaveWindow(GP.hwnd, L"shot_overview.png");
    Shot_SaveFrame(GP.hwnd, L"shot_overview_frame.png");
    DestroyWindow(GP.hwnd);

    // Stretched (test that the bottom block redistributes, no empty gap)
    makeWindow(1300, 800);
    Shot_SaveWindow(GP.hwnd, L"shot_overview_wide.png");
    DestroyWindow(GP.hwnd);

    // Narrowest allowed size (min 800x550 in wWinMain)
    makeWindow(800, 550);
    Shot_SaveWindow(GP.hwnd, L"shot_overview_narrow.png");
    DestroyWindow(GP.hwnd);

    // Clean tab renders
    auto makeClean = [&](int ww, int wh, CleanMode m, const wchar_t* file) {
        GP.st.mode = m;
        makeWindow(ww, wh);
        GP.tab = T_CLEAN;
        ApplyLayout();
        Shot_Repaint();
        Shot_SaveWindow(GP.hwnd, file);
        DestroyWindow(GP.hwnd);
    };
    makeClean(1000, 700, CM_SMART,      L"shot_clean_smart.png");
    makeClean(1000, 700, CM_GENTLE,     L"shot_clean_gentle.png");
    makeClean(1000, 700, CM_AGGRESSIVE, L"shot_clean_aggressive.png");
    makeClean(1300, 800, CM_AGGRESSIVE, L"shot_clean_wide.png");
    makeClean(800, 550,  CM_SMART,      L"shot_clean_narrow.png");

    // Remaining tabs at three sizes each (title headers must stay visible)
    {
        struct TabShot { int tab; const wchar_t* base; };
        TabShot tabs[] = { { T_TEMP, L"shot_temp" }, { T_PROCS, L"shot_procs" },
                           { T_STREAM, L"shot_stream" }, { T_SETTINGS, L"shot_settings" } };
        struct Size { int w, h; const wchar_t* suf; };
        Size sizes[] = { { 1000, 700, L"" }, { 1300, 800, L"_wide" }, { 800, 550, L"_narrow" } };
        for (auto& ts : tabs) {
            for (auto& sz : sizes) {
                makeWindow(sz.w, sz.h);
                GP.tab = ts.tab;
                ApplyLayout();
                SetListPos();
                Shot_Repaint();
                Shot_SaveWindow(GP.hwnd, (std::wstring(ts.base) + sz.suf + L".png").c_str());
                DestroyWindow(GP.hwnd);
            }
        }
    }

    if (ST_HasArg(L"--kover")) {
        GP.cats = BuildCategories();
        auto snap = [&](int tab, const wchar_t* file) {
            makeWindow(1000, 700);
            GP.tab = tab;
            ApplyLayout();
            SetListPos();
            Shot_Repaint();
            Shot_SaveWindow(GP.hwnd, file);
            DestroyWindow(GP.hwnd);
        };
        GP.scanned = false; GP.busyMode.store(0);
        snap(T_TEMP, L"kverify_temp_prescan.png");
        GP.busyMode.store(1);
        snap(T_TEMP, L"kverify_temp_scanbusy.png");
        GP.busyMode.store(0);
        GP.scanned = true;
        GP.scannedTotal = 0; GP.scannedFiles = 0;
        for (auto& c : GP.cats) { GP.scannedTotal += c.size; GP.scannedFiles += c.count; }
        GP.catChecked.assign(GP.cats.size(), 1);
        snap(T_TEMP, L"kverify_temp_done.png");
        snap(T_CLEAN, L"kverify_clean.png");
        snap(T_PROCS, L"kverify_procs.png");
        snap(T_STREAM, L"kverify_stream.png");
        snap(T_SETTINGS, L"kverify_settings.png");
        GP.scanned = false; GP.busyMode.store(0);
    }

    ui::Shutdown();
    if (GP.icon) { DestroyIcon(GP.icon); GP.icon = nullptr; }
    return 0;
}

static int SelfTest(HINSTANCE hInst) {
    HANDLE log = CreateFileW(L"selftest.log", GENERIC_WRITE, FILE_SHARE_READ, nullptr,
                             CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
    int fails = 0;
    auto phase = [&](const wchar_t* n, bool ok) { fails += ST_Phase(log, n, ok); };
    auto center = [](RECT r) { return POINT{ r.left + (r.right - r.left) / 2,
                                              r.top + (r.bottom - r.top) / 2 }; };

    GP.selftestMode = true;

    // 01 resource icon
    HICON ico = (HICON)LoadImageW(hInst, MAKEINTRESOURCEW(IDI_APP), IMAGE_ICON, 32, 32, LR_DEFAULTCOLOR);
    phase(L"01 resource icon load", ico != nullptr);
    if (ico) DestroyIcon(ico);

    ui::Init();
    ui::g_simpleUi = false;

    // 02 offscreen GDI primitives
    {
        HDC sdc = GetDC(nullptr);
        HDC mdc = sdc ? CreateCompatibleDC(sdc) : nullptr;
        HBITMAP bmp = mdc ? CreateCompatibleBitmap(sdc, 1200, 900) : nullptr;
        HGDIOBJ old = bmp ? SelectObject(mdc, bmp) : nullptr;
        bool ok = (mdc && bmp);
        int bad = 0;
        if (ok) {
            Graphics g(mdc);
            g.SetSmoothingMode(SmoothingModeAntiAlias);
            for (int k = 0; k < 300 && bad == 0; k++) {
                float x = (float)((k * 53) % 1100);
                float y = (float)((k * 71) % 760);
                float w = 28.0f + (k % 14) * 8.0f;
                float h = 18.0f + (k % 11) * 6.0f;
                float r = 5.0f + (k % 8) * 3.0f;
                Color c((BYTE)((k * 13) & 255), (BYTE)((k * 7) & 255),
                        (BYTE)((k * 3 + 60) & 255), (BYTE)((k * 5 + 120) & 255));
                double pr = (double)(k % 100) / 100.0;
                ui::DrawShadow(g, x, y, w, h, r, 40);
                ui::DrawGlow(g, x, y, w, h, r, c, 4.0f);
                ui::RoundedRect(g, x, y, w, h, r, true, c);
                ui::RoundedRect(g, x, y, w, h, r, false, Color(), 2.0f, Color(255, 255, 255));
                ui::RoundedRectGradient(g, x, y, w, h, r, c, Color(40, 255, 255, 255), false);
                ui::DrawCircle(g, x + w / 2, y + h / 2, r, true, c);
                ui::DrawDonut(g, x + w / 2, y + h / 2, r + 6, 5, pr,
                              Color(40, 40, 45), c, c);
                ui::DrawBarH(g, x, y, w, 8, pr, c);
                ui::DrawBarHGlow(g, x, y, w, 8, pr, c);
                ui::DrawLine(g, x, y, x + w, y + h, c, 2.0f);
                ui::DrawCardTopLine(g, x, y, w, h, r, c, 3.0f);
                RECT rc = { (int)x, (int)y, (int)(x + w + 60), (int)(y + h) };
                ui::DrawText(g, L"Тест Ёё шрифта TtWwGg", rc, 12, ui::TEXT, false, 1);
                ui::DrawTextF(g, L"Текст-№123", x, y, 10, ui::TEXT, true);
                ui::DrawTextA(g, L"Текст-№123", x, y + 12, 10, c, false);
                SIZE sz = ui::MeasureText(mdc, L"Измерить строку WwТё", 12, true);
                if (sz.cx <= 0 || sz.cy <= 0) bad++;
            }
        }
        if (old) SelectObject(mdc, old);
        if (bmp) DeleteObject(bmp);
        if (mdc) DeleteDC(mdc);
        if (sdc) ReleaseDC(nullptr, sdc);
        phase(L"02 gdi primitives offscreen", ok && bad == 0);
    }

    // 03 font cache
    {
        int bad = 0;
        for (int i = 0; i < 24; i++)
            if (!ui::GetFont(8.0f + i * 0.5f, (i & 1) == 0)) bad++;
        // token check: round-trip measure at several sizes
        HDC sdc = GetDC(nullptr);
        (void)sdc;
        if (sdc) ReleaseDC(nullptr, sdc);
        phase(L"03 font cache + measure", bad == 0);
    }

    // window + interactivity
    GP.icon = (HICON)LoadImageW(hInst, MAKEINTRESOURCEW(IDI_APP), IMAGE_ICON, 32, 32, LR_DEFAULTCOLOR);
    if (!GP.icon) GP.icon = LoadIconW(nullptr, IDI_APPLICATION);
    phase(L"04 app icon for window class", GP.icon != nullptr);

    GP.st.Load();
    ui::g_simpleUi = GP.st.simpleUi;
    if (GP.st.closeApps.empty())
        GP.st.closeApps = { L"Telegram", L"Discord", L"Slack" };
    if (GP.st.highPrioApps.empty())
        GP.st.highPrioApps = { L"cs2", L"dota2" };

    WNDCLASSW wc = {};
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInst;
    wc.hCursor = LoadCursorW(nullptr, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
    wc.lpszClassName = L"RamBoostProMain";
    wc.hIcon = GP.icon;
    RegisterClassW(&wc);

    RECT wa;
    SystemParametersInfoW(SPI_GETWORKAREA, 0, &wa, 0);
    int ww = 900, wh = 620;
    int wx = wa.left + (wa.right - wa.left - ww) / 2;
    int wy = wa.top + (wa.bottom - wa.top - wh) / 2;
    GP.hwnd = CreateWindowExW(WS_EX_APPWINDOW, L"RamBoostProMain", L"RamBoost Pro",
                              WS_POPUP | WS_MINIMIZEBOX | WS_MAXIMIZEBOX,
                              wx, wy, ww, wh, nullptr, nullptr, hInst, nullptr);
    phase(L"05 window create", GP.hwnd != nullptr);
    if (GP.hwnd) {
        AddTrayIcon(GP.hwnd);
        ShowWindow(GP.hwnd, SW_SHOW);
        UpdateWindow(GP.hwnd);
        ST_Pump(200);
        phase(L"06 window visible + render smoke", IsWindowVisible(GP.hwnd) != FALSE);

        // 07 render every tab (with sample data for temp/procs)
        const wchar_t* tabNames[T_COUNT] = {
            L"overview", L"clean", L"temp", L"procs", L"stream", L"settings"
        };
        bool alive = true;
        for (int t = 0; t < T_COUNT && alive; t++) {
            if (t == T_TEMP) {
                CleanCategory ca, cb, cc;
                ca.name = L"Пользовательские Temp"; ca.group = CG_USER; ca.canClean = true;
                ca.size = 12345678; ca.count = 12; ca.status = CS_OK;
                cb.name = L"Prefetch"; cb.group = CG_SYSTEM; cb.requiresAdmin = true; cb.canClean = true;
                cb.size = 999; cb.count = 3; cb.status = CS_OK;
                cc.name = L"Chrome Cache"; cc.group = CG_USER; cc.canClean = true;
                cc.size = 4294967296ULL; cc.count = 400; cc.status = CS_OK;
                GP.cats = { ca, cb, cc };
                GP.scanned = true;
                GP.scannedTotal = 12345678ull + 999 + 4294967296ull;
                GP.scannedFiles = 415;
                GP.catChecked = { 1, 0, 1 };
                GP.scrollTemp = 0;
            }
            if (t == T_PROCS) {
                GP.procs = {
                    { 100, L"explorer.exe", 500000000, false },
                    { 200, L"chrome.exe", 900000000, true },
                    { 300, L"system", 100000000, false }
                };
                GP.procFilter.clear();
                GP.scrollProcs = 0;
                RebuildProcView();
            }
            GP.tab = t;
            ApplyLayout();
            InvalidateRect(GP.hwnd, nullptr, FALSE);
            UpdateWindow(GP.hwnd);
            ST_Pump(50);
            if (!IsWindow(GP.hwnd)) { alive = false; phase(L"window died", false); }
            else {
                ST_Note(log, L"    rendered tab=%d (%s)", t, tabNames[t]);
            }
        }
        phase(L"07 all 6 tabs rendered alive", alive);
        if (GP.tab != T_OVERVIEW) { GP.tab = T_OVERVIEW; ApplyLayout(); InvalidateRect(GP.hwnd, nullptr, FALSE); }

        // 08 tab switch via real clicks
        {
            int before = GP.tab;
            ST_Click(GP.hwnd, center(GP.tabs[3].rc).x, center(GP.tabs[3].rc).y);
            phase(L"08 click tab#3 selects procs", GP.tab == T_PROCS);
            ST_Click(GP.hwnd, center(GP.tabs[0].rc).x, center(GP.tabs[0].rc).y);
            phase(L"08 click tab#0 selects overview", GP.tab == T_OVERVIEW);
        }

        // 09 + 10 clean-tab interactions (must be on the clean tab)
        {
            GP.tab = T_CLEAN;
            ApplyLayout();
            InvalidateRect(GP.hwnd, nullptr, FALSE);
            UpdateWindow(GP.hwnd);
            ST_Click(GP.hwnd, center(GP.modeBtns[1].rc).x, center(GP.modeBtns[1].rc).y);
            phase(L"09 mode button click switches to smart", GP.st.mode == CM_SMART);
            ST_Click(GP.hwnd, center(GP.modeBtns[2].rc).x, center(GP.modeBtns[2].rc).y);
            phase(L"09 mode button click switches to aggressive", GP.st.mode == CM_AGGRESSIVE);

            bool before = GP.st.actions[ACT_WS_TRIM];
            ST_Click(GP.hwnd, center(GP.actionChecks[0].rc).x, center(GP.actionChecks[0].rc).y);
            phase(L"10 action check toggles", GP.st.actions[ACT_WS_TRIM] != before);
            if (GP.st.actions[ACT_WS_TRIM] != before) {
                ST_Click(GP.hwnd, center(GP.actionChecks[0].rc).x, center(GP.actionChecks[0].rc).y);
            }
        }

        // 11 temp list: sample + click a row checkbox
        {
            GP.tab = T_TEMP;
            CleanCategory ca, cb;
            ca.name = L"Пользовательские Temp"; ca.group = CG_USER; ca.canClean = true;
            ca.size = 100; ca.count = 1; ca.status = CS_OK;
            cb.name = L"Prefetch"; cb.group = CG_SYSTEM; cb.requiresAdmin = true; cb.canClean = true;
            cb.size = 200; cb.count = 2; cb.status = CS_OK;
            GP.cats = { ca, cb };
            GP.scanned = true;
            GP.scannedTotal = 300;
            GP.scannedFiles = 3;
            GP.catChecked = { 1, 1 };
            GP.scrollTemp = 0;
            ApplyLayout();
            InvalidateRect(GP.hwnd, nullptr, FALSE);
            UpdateWindow(GP.hwnd);
            RECT rt = GP.listRc;
            int bx = rt.left + TEMP_PAD + 9;
            int firstRow = 0;
            for (int k = 0; k < (int)GP.tempRows.size(); k++)
                if (GP.tempRows[k] >= 0) { firstRow = k; break; }
            int by = rt.top + TEMP_TOP_OFF + firstRow * TEMP_ROW_H + TEMP_ROW_H / 2;
            int beforeC = GP.catChecked[0];
            ST_Click(GP.hwnd, bx, by);
            phase(L"11 temp row checkbox toggles", GP.catChecked[0] != beforeC);
        }

        // 12 slider drag
        {
            GP.tab = T_SETTINGS;
            ApplyLayout();
            InvalidateRect(GP.hwnd, nullptr, FALSE);
            UpdateWindow(GP.hwnd);
            int x0 = GP.thrBar.left + (GP.thrBar.right - GP.thrBar.left) / 2;
            int y0 = (GP.thrBar.top + GP.thrBar.bottom) / 2;
            int beforeT = GP.st.autoThreshold;
            SendMessageW(GP.hwnd, WM_MOUSEMOVE, 0, MAKELPARAM(x0, y0));
            SendMessageW(GP.hwnd, WM_LBUTTONDOWN, MK_LBUTTON, MAKELPARAM(x0, y0));
            SendMessageW(GP.hwnd, WM_MOUSEMOVE, 0, MAKELPARAM(x0 + 40, y0));
            SendMessageW(GP.hwnd, WM_LBUTTONUP, 0, MAKELPARAM(x0 + 40, y0));
            int mid = (int)((double)(x0 - GP.thrBar.left) * 100.0 / (double)(GP.thrBar.right - GP.thrBar.left));
            phase(L"12 slider drag changes threshold", GP.st.autoThreshold != beforeT ||
                  GP.st.autoThreshold == (mid < 40 ? 40 : mid > 95 ? 95 : mid));
            GP.st.autoThreshold = 80;
            ApplyLayout();
            InvalidateRect(GP.hwnd, nullptr, FALSE);
        }

        // 13 settings checks toggle UI state
        {
            ApplyLayout();
            bool b1 = GP.st.autostart, b2 = GP.st.simpleUi;
            ST_Click(GP.hwnd, center(GP.chkAutostart.rc).x, center(GP.chkAutostart.rc).y);
            phase(L"13 chkAutostart toggles", GP.st.autostart != b1);
            ST_Click(GP.hwnd, center(GP.chkSimpleUi.rc).x, center(GP.chkSimpleUi.rc).y);
            phase(L"13 chkSimpleUi toggles", GP.st.simpleUi != b2);
            if (GP.st.simpleUi != b2) {
                // re-render to verify simple path works
                InvalidateRect(GP.hwnd, nullptr, FALSE);
                UpdateWindow(GP.hwnd);
                ST_Pump(20);
                ST_Click(GP.hwnd, center(GP.chkSimpleUi.rc).x, center(GP.chkSimpleUi.rc).y);
            }
            if (GP.st.autostart != b1) {
                ST_Click(GP.hwnd, center(GP.chkAutostart.rc).x, center(GP.chkAutostart.rc).y);
            }
        }

        // 14 proc list interaction (sample data)
        {
            GP.tab = T_PROCS;
            GP.procs = {
                { 100, L"explorer.exe", 500000000, false },
                { 200, L"chrome.exe", 900000000, true },
                { 300, L"system", 100000000, false }
            };
            GP.procFilter.clear();
            GP.scrollProcs = 0;
            RebuildProcView();
            ApplyLayout();
            InvalidateRect(GP.hwnd, nullptr, FALSE);
            UpdateWindow(GP.hwnd);
            RECT rt = GP.listRc;
            int pad = 14, topOff = 34, rowH = 32;
            int rowY = rt.top + pad + topOff + rowH / 2;
            ST_Click(GP.hwnd, (rt.left + rt.right) / 2, rowY);
            phase(L"14 click proc row selects it", GP.selProc == 0);
            // priority boost on sample pid (harmless)
            OnClick(51);
            phase(L"14 proc boost command safe", true);
            // sort via ram header
            ST_Click(GP.hwnd, (GP.hdrRam.left + GP.hdrRam.right) / 2,
                     (GP.hdrRam.top + GP.hdrRam.bottom) / 2);
            phase(L"14 ram header sorts", GP.sortCol == 0);
            ST_Click(GP.hwnd, (GP.hdrPid.left + GP.hdrPid.right) / 2,
                     (GP.hdrPid.top + GP.hdrPid.bottom) / 2);
            phase(L"14 pid header sorts", GP.sortCol == 1);
        }

        // 15 flow: select-all / select-none on temp
        {
            GP.tab = T_TEMP;
            CleanCategory ca, cb;
            ca.name = L"Cat A"; ca.group = CG_USER; ca.canClean = true;
            ca.size = 100; ca.count = 1; ca.status = CS_OK;
            cb.name = L"Cat B"; cb.group = CG_SYSTEM; cb.requiresAdmin = true; cb.canClean = true;
            cb.size = 200; cb.count = 2; cb.status = CS_OK;
            GP.cats = { ca, cb };
            GP.scanned = true;
            GP.scannedTotal = 300;
            GP.scannedFiles = 3;
            GP.catChecked = { 0, 0 };
            ApplyLayout();
            InvalidateRect(GP.hwnd, nullptr, FALSE);
            UpdateWindow(GP.hwnd);
            OnClick(66);
            phase(L"15 select-all checks all", GP.catChecked[0] == 1 && GP.catChecked[1] == 1);
            OnClick(67);
            phase(L"15 select-none unchecks all", GP.catChecked[0] == 0 && GP.catChecked[1] == 0);
        }

        // 16 caption controls
        {
            ApplyLayout();
            // minimize
            ST_Click(GP.hwnd, center(GP.capMinRc).x, center(GP.capMinRc).y);
            ST_Pump(30);
            bool minimized = IsIconic(GP.hwnd) != FALSE;
            phase(L"16 caption minimize", minimized);
            ShowWindow(GP.hwnd, SW_RESTORE);
            ST_Pump(30);
            // maximize toggle
            ST_Click(GP.hwnd, center(GP.capMaxRc).x, center(GP.capMaxRc).y);
            ST_Pump(30);
            bool maximized = GP.capMax;
            phase(L"16 caption maximize", maximized);
            ST_Click(GP.hwnd, center(GP.capMaxRc).x, center(GP.capMaxRc).y);
            ST_Pump(30);
            phase(L"16 caption restore", !GP.capMax);
        }

        // 17 tray icons
        {
            HICON ti1 = MakeTrayIcon(ui::GREEN);
            HICON ti2 = MakeTrayIcon(ui::ORANGE);
            HICON ti3 = MakeTrayIcon(ui::RED);
            phase(L"17 tray icons created", ti1 && ti2 && ti3);
            if (ti1) DestroyIcon(ti1);
            if (ti2) DestroyIcon(ti2);
            if (ti3) DestroyIcon(ti3);
            // let the live timer path build/refresh tray icon
            ST_Pump(1200);
            phase(L"17 tray icon live update", GP.trayIcon != nullptr);
        }

ST_Pump(300);
        phase(L"18 window alive at end of tests", IsWindow(GP.hwnd) != FALSE);
        DestroyWindow(GP.hwnd);
    } else {
        fails++;
    }

    ui::Shutdown();
    if (GP.icon) { DestroyIcon(GP.icon); GP.icon = nullptr; }
    std::wstring res = L"RESULT: " + std::to_wstring(fails) + L" failure(s)";
    ST_Log(log, res.c_str());
    if (log && log != INVALID_HANDLE_VALUE) CloseHandle(log);
    return fails == 0 ? 0 : 1;
}

int WINAPI wWinMain(HINSTANCE hInst, HINSTANCE, PWSTR, int) {
    if (ST_HasArg(L"--selftest")) return SelfTest(hInst);
    if (ST_HasArg(L"--shot"))     return ShotMain(hInst);
    if (!IsElevated() && !ST_HasArg(L"--noelev")) {
        wchar_t exe[MAX_PATH];
        GetModuleFileNameW(nullptr, exe, MAX_PATH);
        SHELLEXECUTEINFOW sei = {};
        sei.cbSize = sizeof(sei);
        sei.lpFile = exe;
        sei.lpVerb = L"runas";
        sei.nShow = SW_SHOW;
        if (ShellExecuteExW(&sei)) return 0;
    }

    GP.icon = (HICON)LoadImageW(hInst, MAKEINTRESOURCEW(IDI_APP), IMAGE_ICON, 32, 32, LR_DEFAULTCOLOR);
    if (!GP.icon) GP.icon = LoadIconW(nullptr, IDI_APPLICATION);

    GP.st.Load();
    ui::g_simpleUi = GP.st.simpleUi;
    if (GP.st.closeApps.empty())
        GP.st.closeApps = { L"Telegram", L"Discord", L"Slack", L"steamwebhelper" };
    if (GP.st.highPrioApps.empty())
        GP.st.highPrioApps = { L"cs2", L"dota2", L"GTA5", L"r5apex", L"valorant", L"warband_server" };

    ui::Init();

    WNDCLASSW wc = {};
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInst;
    wc.hCursor = LoadCursorW(nullptr, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
    wc.lpszClassName = L"RamBoostProMain";
    wc.hIcon = GP.icon;
    RegisterClassW(&wc);

int wx = CW_USEDEFAULT, wy = CW_USEDEFAULT, ww = 1000, wh = 700;
    if (GP.st.winW >= 800 && GP.st.winH >= 500) {
        ww = GP.st.winW; wh = GP.st.winH;
        wx = GP.st.winX; wy = GP.st.winY;
    } else {
        RECT wa;
        if (SystemParametersInfoW(SPI_GETWORKAREA, 0, &wa, 0)) {
            ww = wa.right - wa.left >= 1000 ? 1000 : wa.right - wa.left - 24;
            wh = wa.bottom - wa.top >= 700 ? 700 : wa.bottom - wa.top - 24;
            wx = wa.left + (wa.right - wa.left - ww) / 2;
            wy = wa.top + (wa.bottom - wa.top - wh) / 2;
        }
    }
    ww = ww > 800 ? ww : 800;
    wh = wh > 550 ? wh : 550;
    EnsureOnScreen(wx, wy, ww, wh);
    GP.hwnd = CreateWindowExW(WS_EX_APPWINDOW, L"RamBoostProMain", L"RamBoost Pro",
                             WS_POPUP | WS_MINIMIZEBOX | WS_MAXIMIZEBOX,
                             wx, wy, ww, wh, nullptr, nullptr, hInst, nullptr);
    if (!GP.hwnd) return 1;
    ApplyLayout();
    AddTrayIcon(GP.hwnd);
    ShowWindow(GP.hwnd, SW_SHOW);
    UpdateWindow(GP.hwnd);

    MSG msg;
    while (GetMessageW(&msg, nullptr, 0, 0) > 0) {
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }

    ui::Shutdown();
    if (GP.icon) DestroyIcon(GP.icon);
    return (int)msg.wParam;
}


