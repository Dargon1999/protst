#pragma once
#ifndef UI_H
#define UI_H

#ifndef NOMINMAX
#define NOMINMAX
#endif
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif

#include <windows.h>
#include <objidl.h>
#include <gdiplus.h>
#include <string>
#include <vector>

#pragma comment(lib, "gdiplus.lib")

namespace ui {

using namespace Gdiplus;

// Modern dark theme palette — deeper, more premium
const COLORREF BG      = RGB(0x0F, 0x0F, 0x13);
const COLORREF CARD    = RGB(0x1A, 0x1D, 0x24);
const COLORREF CARD2   = RGB(0x22, 0x26, 0x2E);
const COLORREF BORDER  = RGB(0x2E, 0x32, 0x3C);
const COLORREF TEXT    = RGB(0xF3, 0xF4, 0xF6);
const COLORREF DIM     = RGB(0x9C, 0xA3, 0xAF);
const COLORREF ACCENT  = RGB(0x60, 0xA5, 0xFA);
const COLORREF ACCENT2 = RGB(0x3B, 0x82, 0xF6);
const COLORREF GREEN   = RGB(0x34, 0xD3, 0x99);
const COLORREF RED     = RGB(0xF8, 0x71, 0x71);
const COLORREF ORANGE  = RGB(0xFB, 0xBF, 0x24);
const COLORREF PURPLE  = RGB(0xA7, 0x8B, 0xFA);
const COLORREF CYAN    = RGB(0x22, 0xD3, 0xEE);

void Init();
void Shutdown();

// When true, expensive paint effects (shadows / glows) are skipped.
extern bool g_simpleUi;

Font*   GetFont(float pts, bool bold = false);
Color   ToColor(COLORREF c);
Color   ToColorA(COLORREF c, BYTE alpha);

// Core primitives
GraphicsPath* MakeRoundRect(float x, float y, float w, float h, float r);
void    RoundedRect(Graphics& g, float x, float y, float w, float h,
                    float radius, bool fill, Color fillCol, float strokeW = 0.0f, Color stroke = Color());
void    RoundedRectGradient(Graphics& g, float x, float y, float w, float h,
                           float radius, Color c1, Color c2, bool vertical = true);
void    DrawShadow(Graphics& g, float x, float y, float w, float h, float radius, BYTE alpha = 50);
void    DrawGlow(Graphics& g, float x, float y, float w, float h, float radius, Color col, float expand = 6.0f);
void    DrawCircle(Graphics& g, float cx, float cy, float r, bool fill, Color col, float strokeW = 0.0f, Color stroke = Color());
void    DrawDonut(Graphics& g, float cx, float cy, float r, float thickness, double pct,
                   Color back, Color fillCol, Color glowCol);
void    DrawLine(Graphics& g, float x1, float y1, float x2, float y2, Color col, float width = 1.0f);
void    DrawText(Graphics& g, const std::wstring& s, const RECT& rc,
                 float pts, COLORREF col, bool bold = false, int align = 1);
void    DrawTextF(Graphics& g, const std::wstring& s, float x, float y,
                  float pts, COLORREF col, bool bold = false);
void    DrawTextA(Graphics& g, const std::wstring& s, float x, float y,
                  float pts, Color col, bool bold = false);
void    DrawTextC(Graphics& g, const std::wstring& s, float cx, float cy,
                  float pts, Color col, bool bold = false);
SIZE    MeasureText(HDC hdc, const std::wstring& s, float pts, bool bold = false);
void    DrawBarH(Graphics& g, float x, float y, float w, float h, double pct, Color grad);
void    DrawBarHGlow(Graphics& g, float x, float y, float w, float h, double pct, Color grad);
void    DrawCardTopLine(Graphics& g, float x, float y, float w, float h, float radius, Color lineCol, float lineH = 3.0f);

struct Widget {
    RECT  rc = {0,0,0,0};
    bool  hover = false, pressed = false, disabled = false, on = false;
    bool Hit(int x, int y) const { POINT p{x, y}; return PtInRect(&rc, p) != FALSE; }
};

struct Button : Widget {
    std::wstring text;
    DWORD id = 0;
    bool  accent = false, mini = false, pill = false;
    void Draw(Graphics& g, bool vcenter = true);
};

struct Check : Widget {
    RECT  box = {0,0,0,0};
    std::wstring text;
    DWORD id = 0;
    bool  checked = true;
    void Draw(Graphics& g);
};

struct ScrollBar : Widget {
    int  total = 0;
    int  visible = 0;
    int  pos = 0;
    bool dragging = false;
    int  dragOffset = 0;
    RECT thumbRc = {0,0,0,0};
    void Update();
    void Draw(Graphics& g);
    bool HitThumb(int x, int y) const;
    bool HitTrack(int x, int y) const;
    int  ComputePos(int y) const;
};

void DrawIconMemory(Graphics& g, float cx, float cy, float s, Color col);
void DrawIconCpu(Graphics& g, float cx, float cy, float s, Color col);
void DrawIconBolt(Graphics& g, float cx, float cy, float s, Color col);
void DrawIconTrash(Graphics& g, float cx, float cy, float s, Color col);
void DrawIconPlay(Graphics& g, float cx, float cy, float s, Color col);
void DrawIconShield(Graphics& g, float cx, float cy, float s, Color col);
void DrawIconRocket(Graphics& g, float cx, float cy, float s, Color col);
void DrawIconSettings(Graphics& g, float cx, float cy, float s, Color col);
void DrawIconTemp(Graphics& g, float cx, float cy, float s, Color col);
void DrawIconSearch(Graphics& g, float cx, float cy, float s, Color col);

}
#endif
