#define WIN32_LEAN_AND_MEAN
#include "ui.h"
#include <map>
#include <algorithm>

namespace ui {

static ULONG_PTR gGdiplusToken = 0;
static std::map<std::pair<float, bool>, Font*> gFonts;
bool g_simpleUi = false;

void Init() {
    GdiplusStartupInput in;
    GdiplusStartup(&gGdiplusToken, &in, nullptr);
}

void Shutdown() {
    for (auto& kv : gFonts) delete kv.second;
    gFonts.clear();
    if (gGdiplusToken) GdiplusShutdown(gGdiplusToken);
    gGdiplusToken = 0;
}

Font* GetFont(float pts, bool bold) {
    auto key = std::make_pair(pts, bold);
    auto it = gFonts.find(key);
    if (it != gFonts.end()) return it->second;
    // Pixel size at 96 DPI. The window layout is in physical pixels and is not
    // DPI-scaled, so UnitPoint fonts (which grow with the monitor DPI) overflow
    // every card. UnitPixel keeps text locked to the layout grid.
    float px = pts * 96.0f / 72.0f;
    if (px < 1.0f) px = 1.0f;
    Font* f = new Font(L"Segoe UI", px, bold ? FontStyleBold : FontStyleRegular, UnitPixel);
    gFonts[key] = f;
    return f;
}

Color ToColor(COLORREF c) {
    return Color(255, GetRValue(c), GetGValue(c), GetBValue(c));
}

Color ToColorA(COLORREF c, BYTE alpha) {
    return Color(alpha, GetRValue(c), GetGValue(c), GetBValue(c));
}

GraphicsPath* MakeRoundRect(float x, float y, float w, float h, float r) {
    GraphicsPath* p = new GraphicsPath();
    if (r <= 0.0f) r = 0.01f;
    float d = r * 2.0f;
    p->StartFigure();
    p->AddArc(x, y, d, d, 180, 90);
    p->AddArc(x + w - d, y, d, d, 270, 90);
    p->AddArc(x + w - d, y + h - d, d, d, 0, 90);
    p->AddArc(x, y + h - d, d, d, 90, 90);
    p->CloseFigure();
    return p;
}

void RoundedRect(Graphics& g, float x, float y, float w, float h,
                 float radius, bool fill, Color fillCol, float strokeW, Color stroke) {
    if (w <= 0.01f || h <= 0.01f) return;
    GraphicsPath* p = MakeRoundRect(x, y, w, h, radius);
    if (fill) {
        SolidBrush br(fillCol);
        g.FillPath(&br, p);
    }
    if (strokeW > 0.0f) {
        Pen pen(stroke, strokeW);
        g.DrawPath(&pen, p);
    }
    delete p;
}

void RoundedRectGradient(Graphics& g, float x, float y, float w, float h,
                            float radius, Color c1, Color c2, bool vertical) {
    if (w <= 0.01f || h <= 0.01f) return;
    GraphicsPath* p = MakeRoundRect(x, y, w, h, radius);
    LinearGradientBrush br(
        PointF(x, y),
        vertical ? PointF(x, y + h) : PointF(x + w, y),
        c1, c2);
    g.FillPath(&br, p);
    delete p;
}

void DrawShadow(Graphics& g, float x, float y, float w, float h, float radius, BYTE alpha) {
    if (g_simpleUi) return;
    for (int i = 3; i >= 0; --i) {
        float ext = (float)(i + 1) * 2.0f;
        Color c( alpha / (i + 2), 0, 0, 0 );
        SolidBrush br(c);
        GraphicsPath* p = MakeRoundRect(x - ext, y - ext + 2, w + ext*2, h + ext*2, radius + ext);
        g.FillPath(&br, p);
        delete p;
    }
}

void DrawGlow(Graphics& g, float x, float y, float w, float h, float radius, Color col, float expand) {
    if (g_simpleUi) return;
    for (int i = 3; i >= 0; --i) {
        float ext = (float)(i + 1) * expand * 0.5f;
        Color c( col.GetA() / (i + 3), col.GetR(), col.GetG(), col.GetB() );
        SolidBrush br(c);
        GraphicsPath* p = MakeRoundRect(x - ext, y - ext, w + ext*2, h + ext*2, radius + ext);
        g.FillPath(&br, p);
        delete p;
    }
}

void DrawCircle(Graphics& g, float cx, float cy, float r, bool fill, Color col, float strokeW, Color stroke) {
    if (fill) {
        SolidBrush br(col);
        g.FillEllipse(&br, cx - r, cy - r, r * 2, r * 2);
    }
    if (strokeW > 0.0f) {
        Pen pen(stroke, strokeW);
        g.DrawEllipse(&pen, cx - r, cy - r, r * 2, r * 2);
    }
}

void DrawDonut(Graphics& g, float cx, float cy, float r, float thickness, double pct,
               Color back, Color fillCol, Color glowCol) {
    // Background ring
    Pen backPen(back, thickness);
    backPen.SetStartCap(LineCapRound);
    backPen.SetEndCap(LineCapRound);
    g.DrawArc(&backPen, cx - r, cy - r, r * 2, r * 2, -90, 360);

    // Glow behind active arc
    if (pct > 0.005) {
        Pen glowPen(Color(60, glowCol.GetR(), glowCol.GetG(), glowCol.GetB()), thickness + 6);
        glowPen.SetStartCap(LineCapRound);
        glowPen.SetEndCap(LineCapRound);
        float sweep = (float)(360.0 * pct);
        g.DrawArc(&glowPen, cx - r, cy - r, r * 2, r * 2, -90, sweep);
    }

    // Active arc
    if (pct > 0.005) {
        Pen fillPen(fillCol, thickness);
        fillPen.SetStartCap(LineCapRound);
        fillPen.SetEndCap(LineCapRound);
        float sweep = (float)(360.0 * pct);
        g.DrawArc(&fillPen, cx - r, cy - r, r * 2, r * 2, -90, sweep);
    }
}

void DrawLine(Graphics& g, float x1, float y1, float x2, float y2, Color col, float width) {
    Pen pen(col, width);
    g.DrawLine(&pen, x1, y1, x2, y2);
}

void DrawText(Graphics& g, const std::wstring& s, const RECT& rc,
              float pts, COLORREF col, bool bold, int align) {
    if (s.empty()) return;
    StringFormat fmt;
    fmt.SetLineAlignment(StringAlignmentCenter);
    fmt.SetTrimming(StringTrimmingEllipsisCharacter);
    switch (align) {
    case 0: fmt.SetAlignment(StringAlignmentNear); break;
    case 2: fmt.SetAlignment(StringAlignmentFar); break;
    default: fmt.SetAlignment(StringAlignmentCenter); break;
    }
    int rw = rc.right - rc.left;
    int rh = rc.bottom - rc.top;
    // Real boxes clip so glyphs cannot spill into the next card.
    // Zero-width rects are a legacy "just draw here" hack used by several
    // headers — leave those unclipped or the title disappears.
    bool box = rw >= 8 && rh >= 8;
    if (box) fmt.SetFormatFlags(StringFormatFlagsNoWrap);
    SolidBrush br(ToColor(col));
    RectF rf((REAL)rc.left, (REAL)rc.top, (REAL)(rw > 0 ? rw : 1), (REAL)(rh > 0 ? rh : 1));
    if (box) {
        GraphicsState st = g.Save();
        g.SetClip(rf);
        g.DrawString(s.c_str(), -1, GetFont(pts, bold), rf, &fmt, &br);
        g.Restore(st);
    } else {
        g.DrawString(s.c_str(), -1, GetFont(pts, bold), rf, &fmt, &br);
    }
}

void DrawTextF(Graphics& g, const std::wstring& s, float x, float y,
               float pts, COLORREF col, bool bold) {
    if (s.empty()) return;
    SolidBrush br(ToColor(col));
    g.DrawString(s.c_str(), -1, GetFont(pts, bold), PointF(x, y), &br);
}

void DrawTextA(Graphics& g, const std::wstring& s, float x, float y,
               float pts, Color col, bool bold) {
    if (s.empty()) return;
    SolidBrush br(col);
    g.DrawString(s.c_str(), -1, GetFont(pts, bold), PointF(x, y), &br);
}

void DrawTextC(Graphics& g, const std::wstring& s, float cx, float cy,
               float pts, Color col, bool bold) {
    if (s.empty()) return;
    StringFormat fmt;
    fmt.SetLineAlignment(StringAlignmentCenter);
    fmt.SetAlignment(StringAlignmentCenter);
    SolidBrush br(col);
    // Measure to center properly on the given point
    RectF measured;
    g.MeasureString(s.c_str(), -1, GetFont(pts, bold), PointF(cx, cy), &measured);
    RectF out(cx - measured.Width / 2.0f, cy - measured.Height / 2.0f,
              measured.Width, measured.Height);
    g.DrawString(s.c_str(), -1, GetFont(pts, bold), out, &fmt, &br);
}

SIZE MeasureText(HDC hdc, const std::wstring& s, float pts, bool bold) {
    SIZE sz{};
    if (s.empty()) return sz;
    LOGFONTW lf{};
    lf.lfHeight = -MulDiv((int)(pts + 0.5f), 96, 72);
    lf.lfWeight = bold ? FW_BOLD : FW_NORMAL;
    wcscpy_s(lf.lfFaceName, LF_FACESIZE, L"Segoe UI");
    HFONT f = CreateFontIndirectW(&lf);
    HGDIOBJ old = SelectObject(hdc, f);
    GetTextExtentPoint32W(hdc, s.c_str(), (int)s.size(), &sz);
    SelectObject(hdc, old);
    DeleteObject(f);
    return sz;
}

void DrawBarH(Graphics& g, float x, float y, float w, float h, double pct, Color grad) {
    RoundedRect(g, x, y, w, h, h / 2.0f, true, ToColor(BORDER));
    double p = std::max(0.0, std::min(1.0, pct));
    if (p > 0.005) {
        float ww = (float)(w * p);
        GraphicsPath* path = MakeRoundRect(x, y, ww, h, h / 2.0f);
        LinearGradientBrush br(PointF(x, y), PointF(x + ww, y),
                               Color(255, 59, 130, 246), grad);
        g.FillPath(&br, path);
        delete path;
    }
}

void DrawBarHGlow(Graphics& g, float x, float y, float w, float h, double pct, Color grad) {
    // Background track with subtle glow
    DrawGlow(g, x, y, w, h, h / 2.0f, Color(20, 96, 165, 250), 4.0f);
    RoundedRect(g, x, y, w, h, h / 2.0f, true, Color(40, 30, 40, 55));

    double p = std::max(0.0, std::min(1.0, pct));
    if (p > 0.005) {
        float ww = (float)(w * p);
        // Glow behind fill
        DrawGlow(g, x, y, ww, h, h / 2.0f, Color(80, grad.GetR(), grad.GetG(), grad.GetB()), 5.0f);
        // Fill gradient
        GraphicsPath* path = MakeRoundRect(x, y, ww, h, h / 2.0f);
        LinearGradientBrush br(PointF(x, y), PointF(x + ww, y),
                               Color(255, 96, 165, 250), grad);
        g.FillPath(&br, path);
        delete path;
        // Highlight line on top
        DrawLine(g, x + 2, y + 1, x + ww - 2, y + 1, Color(120, 255, 255, 255), 1.0f);
    }
}

void DrawCardTopLine(Graphics& g, float x, float y, float w, float h, float radius, Color lineCol, float lineH) {
    // Draw a subtle top accent line on card
    GraphicsPath* p = MakeRoundRect(x, y, w, h, radius);
    // Clip to top portion
    Region rgn(p);
    g.SetClip(&rgn);
    SolidBrush br(lineCol);
    g.FillRectangle(&br, x, y, w, lineH);
    g.ResetClip();
    delete p;
}

// ------------------------------------------------------------------ Button

void Button::Draw(Graphics& g, bool vcenter) {
    float w = (float)(rc.right - rc.left), h = (float)(rc.bottom - rc.top);
    float rad = pill ? h / 2.0f : 8.0f;

    if (disabled) {
        RoundedRect(g, (float)rc.left, (float)rc.top, w, h, rad, true, ToColor(CARD2));
        RECT r = rc;
        DrawText(g, text, r, mini ? 12.f : 13.f, DIM, false, 1);
        return;
    }

    // Glow for accent buttons
    if (accent && on) {
        DrawGlow(g, (float)rc.left, (float)rc.top, w, h, rad, Color(100, 96, 165, 250), 8.0f);
    } else if (hover && accent) {
        DrawGlow(g, (float)rc.left, (float)rc.top, w, h, rad, Color(60, 96, 165, 250), 6.0f);
    }

    Color bg;
    if (accent) {
        if (pressed) bg = Color(255, 37, 99, 235);
        else if (on) bg = Color(255, 37, 99, 235);
        else bg = Color(255, 59, 130, 246);
    } else {
        if (pressed) bg = ToColor(CARD2);
        else if (on) bg = Color(255, 30, 64, 175);
        else if (hover) bg = Color(255, 40, 45, 55);
        else bg = ToColor(CARD);
    }

    RoundedRect(g, (float)rc.left, (float)rc.top, w, h, rad, true, bg);

    // Subtle border for non-accent
    if (!accent) {
        Color borderCol = on ? Color(255, 96, 165, 250) : (hover ? Color(255, 75, 85, 99) : ToColor(BORDER));
        RoundedRect(g, (float)rc.left, (float)rc.top, w, h, rad, false, Color(), 1.0f, borderCol);
    }

    // Top highlight line for accent
    if (accent) {
        DrawLine(g, (float)rc.left + rad, (float)rc.top + 1,
                 (float)rc.right - rad, (float)rc.top + 1,
                 Color(100, 255, 255, 255), 1.0f);
    }

    RECT r = rc;
    if (pressed) { r.top += 1; r.bottom += 1; }
    Color tc = disabled ? ToColor(DIM) : (accent ? Color(255, 255, 255) : ToColor(TEXT));

    if (!vcenter) {
        StringFormat fmt; fmt.SetAlignment(StringAlignmentCenter);
        fmt.SetLineAlignment(StringAlignmentCenter);
        SolidBrush br(tc);
        RectF rf((REAL)r.left, (REAL)r.top, (REAL)(r.right - r.left), (REAL)(r.bottom - r.top));
        g.DrawString(text.c_str(), -1, GetFont(mini ? 12.f : 13.f, accent || on),
                     rf, &fmt, &br);
        return;
    }
    RECT rr = r;
    DrawText(g, text, rr, mini ? 12.f : 13.f,
             accent ? RGB(255, 255, 255) : TEXT, accent || on, 1);
}

// ------------------------------------------------------------------ Check

void Check::Draw(Graphics& g) {
    float bw = (float)(box.right - box.left);
    float bh = (float)(box.bottom - box.top);

    if (checked) {
        // Glow for checked state
        DrawGlow(g, (float)box.left, (float)box.top, bw, bh, 4.0f,
                 Color(80, 96, 165, 250), 4.0f);
        RoundedRect(g, (float)box.left, (float)box.top, bw, bh, 4, true, ToColor(ACCENT));
        // Top highlight
        DrawLine(g, (float)box.left + 2, (float)box.top + 1,
                 (float)box.right - 2, (float)box.top + 1,
                 Color(120, 255, 255, 255), 1.0f);
    } else {
        RoundedRect(g, (float)box.left, (float)box.top, bw, bh, 4, true, ToColor(CARD2));
        Color borderCol = hover ? Color(255, 96, 165, 250) : ToColor(BORDER);
        RoundedRect(g, (float)box.left, (float)box.top, bw, bh, 4, false, Color(), 1.0f, borderCol);
    }

    if (checked) {
        // Smooth checkmark
        Pen pen(Color(255, 255, 255), 2.0f);
        pen.SetStartCap(LineCapRound);
        pen.SetEndCap(LineCapRound);
        float x0 = (float)box.left + 3.5f, y0 = (float)box.top + 4.0f;
        float s = bw - 7.0f;
        PointF pts[3] = {
            PointF(x0, y0 + s * 0.5f),
            PointF(x0 + s * 0.35f, y0 + s * 0.82f),
            PointF(x0 + s * 1.05f, y0 + s * 0.15f)
        };
        g.DrawCurve(&pen, pts, 3, 0.3f);
    }

    RECT r = rc;
    r.left = box.right + 8;
    DrawText(g, text, r, 12.5f, disabled ? DIM : TEXT, false, 0);
}

// ------------------------------------------------------------------ ScrollBar

void ScrollBar::Update() {
    int w = rc.right - rc.left;
    int h = rc.bottom - rc.top;
    if (total <= visible || total <= 0 || h <= 0) {
        thumbRc = { 0,0,0,0 };
        return;
    }
    float ratio = (float)visible / (float)total;
    int thumbH = std::max((int)(h * ratio), 28);
    float trackLen = (float)(h - thumbH);
    int maxPos = total - visible;
    float p = maxPos > 0 ? (float)pos / (float)maxPos : 0.0f;
    if (p < 0) p = 0; if (p > 1) p = 1;
    int ty = rc.top + (int)(trackLen * p);
    thumbRc = { rc.left + 2, ty, rc.right - 2, ty + thumbH };
}

void ScrollBar::Draw(Graphics& g) {
    int w = rc.right - rc.left;
    int h = rc.bottom - rc.top;
    if (w <= 0 || h <= 0) return;
    if (total <= visible) return;

    RoundedRect(g, (float)rc.left, (float)rc.top, (float)w, (float)h, w / 2.0f,
                true, Color(40, 30, 38, 52));

    if (thumbRc.right > thumbRc.left) {
        float tw = (float)(thumbRc.right - thumbRc.left);
        float th = (float)(thumbRc.bottom - thumbRc.top);
        Color col = hover ? Color(255, 80, 90, 110) : Color(255, 55, 62, 74);
        if (pressed || dragging) col = Color(255, 96, 165, 250);
        if (!g_simpleUi) {
            DrawGlow(g, (float)thumbRc.left, (float)thumbRc.top, tw, th,
                     (th < 12 ? th / 2 : 6), Color(60, 96, 165, 250), 4.0f);
        }
        RoundedRect(g, (float)thumbRc.left, (float)thumbRc.top, tw, th,
                    th / 2.0f, true, col);
    }
}

bool ScrollBar::HitThumb(int x, int y) const {
    if (thumbRc.right <= thumbRc.left) return false;
    POINT p{ x, y };
    return PtInRect(&thumbRc, p) != FALSE;
}

bool ScrollBar::HitTrack(int x, int y) const {
    POINT p{ x, y };
    return PtInRect(&rc, p) != FALSE;
}

int ScrollBar::ComputePos(int y) const {
    int h = rc.bottom - rc.top;
    int thumbH = thumbRc.bottom - thumbRc.top;
    if (thumbH <= 0 || h <= thumbH) return 0;
    float p = (float)(y - rc.top - thumbH / 2) / (float)(h - thumbH);
    if (p < 0) p = 0; if (p > 1) p = 1;
    int maxPos = total - visible;
    if (maxPos < 0) maxPos = 0;
    return (int)(p * (float)maxPos + 0.5f);
}

// ------------------------------------------------------------------ Icons

void DrawIconMemory(Graphics& g, float cx, float cy, float s, Color col) {
    Pen p(col, 1.6f);
    p.SetLineCap(LineCapRound, LineCapRound, DashCapRound);
    float hx = s * 0.42f, hy = s * 0.48f;
    float x0 = cx - hx, y0 = cy - hy;
    float w = hx * 2, h = hy * 2;
    RoundedRect(g, x0, y0, w, h, 3.5f, false, Color(), 1.6f, col);
    DrawLine(g, x0, cy - 1, cx - hx * 0.55f, cy - 1, col, 1.4f);
    DrawLine(g, x0, cy + 1, cx - hx * 0.55f, cy + 1, col, 1.4f);
    DrawCircle(g, cx + hx * 0.55f, cy - hy * 0.35f, 1.8f, true, col);
    DrawCircle(g, cx + hx * 0.55f, cy + hy * 0.35f, 1.8f, true, col);
}

void DrawIconCpu(Graphics& g, float cx, float cy, float s, Color col) {
    Pen p(col, 1.6f);
    p.SetLineCap(LineCapRound, LineCapRound, DashCapRound);
    float hx = s * 0.38f, hy = s * 0.38f;
    RoundedRect(g, cx - hx, cy - hy, hx * 2, hy * 2, 3.0f, false, Color(), 1.6f, col);
    RoundedRect(g, cx - hx * 0.55f, cy - hy * 0.55f, hx * 1.1f, hy * 1.1f, 2.0f, false, Color(), 1.4f, col);
    float pad = s * 0.08f;
    for (int i = 0; i < 3; i++) {
        float y = cy - hy - pad + i * (hy + pad);
        DrawLine(g, cx - hx - pad * 1.5f, y, cx - hx - pad * 0.4f, y, col, 1.4f);
        DrawLine(g, cx + hx + pad * 0.4f, y, cx + hx + pad * 1.5f, y, col, 1.4f);
    }
}

void DrawIconBolt(Graphics& g, float cx, float cy, float s, Color col) {
    GraphicsPath path;
    float hx = s * 0.28f, hy = s * 0.46f;
    PointF pts[6] = {
        PointF(cx + hx * 0.15f, cy - hy),
        PointF(cx - hx * 0.75f, cy + hy * 0.05f),
        PointF(cx - hx * 0.15f, cy + hy * 0.05f),
        PointF(cx - hx * 0.15f, cy + hy),
        PointF(cx + hx * 0.75f, cy - hy * 0.05f),
        PointF(cx + hx * 0.15f, cy - hy * 0.05f)
    };
    path.AddPolygon(pts, 6);
    SolidBrush br(col);
    g.FillPath(&br, &path);
}

void DrawIconTrash(Graphics& g, float cx, float cy, float s, Color col) {
    Pen p(col, 1.6f);
    p.SetLineCap(LineCapRound, LineCapRound, DashCapRound);
    float hx = s * 0.38f, hy = s * 0.42f;
    DrawLine(g, cx - hx * 0.75f, cy - hy, cx + hx * 0.75f, cy - hy, col, 1.6f);
    RoundedRect(g, cx - hx * 0.65f, cy - hy * 0.82f, hx * 1.3f, hy * 0.22f, 1.5f, false, Color(), 1.5f, col);
    RoundedRect(g, cx - hx * 0.6f, cy - hy * 0.55f, hx * 1.2f, hy * 1.4f, 2.5f, false, Color(), 1.5f, col);
    DrawLine(g, cx - hx * 0.22f, cy - hy * 0.4f, cx - hx * 0.22f, cy + hy * 0.7f, col, 1.2f);
    DrawLine(g, cx + hx * 0.22f, cy - hy * 0.4f, cx + hx * 0.22f, cy + hy * 0.7f, col, 1.2f);
}

void DrawIconPlay(Graphics& g, float cx, float cy, float s, Color col) {
    float r = s * 0.44f;
    GraphicsPath path;
    PointF pts[3] = {
        PointF(cx - r * 0.5f, cy - r),
        PointF(cx + r * 0.9f, cy),
        PointF(cx - r * 0.5f, cy + r)
    };
    path.AddPolygon(pts, 3);
    SolidBrush br(col);
    g.FillPath(&br, &path);
}

void DrawIconShield(Graphics& g, float cx, float cy, float s, Color col) {
    Pen p(col, 1.7f);
    p.SetLineCap(LineCapRound, LineCapRound, DashCapRound);
    GraphicsPath path;
    float r = s * 0.45f;
    PointF pts[6] = {
        PointF(cx, cy - r),
        PointF(cx + r, cy - r * 0.55f),
        PointF(cx + r * 0.92f, cy + r * 0.35f),
        PointF(cx, cy + r),
        PointF(cx - r * 0.92f, cy + r * 0.35f),
        PointF(cx - r, cy - r * 0.55f)
    };
    path.AddPolygon(pts, 6);
    SolidBrush br(Color(60, col.GetR(), col.GetG(), col.GetB()));
    g.FillPath(&br, &path);
    Pen sp(col, 1.6f);
    g.DrawPath(&sp, &path);
    DrawLine(g, cx - r * 0.45f, cy, cx - r * 0.08f, cy + r * 0.4f, col, 1.6f);
    DrawLine(g, cx - r * 0.08f, cy + r * 0.4f, cx + r * 0.5f, cy - r * 0.32f, col, 1.6f);
}

void DrawIconRocket(Graphics& g, float cx, float cy, float s, Color col) {
    Pen p(col, 1.6f);
    p.SetLineCap(LineCapRound, LineCapRound, DashCapRound);
    float hy = s * 0.48f;
    GraphicsPath path;
    PointF nose[4] = {
        PointF(cx, cy - hy),
        PointF(cx + s * 0.18f, cy - hy * 0.2f),
        PointF(cx + s * 0.18f, cy + hy * 0.45f),
        PointF(cx - s * 0.18f, cy + hy * 0.45f)
    };
    path.AddBeziers(nose, 4);
    path.CloseFigure();
    SolidBrush br(Color(50, col.GetR(), col.GetG(), col.GetB()));
    g.FillPath(&br, &path);
    g.DrawPath(&p, &path);
    DrawCircle(g, cx, cy - hy * 0.25f, s * 0.08f, true, col);
    DrawLine(g, cx - s * 0.22f, cy + hy * 0.3f, cx - s * 0.34f, cy + hy * 0.65f, col, 1.6f);
    DrawLine(g, cx + s * 0.22f, cy + hy * 0.3f, cx + s * 0.34f, cy + hy * 0.65f, col, 1.6f);
    DrawLine(g, cx - s * 0.1f, cy + hy * 0.45f, cx, cy + hy * 0.7f, col, 1.6f);
    DrawLine(g, cx + s * 0.1f, cy + hy * 0.45f, cx, cy + hy * 0.7f, col, 1.6f);
}

void DrawIconSettings(Graphics& g, float cx, float cy, float s, Color col) {
    Pen p(col, 1.6f);
    p.SetLineCap(LineCapRound, LineCapRound, DashCapRound);
    GraphicsPath gear;
    float rOut = s * 0.42f, rIn = s * 0.22f;
    const int teeth = 8;
    PointF pts[teeth * 2];
    for (int i = 0; i < teeth * 2; i++) {
        float a = (float)i * 3.14159f / (float)teeth - 3.14159f / 2.0f;
        float r = (i % 2 == 0) ? rOut : rOut * 0.82f;
        pts[i] = PointF(cx + cosf(a) * r, cy + sinf(a) * r);
    }
    gear.AddPolygon(pts, teeth * 2);
    SolidBrush br(Color(45, col.GetR(), col.GetG(), col.GetB()));
    g.FillPath(&br, &gear);
    g.DrawPath(&p, &gear);
    DrawCircle(g, cx, cy, rIn, false, Color(), 1.6f, col);
    DrawCircle(g, cx, cy, rIn * 0.55f, true, col);
}

void DrawIconTemp(Graphics& g, float cx, float cy, float s, Color col) {
    Pen p(col, 1.6f);
    p.SetLineCap(LineCapRound, LineCapRound, DashCapRound);
    float w = s * 0.5f, h = s * 0.6f;
    float x0 = cx - w / 2, y0 = cy - h / 2;
    RoundedRect(g, x0, y0, w, h, 2.5f, false, Color(), 1.6f, col);
    DrawLine(g, x0 + w * 0.2f, y0 + h * 0.15f, x0 + w * 0.8f, y0 + h * 0.15f, col, 1.2f);
    DrawLine(g, x0 + w * 0.2f, y0 + h * 0.35f, x0 + w * 0.7f, y0 + h * 0.35f, col, 1.2f);
    DrawLine(g, x0 + w * 0.2f, y0 + h * 0.55f, x0 + w * 0.75f, y0 + h * 0.55f, col, 1.2f);
    DrawLine(g, x0 + w * 0.2f, y0 + h * 0.75f, x0 + w * 0.55f, y0 + h * 0.75f, col, 1.2f);
}

void DrawIconSearch(Graphics& g, float cx, float cy, float s, Color col) {
    Pen p(col, 1.8f);
    p.SetLineCap(LineCapRound, LineCapRound, DashCapRound);
    float r = s * 0.35f;
    DrawCircle(g, cx - r * 0.25f, cy - r * 0.25f, r, false, Color(), 1.8f, col);
    DrawLine(g, cx + r * 0.55f, cy + r * 0.55f, cx + r * 1.05f, cy + r * 1.05f, col, 1.8f);
}

}
