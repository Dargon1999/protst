#pragma once
#ifndef SETTINGS_H
#define SETTINGS_H

#include <windows.h>
#include <string>
#include <vector>
#include <cstdint>
#include "memcore.h"

class Settings {
public:
    Settings();

    bool autostart = false;
    bool minimizeToTray = true;
    bool showNotifications = true;
    bool autoClean = false;
    int autoThreshold = 80;
    std::wstring hotkeyKey = L"F7";
    CleanMode mode = CM_AGGRESSIVE;
    bool actions[ACT_COUNT]{};

    std::vector<std::wstring> customProtected;
    std::vector<std::wstring> closeApps;      // stream mode
    std::vector<std::wstring> highPrioApps;   // stream mode
    bool disableNotifsInStream = false;
    bool simpleUi = false;
    bool scheduledEnabled = false;
    std::wstring schedTime = L"03:00";

    int winX = 0, winY = 0, winW = 1000, winH = 700;

    std::wstring GetPath() const;
    void Load();
    void Save();
    void ApplyAutostart();
private:
    std::wstring engineP_ = L"";
    void Parse(bool apply);
};

// Default keyword-protected names (system + security + drivers).
bool IsProtectedName(const std::wstring& name, const Settings& s);

// Combined list of built-in protected base names (for TrimAllWorkingSets).
std::vector<std::wstring> BuiltinProtectedNames();

#endif