#include "memcore.h"
#include <tlhelp32.h>
#include <functional>
#include <algorithm>
#include <mutex>

typedef LONG NTSTATUS;
#define NT_SUCCESS(Status) (((NTSTATUS)(Status)) >= 0)

// ---------------- constants ----------------
#define SystemMemoryListInformation  80
#define SystemSuperfetchInformation  79
#define SystemPageFileInformation    14
#define SystemRegistryReconciliationInformation 157

#define FLUSH_MODIFIED_LIST             2
#define PURGE_STANDBY_LIST              3
#define PURGE_LOW_PRIORITY_STANDBY_LIST  4
#define MEMORY_COMBINE_PAGES            12

typedef LONG(WINAPI* pNtQSI_T)(ULONG, PVOID, ULONG, PULONG);
typedef LONG(WINAPI* pNtSSI_T)(ULONG, PVOID, ULONG);

static pNtQSI_T NtQSI = nullptr;
static pNtSSI_T NtSSI = nullptr;

struct MLI {
    uint64_t ZeroPageCount;
    uint64_t FreePageCount;
    uint64_t ModifiedPageCount;
    uint64_t ModifiedNoWritePageCount;
    uint64_t BadPageCount;
    uint64_t PageCountByPriority[8];
    uint64_t RepurposedCountsByPriority[8];
    uint64_t ModifiedPageCountPageFile;
};

static LONG64 lastIdle = 0, lastKernel = 0, lastUser = 0;
static bool cpuInit = false;
static std::mutex gCpuMtx;

bool CoreInit() {
    static bool done = false;
    if (done) return NtQSI && NtSSI;
    HMODULE n = GetModuleHandleW(L"ntdll.dll");
    NtQSI = (pNtQSI_T)GetProcAddress(n, "NtQuerySystemInformation");
    NtSSI = (pNtSSI_T)GetProcAddress(n, "NtSetSystemInformation");
    done = true;
    return NtQSI && NtSSI;
}

bool IsElevated() {
    HANDLE t = nullptr;
    if (!OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &t)) return false;
    DWORD sz = 0, elev = 0;
    GetTokenInformation(t, TokenElevation, &elev, sizeof(elev), &sz);
    CloseHandle(t);
    return elev != 0;
}

bool NtSetSysInfo(ULONG cls, void* buf, ULONG len) {
    CoreInit();
    if (!NtSSI) return false;
    return NT_SUCCESS(NtSSI(cls, buf, len));
}

bool EnablePrivileges() {
    HANDLE t;
    if (!OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &t)) return false;
    struct { DWORD Count; struct { LUID Luid; DWORD Attr; } P[8]; } tp;
    tp.Count = 0;
    static const wchar_t* privs[] = {
        L"SeDebugPrivilege", L"SeIncreaseQuotaPrivilege",
        L"SeProfileSingleProcessPrivilege", L"SeIncreaseBasePriorityPrivilege"
    };
    for (auto p : privs) {
        LUID luid;
        if (LookupPrivilegeValueW(nullptr, p, &luid) && tp.Count < 8) {
            tp.P[tp.Count].Luid = luid;
            tp.P[tp.Count].Attr = SE_PRIVILEGE_ENABLED;
            tp.Count++;
        }
    }
    bool ok = AdjustTokenPrivileges(t, FALSE, (PTOKEN_PRIVILEGES)&tp, 0, nullptr, nullptr) != 0;
    CloseHandle(t);
    return ok;
}

void SetBoostPrivileges() { EnablePrivileges(); }

static void ntSetCmd(ULONG cmd) {
    ULONG v = cmd;
    NtSetSysInfo(SystemMemoryListInformation, &v, sizeof(v));
}

bool PurgeStandbyList() { ntSetCmd(PURGE_STANDBY_LIST); return true; }
bool PurgeLowPriorityStandby() { ntSetCmd(PURGE_LOW_PRIORITY_STANDBY_LIST); return true; }
bool FlushModifiedList() { ntSetCmd(FLUSH_MODIFIED_LIST); return true; }
bool CombineMemoryPages() { ntSetCmd(MEMORY_COMBINE_PAGES); return true; }

bool ClearSystemFileCache() {
    SIZE_T minS, maxS;
    DWORD flags;
    if (!GetSystemFileCacheSize(&minS, &maxS, &flags)) return false;
    bool ok = SetSystemFileCacheSize((SIZE_T)-1, (SIZE_T)-1, 0) != 0;
    SetSystemFileCacheSize(minS, maxS, flags);
    return ok;
}

bool ClearSuperfetchCache() {
    struct { ULONG Version; ULONG Magic; ULONG Command; ULONG Reserved[4]; } info{};
    info.Version = 1;
    info.Magic = 0x6A911971;
    info.Command = 4;
    return NtSetSysInfo(SystemSuperfetchInformation, &info, sizeof(info));
}

bool ClearRegistryRecon() {
    return NtSetSysInfo(SystemRegistryReconciliationInformation, nullptr, 0);
}

static Snap readSnap() {
    CoreInit();
    Snap s;
    MEMORYSTATUSEX ms{};
    ms.dwLength = sizeof(ms);
    if (GlobalMemoryStatusEx(&ms)) {
        s.total = ms.ullTotalPhys;
        s.avail = ms.ullAvailPhys;
        s.commitTotal = ms.ullTotalPageFile - ms.ullAvailPageFile;
        s.commitLimit = ms.ullTotalPageFile;
    }
    SYSTEM_INFO si;
    GetSystemInfo(&si);
    s.pageSize = si.dwPageSize;
    s.total = (s.total && s.pageSize) ? s.total : 0;

    if (NtQSI) {
        MLI m{};
        if (NT_SUCCESS(NtQSI(SystemMemoryListInformation, &m, sizeof(m), nullptr))) {
            for (int i = 0; i < 8; i++) s.standby += m.PageCountByPriority[i];
            s.modified = m.ModifiedPageCount + m.ModifiedNoWritePageCount;
            s.free = m.FreePageCount;
            s.zero = m.ZeroPageCount;
        }
        s.standby *= s.pageSize;
        s.modified *= s.pageSize;
        s.free *= s.pageSize;
        s.zero *= s.pageSize;
    }
    PERFORMANCE_INFORMATION pi{};
    pi.cb = sizeof(pi);
    if (GetPerformanceInfo(&pi, pi.cb)) s.cache = (uint64_t)pi.SystemCache * pi.PageSize;

    s.usagePct = s.total > 0 ? 100.0 * (double)(s.total - s.avail) / (double)s.total : 0.0;

    // CPU
    FILETIME idle, ker, usr;
    if (GetSystemTimes(&idle, &ker, &usr)) {
        ULARGE_INTEGER i, k, u;
        i.LowPart = idle.dwLowDateTime; i.HighPart = idle.dwHighDateTime;
        k.LowPart = ker.dwLowDateTime; k.HighPart = ker.dwHighDateTime;
        u.LowPart = usr.dwLowDateTime; u.HighPart = usr.dwHighDateTime;
        std::lock_guard<std::mutex> lock(gCpuMtx);
        if (!cpuInit) {
            lastIdle = i.QuadPart; lastKernel = k.QuadPart; lastUser = u.QuadPart;
            s.cpuPct = 0.0;
            cpuInit = true;
        } else {
            LONG64 kd = (LONG64)(k.QuadPart - lastKernel);
            LONG64 ud = (LONG64)(u.QuadPart - lastUser);
            LONG64 id = (LONG64)(i.QuadPart - lastIdle);
            lastIdle = i.QuadPart; lastKernel = k.QuadPart; lastUser = u.QuadPart;
            LONG64 total = kd + ud;
            if (total > 0) {
                double p = 100.0 * (double)(total - id) / (double)total;
                s.cpuPct = std::max(0.0, std::min(100.0, p));
            }
        }
    }

    // pressure
    double commitPct = s.commitLimit > 0 ? 100.0 * (double)s.commitTotal / (double)s.commitLimit : 0.0;
    double availGb = s.availGB();
    if (availGb < 1.0 || commitPct >= 95) s.pressure = P_CRITICAL;
    else if (availGb < 2.0 || s.usagePct >= 92 || commitPct >= 90) s.pressure = P_HIGH;
    else if (availGb < 3.0 || s.usagePct >= 85 || commitPct >= 80) s.pressure = P_WARNING;
    else if (s.usagePct < 55 && availGb >= 4.0) s.pressure = P_LOW;
    else s.pressure = P_NORMAL;
    return s;
}

Snap GetSnapshot() { return readSnap(); }

static std::wstring WsBase(const std::wstring& name) {
    std::wstring base = name;
    if (base.size() > 4 && _wcsicmp(base.c_str() + base.size() - 4, L".exe") == 0)
        base = base.substr(0, base.size() - 4);
    return base;
}

void TrimAllWorkingSets(const std::vector<std::wstring>& protectedNames) {
    std::vector<std::wstring> prot;
    for (auto& p : protectedNames) prot.push_back(WsBase(p));
    DWORD access = PROCESS_QUERY_INFORMATION | PROCESS_SET_QUOTA;
    HANDLE snapH = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snapH == INVALID_HANDLE_VALUE) return;
    PROCESSENTRY32W pe{};
    pe.dwSize = sizeof(pe);
    if (Process32FirstW(snapH, &pe)) {
        do {
            if (pe.th32ProcessID <= 4) continue;
            std::wstring base = WsBase(pe.szExeFile);
            bool isProt = false;
            for (auto& p : prot) {
                if (_wcsicmp(p.c_str(), base.c_str()) == 0) { isProt = true; break; }
            }
            if (isProt) continue;
            HANDLE h = OpenProcess(access, FALSE, pe.th32ProcessID);
            if (h) { EmptyWorkingSet(h); CloseHandle(h); }
        } while (Process32NextW(snapH, &pe));
    }
    CloseHandle(snapH);
}

uint64_t MemoryAllocTrick(uint64_t availBytes) {
    std::vector<void*> blocks;
    uint64_t allocated = 0;
    const SIZE_T block = 50ull * 1024 * 1024;
    uint64_t target = (uint64_t)(availBytes * 0.85);
    while (allocated < target) {
        void* p = VirtualAlloc(nullptr, block, MEM_COMMIT, PAGE_READWRITE);
        if (!p) break;
        // Touch every page. Writing 4 KB leaves the rest of the 50 MB block
        // as demand-zero and Windows never actually commits it.
        volatile char* b = (volatile char*)p;
        for (SIZE_T off = 0; off < block; off += 4096) b[off] = (char)0xFF;
        blocks.push_back(p);
        allocated += block;
    }
    for (void* p : blocks) VirtualFree(p, 0, MEM_RELEASE);
    return allocated;
}

void MsSleep(DWORD ms) { Sleep(ms); }

const wchar_t* CleanModeName(CleanMode m) {
    switch (m) {
    case CM_GENTLE: return L"Мягкая";
    case CM_SMART: return L"Умная";
    default: return L"Агрессивная";
    }
}



CleanReport RunClean(CleanMode mode, const bool enabled[ACT_COUNT],
                     const std::vector<std::wstring>& protectedNames) {
    CleanReport rep;
    DWORD start = GetTickCount();
    EnablePrivileges();

    auto before = readSnap();
    rep.beforeAvail = before.avail;
    auto cur = before;

    auto step = [&](std::wstring name, std::function<void()> fn, int settle) {
        StepResult sr;
        sr.name = name;
        DWORD t0 = GetTickCount();
        uint64_t a0 = cur.avail;
        fn();
        MsSleep(settle);
        cur = readSnap();
        sr.deltaBytes = (int64_t)cur.avail - (int64_t)a0;
        sr.ms = (int)(GetTickCount() - t0);
        sr.ok = true;
        rep.steps.push_back(sr);
    };

    // Mode chooses intensity. Checkboxes are always honored — an unchecked
    // action never runs, including in aggressive mode.
    auto settleFor = [&](int gentleMs) -> int {
        if (mode == CM_AGGRESSIVE) return gentleMs < 80 ? 40 : gentleMs / 3;
        if (mode == CM_SMART) return gentleMs;
        return gentleMs + 50;
    };
    auto enabledAt = [&](int id) -> bool {
        return id >= 0 && id < ACT_COUNT && enabled[id];
    };

    if (enabledAt(ACT_FILE_CACHE) && mode >= CM_SMART)
        step(L"Файловый кэш", [] { ClearSystemFileCache(); }, settleFor(200));
    if (enabledAt(ACT_PAGEFILE) && mode == CM_AGGRESSIVE)
        step(L"Pagefile", [] { ULONG z = 0; NtSetSysInfo(SystemPageFileInformation, &z, sizeof(z)); }, settleFor(80));
    if (enabledAt(ACT_SUPERFETCH) && mode == CM_AGGRESSIVE)
        step(L"Superfetch / SysMain", [] { ClearSuperfetchCache(); }, settleFor(80));
    if (enabledAt(ACT_REGISTRY))
        step(L"Сброс реестра", [] { ClearRegistryRecon(); }, settleFor(60));
    if (enabledAt(ACT_WS_TRIM))
        step(L"Working Sets процессов", [&] { TrimAllWorkingSets(protectedNames); }, settleFor(250));
    if (enabledAt(ACT_MODIFIED) && mode >= CM_SMART)
        step(L"Modified Page List", [] { FlushModifiedList(); }, settleFor(80));
    if (enabledAt(ACT_STANDBY_ALL) && mode >= CM_SMART) {
        int passes = mode == CM_AGGRESSIVE ? 3 : 1;
        for (int i = 0; i < passes; i++)
            step(L"Standby List (очистка)", [] { PurgeStandbyList(); }, settleFor(60));
    }
    if (enabledAt(ACT_STANDBY_LOW))
        step(L"Standby List (низкий приоритет)", [] { PurgeLowPriorityStandby(); }, settleFor(200));
    if (enabledAt(ACT_COMBINE) && mode == CM_AGGRESSIVE)
        step(L"Combine Memory Pages", [] { CombineMemoryPages(); }, settleFor(60));
    if (enabledAt(ACT_ALLOC_TRICK) && mode == CM_AGGRESSIVE)
        step(L"Memory Allocation Trick", [&] { MemoryAllocTrick(cur.avail); }, settleFor(250));
    if (mode == CM_AGGRESSIVE) {
        if (enabledAt(ACT_FILE_CACHE))
            step(L"Финал: кэш", [] { ClearSystemFileCache(); }, 40);
        if (enabledAt(ACT_STANDBY_ALL)) {
            for (int i = 0; i < 2; i++)
                step(L"Финал: standby", [] { PurgeStandbyList(); }, 20);
        }
    }

    MsSleep(400);
    auto after = readSnap();
    rep.afterAvail = after.avail;
    rep.delta = (int64_t)after.avail - (int64_t)before.avail;
    rep.standbyFreed = before.standby > after.standby ? before.standby - after.standby : 0;
    rep.durationMs = (int)(GetTickCount() - start);

    return rep;
}

std::vector<ProcInfo> GetTopProcesses(int count) {
    std::vector<ProcInfo> procs;
    HANDLE snapH = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snapH == INVALID_HANDLE_VALUE) return procs;
    PROCESSENTRY32W pe{};
    pe.dwSize = sizeof(pe);
    PROCESS_MEMORY_COUNTERS pmc{};
    if (Process32FirstW(snapH, &pe)) {
        do {
            HANDLE h = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, FALSE, pe.th32ProcessID);
            if (h) {
                if (GetProcessMemoryInfo(h, &pmc, sizeof(pmc))) {
                    ProcInfo pi;
                    pi.pid = pe.th32ProcessID;
                    pi.name = pe.szExeFile;
                    pi.ws = pmc.WorkingSetSize;
                    procs.push_back(pi);
                }
                CloseHandle(h);
            }
        } while (Process32NextW(snapH, &pe));
    }
    CloseHandle(snapH);
    std::sort(procs.begin(), procs.end(), [](const ProcInfo& a, const ProcInfo& b) { return a.ws > b.ws; });
    if (procs.size() > (size_t)count) procs.resize(count);
    return procs;
}

bool TrimProcessPid(uint32_t pid) {
    HANDLE h = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_SET_QUOTA, FALSE, pid);
    if (!h) return false;
    bool ok = EmptyWorkingSet(h) != 0;
    CloseHandle(h);
    return ok;
}