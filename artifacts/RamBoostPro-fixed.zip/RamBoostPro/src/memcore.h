#pragma once
#ifndef MEMCORE_H
#define MEMCORE_H

#ifndef NOMINMAX
#define NOMINMAX
#endif

#include <windows.h>
#include <psapi.h>
#include <cstdint>
#include <string>
#include <vector>

enum PressureLevel {
    P_LOW = 0,
    P_NORMAL = 1,
    P_WARNING = 2,
    P_HIGH = 3,
    P_CRITICAL = 4
};

struct Snap {
    uint64_t total = 0, avail = 0, commitTotal = 0, commitLimit = 0;
    uint64_t standby = 0, modified = 0, free = 0, zero = 0, cache = 0;
    uint64_t pageSize = 4096;
    double cpuPct = 0.0;
    double usagePct = 0.0;
    int pressure = P_LOW;

    double availGB() const { return (double)avail / 1073741824.0; }
    double totalGB() const { return (double)total / 1073741824.0; }
    double standbyGB() const { return (double)standby / 1073741824.0; }
};

bool CoreInit();
Snap GetSnapshot();
bool IsElevated();
bool EnablePrivileges();
bool NtSetSysInfo(ULONG cls, void* buf, ULONG len);

bool PurgeStandbyList();
bool PurgeLowPriorityStandby();
bool FlushModifiedList();
bool CombineMemoryPages();
bool ClearSystemFileCache();
bool ClearSuperfetchCache();
bool ClearRegistryRecon();
void TrimAllWorkingSets(const std::vector<std::wstring>& protectedNames);
uint64_t MemoryAllocTrick(uint64_t availBytes);
void SetBoostPrivileges();

void MsSleep(DWORD ms);

// ---------------------- clean engine ----------------------
enum CleanMode { CM_GENTLE = 0, CM_SMART = 1, CM_AGGRESSIVE = 2 };
const wchar_t* CleanModeName(CleanMode m);

struct StepResult {
    std::wstring name;
    bool ok = false;
    int64_t deltaBytes = 0;
    int ms = 0;
};

struct CleanReport {
    uint64_t beforeAvail = 0, afterAvail = 0;
    int64_t delta = 0;                 // signed freed bytes (positive = freed)
    uint64_t standbyFreed = 0;
    std::vector<StepResult> steps;
    int durationMs = 0;
};

// action flags [10]
#define ACT_WS_TRIM       0
#define ACT_STANDBY_LOW   1
#define ACT_FILE_CACHE    2
#define ACT_STANDBY_ALL   3
#define ACT_MODIFIED      4
#define ACT_ALLOC_TRICK   5
#define ACT_SUPERFETCH    6
#define ACT_COMBINE       7
#define ACT_REGISTRY      8
#define ACT_PAGEFILE      9
#define ACT_COUNT         10

CleanReport RunClean(CleanMode mode, const bool enabled[ACT_COUNT],
                     const std::vector<std::wstring>& protectedNames);

struct ProcInfo {
    uint32_t pid = 0;
    std::wstring name;
    uint64_t ws = 0;
    bool isProtected = false;
};

std::vector<ProcInfo> GetTopProcesses(int count);
bool TrimProcessPid(uint32_t pid);

#endif