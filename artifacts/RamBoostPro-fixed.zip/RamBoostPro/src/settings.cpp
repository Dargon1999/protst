#include "settings.h"
#include <fstream>
#include <sstream>
#include <algorithm>
#include <cwctype>
#include <shlobj.h>

static std::wstring gLocalAppDir() {
    wchar_t buf[MAX_PATH];
    if (SHGetFolderPathW(nullptr, CSIDL_LOCAL_APPDATA, nullptr, SHGFP_TYPE_CURRENT, buf) == S_OK)
        return std::wstring(buf) + L"\\RamBoostPro";
    return L"C:\\RamBoostPro";
}

bool default_action_enabled(int idx);

Settings::Settings() {
    for (int i = 0; i < ACT_COUNT; i++) actions[i] = default_action_enabled(i);
    Load();
}

static const wchar_t* kWinNames[] = {
    L"system", L"idle", L"registry", L"smss", L"csrss", L"wininit", L"winlogon",
    L"services", L"lsass", L"svchost", L"fontdrvhost", L"dwm", L"taskhostw",
    L"searchhost", L"runtimebroker", L"sihost", L"shellexperiencehost",
    L"startmenuexperiencehost", L"textinputhost", L"spoolsv", L"conhost",
    L"wudfhost", L"explorer", L"memcompression", L"memory compression",
    L"dllhost", L"audiodg",
};
static const wchar_t* kSecNames[] = {
    L"msmpeng", L"nissrv", L"securityhealthservice", L"securityhealthsystray",
    L"feedbackhub", L"avp", L"ekrn", L"egui", L"bdagent", L"avgsvc",
    L"avastsvc", L"mbamservice", L"kaspersky", L"drweb", L"eset", L"norton",
};
static const wchar_t* kGpuNames[] = {
    L"nvcontainer", L"nvdisplay.container", L"amdrsserv", L"amdow",
    L"radesoftware", L"amdrssrcext", L"nvsphelper", L"nvbackend"
};

std::vector<std::wstring> BuiltinProtectedNames() {
    std::vector<std::wstring> v;
    for (auto* w : kWinNames) v.push_back(w);
    for (auto* w : kSecNames) v.push_back(w);
    for (auto* w : kGpuNames) v.push_back(w);
    return v;
}

bool IsProtectedName(const std::wstring& nameIn, const Settings& s) {
    if (nameIn.empty()) return true;
    std::wstring name = nameIn;
    // strip .exe
    if (name.size() > 4 && _wcsicmp(name.c_str() + name.size() - 4, L".exe") == 0)
        name = name.substr(0, name.size() - 4);

    std::wstring low;
    for (auto c : name) low += (wchar_t)towlower(c);

    // custom
    for (auto& c : s.customProtected) {
        std::wstring c2 = c;
        if (c2.size() > 4 && _wcsicmp(c2.c_str() + c2.size() - 4, L".exe") == 0)
            c2 = c2.substr(0, c2.size() - 4);
        if (_wcsicmp(c2.c_str(), name.c_str()) == 0) return true;
    }

    for (auto* w : kWinNames) if (low == w) return true;

    for (auto* w : kSecNames) if (low.find(w) != std::wstring::npos) return true;

    for (auto* w : kGpuNames) if (low == w) return true;

    return false;
}

bool default_action_enabled(int idx) {
    switch (idx) {
    case ACT_WS_TRIM: return true;
    case ACT_STANDBY_LOW: return true;
    case ACT_FILE_CACHE: return true;
    case ACT_STANDBY_ALL: return true;
    case ACT_MODIFIED: return false;
    case ACT_ALLOC_TRICK: return false;
    case ACT_SUPERFETCH: return false;
    case ACT_COMBINE: return false;
    case ACT_REGISTRY: return true;
    case ACT_PAGEFILE: return false;
    default: return true;
    }
}

std::wstring Settings::GetPath() const {
    return gLocalAppDir() + L"\\settings.conf";
}

void Settings::ApplyAutostart() {
    HKEY key;
    if (RegOpenKeyExW(HKEY_CURRENT_USER,
        L"Software\\Microsoft\\Windows\\CurrentVersion\\Run", 0, KEY_SET_VALUE, &key) != ERROR_SUCCESS)
        return;
    if (autostart) {
        wchar_t exe[MAX_PATH];
        GetModuleFileNameW(nullptr, exe, MAX_PATH);
        std::wstring cmd = L"\"" + std::wstring(exe) + L"\"";
        RegSetValueExW(key, L"RamBoostPro", 0, REG_SZ, (const BYTE*)cmd.c_str(),
                       (DWORD)((cmd.size() + 1) * sizeof(wchar_t)));
    } else {
        RegDeleteValueW(key, L"RamBoostPro");
    }
    RegCloseKey(key);
}

void Settings::Save() {
    std::wstring dir = gLocalAppDir();
    CreateDirectoryW(dir.c_str(), nullptr);
    std::wofstream f(GetPath(), std::ios::out | std::ios::trunc);
    if (!f) return;
    f << L"autostart=" << (autostart ? 1 : 0) << L"\n";
    f << L"minimizeToTray=" << (minimizeToTray ? 1 : 0) << L"\n";
    f << L"showNotifications=" << (showNotifications ? 1 : 0) << L"\n";
    f << L"autoClean=" << (autoClean ? 1 : 0) << L"\n";
    f << L"autoThreshold=" << autoThreshold << L"\n";
    f << L"hotkey=" << hotkeyKey << L"\n";
    f << L"mode=" << (int)mode << L"\n";
    f << L"act=";
    for (int i = 0; i < ACT_COUNT; i++) f << (actions[i] ? 1 : 0);
    f << L"\n";
    f << L"sched=" << (scheduledEnabled ? 1 : 0) << L":" << schedTime << L"\n";
    f << L"streamNotifs=" << (disableNotifsInStream ? 1 : 0) << L"\n";
    f << L"simpleUi=" << (simpleUi ? 1 : 0) << L"\n";
    f << L"win=" << winX << L":" << winY << L":" << winW << L":" << winH << L"\n";

    auto writeList = [&](const wchar_t* label, const std::vector<std::wstring>& v) {
        f << label << L"=";
        for (size_t i = 0; i < v.size(); i++) {
            f << v[i];
            if (i + 1 < v.size()) f << L";";
        }
        f << L"\n";
    };
    writeList(L"protected", customProtected);
    writeList(L"closeApps", closeApps);
    writeList(L"highPrio", highPrioApps);
    f.close();
}

void Settings::Parse(bool apply) {
    std::wifstream f(GetPath());
    if (!f) return;
    std::wstring line;
    while (std::getline(f, line)) {
        if (line.size() < 3) continue;
        if (line.rfind(L"autostart=", 0) == 0) autostart = line[10] == L'1';
        else if (line.rfind(L"minimizeToTray=", 0) == 0) minimizeToTray = line[15] == L'1';
        else if (line.rfind(L"showNotifications=", 0) == 0)
            showNotifications = line.size() > 18 && line[18] == L'1';
        else if (line.rfind(L"autoClean=", 0) == 0) autoClean = line[10] == L'1';
        else if (line.rfind(L"autoThreshold=", 0) == 0) autoThreshold = _wtoi(line.c_str() + 14);
        else if (line.rfind(L"hotkey=", 0) == 0) hotkeyKey = line.substr(7);
        else if (line.rfind(L"mode=", 0) == 0) mode = (CleanMode)_wtoi(line.c_str() + 5);
        else if (line.rfind(L"act=", 0) == 0) {
            int n = (int)line.size() - 4;
            for (int i = 0; i < ACT_COUNT && i < n; i++) actions[i] = line[4 + i] == L'1';
        }
        else if (line.rfind(L"sched=", 0) == 0) {
            scheduledEnabled = line.rfind(L"sched=1:", 0) == 0;
            size_t p = line.find(L':');
            if (p != std::wstring::npos) schedTime = line.substr(p + 1);
        }
        else if (line.rfind(L"streamNotifs=", 0) == 0) disableNotifsInStream = line[13] == L'1';
        else if (line.rfind(L"simpleUi=", 0) == 0) simpleUi = line[9] == L'1';
        else if (line.rfind(L"win=", 0) == 0) {
            int v[4] = {}, cur = 0, acc = 0;
            bool neg = false;
            for (size_t j = 4; j <= line.size() && cur < 4; j++) {
                if (j < line.size() && line[j] == L'-') { neg = true; continue; }
                if (j == line.size() || line[j] == L':') {
                    v[cur++] = neg ? -acc : acc;
                    acc = 0; neg = false;
                } else if (line[j] >= L'0' && line[j] <= L'9') {
                    acc = acc * 10 + (line[j] - L'0');
                }
            }
            winX = v[0]; winY = v[1]; winW = v[2]; winH = v[3];
        }
        else if (line.rfind(L"protected=", 0) == 0) {
            std::wstring v = line.substr(10);
            customProtected.clear();
            std::wstringstream ss(v); std::wstring item;
            while (std::getline(ss, item, L';')) if (!item.empty()) customProtected.push_back(item);
        }
        else if (line.rfind(L"closeApps=", 0) == 0) {
            std::wstring v = line.substr(10);
            closeApps.clear();
            std::wstringstream ss(v); std::wstring item;
            while (std::getline(ss, item, L';')) if (!item.empty()) closeApps.push_back(item);
        }
        else if (line.rfind(L"highPrio=", 0) == 0) {
            std::wstring v = line.substr(9);
            highPrioApps.clear();
            std::wstringstream ss(v); std::wstring item;
            while (std::getline(ss, item, L';')) if (!item.empty()) highPrioApps.push_back(item);
        }
    }
    f.close();
    if (schedTime.size() != 5) schedTime = L"03:00";
    if (mode < CM_GENTLE || mode > CM_AGGRESSIVE) mode = CM_AGGRESSIVE;
}

void Settings::Load() {
    Parse(true);
}