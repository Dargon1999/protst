#pragma once
#ifndef PROCS_H
#define PROCS_H

#include <windows.h>
#include <string>
#include <vector>

// PID of first process whose base name matches `name` (case-insensitive). 0 = not found.
uint32_t FindProcByName(const std::wstring& name);

// Enumerate all processes with working set; fills result (name, pid, ws).
std::vector<std::pair<std::wstring, uint32_t>> AllProcesses();

// Graceful close (WM_CLOSE to windows), then taskkill if still alive after waitMs.
bool CloseProcByName(const std::wstring& name, DWORD waitMs = 1500);

// Set priority class of process (HIGH_PRIORITY_CLASS).
bool SetProcPriority(uint32_t pid, DWORD priorityClass);

// Boost: raise every listed app to High; returns count boosted.
int BoostPriorities(const std::vector<std::wstring>& apps);

// Affinity boost for a game: pin to all processors except core 0 (system core).
bool BoostGameAffinity(const std::wstring& gameName);

// Service helpers.
bool StopService(const wchar_t* name);
bool ServiceExists(const wchar_t* name);

#endif